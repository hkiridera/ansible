<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}
?>
<article>

<h1><span>拒否 URL 設定</span></h1>
<?php message(); ?>
<section>
	<h1>拒否 URL 追加・編集</h1>
	<form action="./?action=add_denyurl" method="post" id="form">
	<dl class="form clearfix">
		<dt>URL</dt>
		<dd><input type="text" name="url" id="url" size="20" placeholder="アクセスランキングに表示しないURL" value="<?php s('url'); ?>" /><span>e.g.) www.google.com</span></dd>
	</dl>
	<p class="button submit">
		<input type="hidden" name="redirect" value="./?mode=deny" />
		<input type="hidden" name="id" id="id" value="0" />
		<input type="submit" value="追加" name="submit" id="submit" />
	</p>
	</form>
</section>

<section>
	<h1>拒否 URL リスト</h1>
	<p>
		拒否 URL に設定してもアクセスは一時的に保存され、ランキング生成時に設定した URL を含むログを削除するようになっています。
	</p>
	<form action="./?action=del_denyurl" method="post" name="del_form" id="del_form">
	<input type="hidden" name="redirect" value="./?mode=deny" />
	<table>
		<colgroup span="1" style="width: 70px;"></colgroup>
		<colgroup span="1"></colgroup>
		<colgroup span="1" style="width: 60px;"></colgroup>
		<colgroup span="1" style="width: 60px;"></colgroup>
		<thead>
		<tr>
			<th>ID</th>
			<th>URL</th>
			<th>編集</th>
			<th>削除</th>
		</tr>
		</thead>
		<tbody>
		<?php foreach ($this->deny as $key => $value) : ?>
		<tr>
			<td><input type="checkbox" name="id[]" id="ch<?php e($value['id']); ?>" value="<?php e($value['id']); ?>" onclick="checkbox(this);" /><label for="ch<?php e($value['id']); ?>"> <?php e($value['id']); ?></label></td>
			<td id="url_<?php e($value['id']); ?>"><?php e($value['url']); ?></td>
			<td><a href="#header" class="actionlink" onclick="denyULREdit('<?php e($value['id']); ?>');">編集</a></td>
			<td><a href="#" class="actionlink" onclick="return checkSubmit('ch<?php e($value['id']); ?>', 'del_form');">削除</a></td>
		</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<p class="button">
		<input type="checkbox" name="chall" id="chall" onclick="check_all(this);" /><label for="chall"> すべて選択</label>
		<input type="submit" value="削除" onclick="return conf('チェックしたURLを削除してもよろしいですか？');" />
	</p>
	</form>
</section>

<?php if (isMode('deny_edit')) : ?>
<script>
<!--
denyULREdit(<?php echo $this->getEditID(); ?>);
-->
</script>
<?php endif; ?>

</article>
