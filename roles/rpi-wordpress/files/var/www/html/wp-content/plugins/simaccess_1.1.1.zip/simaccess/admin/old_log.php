<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}
?>
<div id="contents">

	<article>
		<h1><span>過去のアクセスランキング</span></h1>
		<?php message(); ?>
		<section class="form">
			<h1><?php e($this->h1); ?></h1>
			<?php if ($this->is_readFile) : ?>
				<?php echo $this->fileContents; ?>
			<?php else : ?>
			<form action="./?action=delete_oldlog" method="post" name="del_form" id="del_form">
			<input type="hidden" name="redirect" value="./?mode=old_log" />
			<table>
				<colgroup span="1" style="width: 40px;"></colgroup>
				<colgroup span="1"></colgroup>
				<colgroup span="1" style="width: 210px;"></colgroup>
				<colgroup span="1" style="width: 60px;"></colgroup>
				<thead>
				<tr>
					<th>-</th>
					<th>ファイル名</th>
					<th>作成日時</th>
					<th>削除</th>
				</tr>
				</thead>
				<tbody>
				<?php foreach ($this->log_file as $file) : ?>
				<tr>
					<td><input type="checkbox" name="files[]" id="ch<?php echo $file['file']; ?>" value="<?php echo $file['file']; ?>" /></td>
					<td><a href="./?mode=old_log&amp;file=<?php echo $file['file']; ?>"><?php echo $file['file']; ?></a></td>
					<td><?php echo $file['date']; ?></td>
					<td><a href="" class="actionlink" onclick="return checkSubmit('ch<?php echo $file['file']; ?>', 'del_form');">削除</a></td>
				</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="button">
				<input type="checkbox" name="chall" id="chall" onclick="check_all(this);" /><label for="chall"> すべて選択</label>
				<input type="submit" value="削除" onclick="return conf('チェックしたファイルを削除してもよろしいですか？');" />
			</p>
			</form>
			<?php endif; ?>
		</section>
	</article>
	
</div>

<div id="sidebar">
	<aside>
		<h1>過去ログ</h1>
		<ul class="sidenav">
			<li><a href="./?mode=old_log">ファイル管理</a>
			<ul>
			<?php
			foreach ($this->log_file as $file) {
				echo '<li><a href="./?mode=old_log&file='.$file['file'].'">'.$file['file'].'</a></li>';
			}
			?>
			</ul>
			</li>
		</ul>
	</aside>
</div>
