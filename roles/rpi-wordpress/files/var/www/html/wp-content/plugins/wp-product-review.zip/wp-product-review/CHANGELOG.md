
### 2.9.8 - 07/12/2016
**Changes:** 
- Development

### 2.9.7 - 01/12/2016
**Changes:** 
- Added premium features tab

### 2.9.6 - 31/10/2016
**Changes:** 
- Release 2.9.6

### 2.9.5 - 20/09/2016
**Changes:** 
- Added amazon integration support
- Fixed some design issues

### 2.9.3 - 01/09/2016
**Changes:** 
- Added filters for nofollow links in widgets
- Added dashes in pros/cons list

### 2.9.2 - 26/08/2016
**Changes:** 
- Added color options in pro
- Fixed issue with shortcode markup
- Removed rel=friend

### 2.9.1 - 18/08/2016
**Changes:** 
- Removed buy now or read review if text values are empty
- Fixed undefined notice on plugin activation.

### 2.9.0 - 18/08/2016
**Changes:** 
- Removed addons page
- Changed title and urls
- Updated Upsell texts
- Apply do_shortcode on all review fields.

### 2.8.7 - 07/07/2016
**Changes:** 
- Fixed img closing tag issue
- Fixed rich snippet error when comment influence is off

### 2.8.6 - 16/05/2016
**Changes:** 
- Added compatibility with new pro addons
- Fixed layout issues with the review
- Fixed responsiveness bugs
- Fixed bug with enable/disable review box
 ### 2.8.5 - 16/05/2016 **Changes:** 
