<?php

require_once( dirname(__FILE__). '/class.db.php');
require_once( dirname(__FILE__). '/class.url.php');
require_once( dirname(__FILE__). '/class.login.php');
require_once( dirname(__FILE__). '/class.access.php');
require_once( dirname(__FILE__). '/class.pagenavi.php');

class Admin extends Common
{
	/**
	 * コンストラクタ
	 *
	 * @return void
	 */
	public function __construct() {
	
		parent::__construct();

		$this->db = new DB();
		$this->db->connect('access.sqlite');
		
		$this->access = new Access();
		
		// テンプレートディレクトリ
		$this->tpl_dir = dirname(__FILE__). '/../admin';
		$_SESSION['direct'] = false;
		// モード取得
		$this->mode = getMode();
		// アクション取得
		$this->action = getGet('action');

		$login = new Login($this->action);
		
		// ログインチェック
		if (!$login->isLogin()) {
			$this->mode = 'login';
			$this->i('index.php');
			die();
		}
		
	}
	
	/**
	 * アクセスランキング
	 *
	 * @return void
	 */
	public function adminRanking() {
	
		// 拒否URL削除
		$this->access->denyURLDelete();
		
		$this->access->replace_only = 0;
		list($this->url, $this->name, $this->count) = $this->access->rankProcess();
		
		// 件数
		$cnt = count($this->url);
		
		// ランク計算
		$this->rank = array();
		$rank_temp = 1;
		$prev_rank = 0;
		$prev_count = -1;
		for ($i = 0; $i < $cnt; $i++) {
			if ($this->count[$i] == $prev_count) {
				$this->rank[$i] = $prev_rank;
				$rank_temp++;
			} else {
				$this->rank[$i] = $prev_rank + $rank_temp;
				$rank_temp = 1;
			}
			$prev_rank = $this->rank[$i];
			$prev_count = $this->count[$i];
		}
		
		$this->pagenavi = new PageNavi($this->show_cnt, $this->tpl_dir);
		$this->pagenavi->maxPage($cnt);
		list($this->start, $this->end) = $this->pagenavi->startEnd($cnt);
		
		// ランキング表示
		$this->i('ranking.php');
	}
	
	/**
	 * ランキングから指定 URL 削除
	 *
	 * @return void
	 */
	public function deleteRank() {
	
		$url = getPost('url');
		if (!checkEmpty($url)) {
			return 'URL が指定されていません';
		}
		
		// 指定 URL が置換されたものかチェック
		$ret = $this->db->select('replace', 'ref', ' where url = ?', array(array($url)));
		if (count($ret) > 0) {
			$arr_url = explode('|', $ret[0]['ref']);
		} else {
			$arr_url = array(htmlspecialchars_decode($url, ENT_QUOTES));
		}
		
		$this->db->begin();
		foreach ($arr_url as $url) {
			$url = '%'.str_replace('%', '|%', $url).'%';
			$this->db->delete('access', " where referrer like ? escape '|'", array($url));
		}
		$this->db->commit();
		
		return true;
	
	}
	
	/**
	 * 拒否 URL 設定
	 *
	 * @return void
	 */
	public function denyURLSetting() {
		
		$url = new URL($this);
		
		if (($this->deny = $url->readDenyURL()) !== false) {
			$this->i('deny.php');
		}
	
	}
	
	/**
	 * 置換 URL 設定
	 *
	 * @return void
	 */
	public function replaceURLSetting() {
		
		$url = new URL($this);

		if (($this->replace = $url->readReplaceURL()) !== false) {
			$this->i('replace.php');
		}
	
	}
	
	/**
	 * 各種設定
	 *
	 * @return void
	 */
	public function setting() {
		
		//
		$this->rank_type = array(null, null, null);
		$this->rank_type[RANK_TYPE] = 'checked="checked" ';
		
		$this->replace_only = array(null, null);
		$this->replace_only[REPLACE_ONLY] = 'checked="checked" ';
		
		$this->i('setting.php');
	
	}
	
	/**
	 * 各種設定
	 *
	 * @return bool or string
	 */
	public function set() {
		
		//
		$post = getPost();
		
		$error = null;
		if (getGet('type') == 0) {
			$set_key = array(
				'rank_type',
				'rank_day',
				'rank_count',
				'name_length',
				'ip_interval',
				'create_interval',
				'replace_only',
			);
			foreach ($set_key as $key) {
				if (!isInteger($post[$key])) {
					$error .= '数値で入力してください<br />'."\n";
					break;
				}
			}
			
			$set_key[] = 'character_code';
			
			// チェック
			if ($post['rank_day'] < 1 || $post['rank_day'] > 31) {
				$error .= '日数は 1 ~ 31 の間で入力してください<br />'."\n";
			}
			if ($post['rank_count'] < 1) {
				$error .= '表示件数は 1 以上で入力してください<br />'."\n";
			}
			if ($post['name_length'] < 1) {
				$error .= '表示最大文字数は 1 以上で入力してください<br />'."\n";
			}
			if ($post['ip_interval'] < 30 || $post['ip_interval'] > 1440) {
				$error .= 'IP 間隔は 30 ~ 1440 分の間で入力してください<br />'."\n";
			}
			if ($post['create_interval'] < 60 || $post['create_interval'] > 1440) {
				$error .= 'ランキング生成間隔は 60 ~ 1440 分の間で入力してください<br />'."\n";
			}
		} else {
			$set_key = array(
				'admin_user',
				'admin_pass',
			);
			// チェック
			if ($post['admin_user'] != ADMIN_USER || md5($post['admin_pass']) != ADMIN_PASS) {
				$error .= '現在のユーザー名、パスワードが違います<br />'."\n";
			}
			if (!checkEmpty($post['new_user']) || !checkEmpty($post['new_pass'])) {
				$error .= '新しいユーザー名、パスワードが入力されていません<br />'."\n";
			}
		}
		
		if ($error !== null) {
			// 値一時保存
			setSession($post);
			return $error;
		} else {
			$set = ' '.implode(' = ?, ', $set_key).' = ?';
			
			$post['admin_user'] = $post['new_user'];
			$post['admin_pass'] = md5($post['new_pass']);
			$data = $this->toArray($set_key, $post);
		
			$this->db->begin();
			$this->db->update('setting', $set, $data);
			$this->db->commit();
			
			return true;
		}
	
	}
	
	/**
	 * rank.html
	 *
	 * @return void
	 */
	public function rankjs() {
		
		//
		$this->create_date = gmdate("Y-m-d H:i:s", CREATE_TIME);
		
		$str = null;
		switch (RANK_TYPE) {
			case 0:
				$str = '一月 ( 今月のランキングが生成されます )';
				break;
			case 1:
				$start_time = gmdate("Y-m-d H:i:s", RANK_START_TIME);
				$end_time = gmdate("Y-m-d H:i:s", strtotime("+".RANK_DAY." day", RANK_START_TIME));
				$str = '指定日数 : ( '.$start_time.' ～ '.$end_time.' 間のランキング)';
				break;
			case 2:
				$str = '最新 '.RANK_DAY.' 日間のランキングが生成されます';
				break;
		}
		
		$this->now_setting = $str;
		
		$this->i('rank.php');
	
	}
	
	/**
	 * rank.html
	 *
	 * @return void
	 */
	public function createRank() {
		
		$this->access->createRank(true);
		// 不要なデータを削除
		if ($this->access->do_delete) {
			$this->access->deleteAccessLog();
		}
		return true;
	
	}
	
	/**
	 * 生ログ
	 *
	 * @return void
	 */
	public function log() {
		
		// ログ数
		$temp = $this->db->count('access', 'ip');
		$this->cnt = $temp[0];
		
		// 前回削除日
		$this->delete_time = gmdate("Y-m-d H:i:s", DELETE_TIME);
			
		$this->is_log = true;
		if ($this->cnt <= 0) {
		
			$this->is_log = false;
			
		} else {
		
			$this->pagenavi = new PageNavi($this->show_cnt, $this->tpl_dir);
			$this->pagenavi->maxPage($this->cnt);
			list($start, $end) = $this->pagenavi->startEnd_forSQL($this->cnt);
			
			// ログ読み込み
			$this->access = $this->db->select('access', '*', ' order by date desc limit ? offset ?', array(array($end, $start)));
			
		}
		
		$this->i('log.php');
	
	}
	
	/**
	 * 過去のアクセスランキング
	 *
	 * @return void
	 */
	public function oldLog() {
		
		// ディレクトリオープン
		$dir = dir(LOG_FOLDER);

		// 初期化
		$row = 0;
		$this->log_file = array();

		while (($temp = $dir->read()) !== false) {
			// "." と ".." 以外を変数に格納
			if ($temp != "." && $temp != "..") {
				// ファイル名
				$this->log_file[$row]['file'] = mb_convert_encoding($temp, "UTF-8", "SJIS, EUC-JP, JIS, ASCII");
				// 更新日時
				$this->log_file[$row]['date'] = gmdate('Y/m/d(D) H:i:s', filemtime(LOG_FOLDER.$this->log_file[$row]['file']) + 32400);
				$row++;
			}
		}

		// ディレクトリクローズ
		$dir->close();
		
		$this->h1 = '過去のランキングファイル';
		$this->is_readFile = false;
		$readFile = getGet('file');
		if ($readFile != null) {
			if (file_exists(LOG_FOLDER.$readFile)) {
				$this->h1 = $readFile;
				$this->is_readFile = true;
				
				// ファイル読み込み、文字コード変換
				$this->fileContents = file_get_contents(LOG_FOLDER.$readFile);
				$this->fileContents = mb_convert_encoding($this->fileContents, 'UTF-8', CHARACTER_CODE);
			}
		}
		
		$this->i('old_log.php');
	
	}
	
	/**
	 * 過去ログ削除
	 *
	 * @return void
	 */
	public function deleteOldLog() {
	
		// ファイル名
		$files = getPost('files');
		
		$unlink = false;
		if (count($files) > 0) {
			foreach ($files as $file) {
				if (file_exists(LOG_FOLDER.$file)) {
					unlink(LOG_FOLDER.$file);
					$unlink = true;
				}
			}
			
			if ($unlink) {
				return true;
			}
		}
		
		return '指定されたファイルは存在しません';
	
	}
	
	/**
	 * 生ログ削除
	 *
	 * @return void
	 */
	public function deleteLog() {
		
		$time = time() + TIME_ZONE;
		$y = gmdate('Y', $time);
		$m = gmdate('m', $time);
		$d = gmdate('d', $time);
		// 今日の 0 時のタイムスタンプ
		$timestamp = mktime(0, 0, 0, $m, $d, $y);
		
		$this->db->begin();
		$this->db->delete('access');
		// 指定日数の開始日、削除日セット
		$this->db->update('setting', ' rank_start_time = ?, delete_time = ?', array($timestamp, $timestamp));
		$this->db->commit();
		
		$this->db->exec('VACUUM;');
	
	}
	
	/**
	 * ファイル読み込み
	 *
	 * @return void
	 */
	public function i($file) {
	
		include($this->tpl_dir.'/'.$file);
	
	}
	
	/**
	 * ID
	 *
	 * @return mixed
	 */
	public function getEditID() {
		$id = getGet('id');
		if (isInteger($id)) {
			return $id;
		}
		return false;
	}
	
	/**
	 * デストラクタ
	 *
	 * @return void
	 */
	public function __destruct() {
	
		$this->db->disConnect();
	
	}
	
}
