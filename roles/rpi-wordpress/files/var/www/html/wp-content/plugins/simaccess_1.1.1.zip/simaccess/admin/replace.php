<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}
?>
<article>

<h1><span>置換 URL 設定</span></h1>
<?php message(); ?>
<section>
	<h1>置換 URL 追加・編集</h1>
	<form action="./?action=add_repurl" method="post" id="form">
	<dl class="form clearfix">
		<dt>置換元 URL</dt>
		<dd><input type="text" name="ref" id="ref" size="20" placeholder="置換したいアクセス元のURL" value="<?php s('ref'); ?>" /><span>複数は | で区切る　e.g.) www.google.co.jp|www.google.com</span></dd>
		<dt>表示名</dt>
		<dd><input type="text" name="name" id="name" size="20" placeholder="ランキングに表示する際の文字列" value="<?php s('name'); ?>" /><span>e.g.) Google</span></dd>
		<dt>置換 URL</dt>
		<dd><input type="url" name="url" id="url" size="20" placeholder="置き換えるURL" value="<?php s('url'); ?>" /><span>e.g.) http://www.google.co.jp/</span></dd>
	</dl>
	<p class="button submit">
		<input type="hidden" name="redirect" value="./?mode=rep" />
		<input type="hidden" name="id" id="id" value="0" />
		<input type="submit" value="追加" name="submit" id="submit" />
	</p>
	</form>
</section>

<section>
	<h1>置換 URL リスト</h1>
	<form action="./?action=del_repurl" method="post" name="del_form" id="del_form">
	<table>
		<colgroup span="1" style="width: 70px;"></colgroup>
		<colgroup span="1"></colgroup>
		<colgroup span="1" style="width: 150px;"></colgroup>
		<colgroup span="1" style="width: 200px;"></colgroup>
		<colgroup span="1" style="width: 60px;"></colgroup>
		<colgroup span="1" style="width: 60px;"></colgroup>
		<thead>
		<tr>
			<th>ID</th>
			<th>置換元</th>
			<th>表示名</th>
			<th>置換 URL</th>
			<th>編集</th>
			<th>削除</th>
		</tr>
		</thead>
		<tbody>
		<?php foreach ($this->replace as $key => $value) : ?>
		<tr>
			<td><input type="checkbox" name="id[]" id="ch<?php e($value['id']); ?>" value="<?php e($value['id']); ?>" onclick="checkbox(this);" /><label for="ch<?php e($value['id']); ?>"> <?php e($value['id']); ?></label></td>
			<td id="ref_<?php e($value['id']); ?>"><?php e($value['ref']); ?></td>
			<td id="name_<?php e($value['id']); ?>"><?php e($value['name']); ?></td>
			<td id="url_<?php e($value['id']); ?>"><a href="<?php e($value['url']); ?>"><?php e($value['url']); ?></a></td>
			<td><a href="#header" class="actionlink" onclick="repULREdit('<?php e($value['id']); ?>');">編集</a></td>
			<td><a href="#" class="actionlink" onclick="return checkSubmit('ch<?php e($value['id']); ?>', 'del_form');">削除</a></td>
		</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<p class="button">
		<input type="hidden" name="redirect" value="./?mode=rep" />
		<input type="checkbox" name="chall" id="chall" onclick="check_all(this);" /> <label for="chall">すべて選択</label>
		<input type="submit" value="削除" onclick="return conf('チェックしたURLを削除してもよろしいですか？');" />
	</p>
	</form>
</section>

<?php if (isMode('rep_edit')) : ?>
<script>
<!--
repULREdit(<?php echo $this->getEditID(); ?>);
-->
</script>
<?php endif; ?>

</article>
