jQuery(document).ready(function($) {
	//color picker
    var f = $.farbtastic('#picker');
    var p = $('#picker').css('opacity', 0.25);
    var selected;
    $('.colorwell').each(function () { f.linkTo(this); $(this).css('opacity', 0.75); }).focus(function() {
        if (selected) { $(selected).css('opacity', 0.75).removeClass('colorwell-selected'); }
        f.linkTo(this);
        p.css('opacity', 1);
        $(selected = this).css('opacity', 1).addClass('colorwell-selected');
    });
    $('.colorwell').click(function() {
		var position = $(selected = this).position();
    	$('#picker').css('left', (position.left + 150) );
    	$('#picker').css('top', position.top); 
    	$('#picker').fadeIn(900,function (){
    		$('#picker').css('display', 'inline');
	    });
	}).blur(function(){
    	  $('#picker').fadeOut('fast');
    	  $('#picker').css('display', 'none');
    });

	//image button upload - thanks Brad Williams, Ozh Richard, and Justin Tadlock!
	var formfield = null;
	
	$('#upload_image_button').click(function() {
		$('html').addClass('Image');
		formfield = $('#category-image').attr('name');
		tb_show('', 'media-upload.php?type=image&TB_iframe=true');
		return false;
	});
	
	// user inserts file into post. only run custom if user started process using the above process
	// window.send_to_editor(html) is how wp would normally handle the received data
	window.original_send_to_editor = window.send_to_editor;
	window.send_to_editor = function(html){
	    var fileurl;

		if (formfield != null) {
			var img = $(html).find('img');
			fileurl = img.attr('src');
			$('#category-image').val(fileurl);
			$('#category-image-img img').attr('src', fileurl);
			//get the attachment id if possible
			var fileIdClass = img.attr('class');
			var pattern = /wp\-image\-[0-9]+/;
			var fileIdFull = pattern.exec(fileIdClass);
			if( fileIdFull[0] != '' ){
				var fileId = fileIdFull[0].replace('wp-image-','');
				$('#category-image-id').val(fileId);
			}			

			tb_remove();

			$('html').removeClass('Image');
			formfield = null;
		} else {
			window.original_send_to_editor(html);
		}
	};
	
	//detach/remove image from category for saving
	$('#delete_image_button').on('click', function(){
		$('#category-image-img').remove();
		$('#category-image, #category-image-id').val('');
	}); 
});