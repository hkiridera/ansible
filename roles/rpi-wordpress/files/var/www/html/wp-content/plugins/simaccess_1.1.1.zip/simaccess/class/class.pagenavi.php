<?php

class PageNavi
{
	/**
	 * コンストラクタ
	 *
	 * @return void
	 */
	function __construct($cnt, $tpl) {
	
		$this->show_cnt = $cnt;
		$this->tpl_dir = $tpl;
	
	}
	
	/**
	 * 
	 *
	 * @return string
	 */
	function getKey() {
	
		$get = '';
		
		if (isset($_GET)) {
		
			foreach ($_GET as $key => $value) {
				if ($key != 'ac' && $key != 'key' && $key != 'p') {
					$get .= h($key).'='.h($value).'&';
				}
			}
		
		}
		
		$get = rtrim($get, '&');
		
		return $get;
	
	}
	
	/**
	 * ページ遷移
	 *
	 * @return void
	 */
	function pageNavi() {
		
		if ($this->maxpage > 1) {
		
			$get = $this->getKey();
			$self = h($_SERVER['PHP_SELF']);
			
			include( $this->tpl_dir . '/pagenavi.php');
		}
	
	}
	
	/**
	 * 最大ページ数を求める
	 *
	 * @return void
	 */
	function maxPage($row) {
		
		$this->maxpage = $row / $this->show_cnt;
		$temp = (int)$this->maxpage;
		if($this->maxpage > $temp) {
			$this->maxpage = $temp + 1;
		}
	
	}
	
	/**
	 * ページ番号からスタートとエンドを取得
	 *
	 * @return array
	 */
	function startEnd($row) {
		
		$this->p = 1;
		if (isset($_GET['p']) && $_GET['p'] > 0) {
			$this->p = $_GET['p'];
		}
		
		$start = 0;
		$end = 0;
		
		$start = ($this->p-1) * $this->show_cnt; 
		$end   = $this->p * $this->show_cnt;
		if ($end > $row) {
			$end = $row;
		}
		
		return array($start, $end);
		
	}
	
	/**
	 * ページ番号からスタートとエンドを取得
	 *
	 * @return array
	 */
	function startEnd_forSQL($row) {
		
		$this->p = 1;
		if (isset($_GET['p']) && $_GET['p'] > 0) {
			$this->p = $_GET['p'];
		}
		
		$start = 0;
		$end = 0;
		
		$start = ($this->p-1) * $this->show_cnt; 
		$end   = $this->show_cnt;
		
		return array($start, $end);
		
	}
	
}
