<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}
?>
<article>

<h1><span>設定</span></h1>
<?php message(); ?>
<section class="form">
	<h1>一般設定</h1>
	<form action="./?action=set&type=0" method="post">
	<dl class="form clearfix">
		<dt>ランキング生成方式</dt>
		<dd>
			<input type="radio" name="rank_type" value="0" id="rank_type0" <?php echo ($this->rank_type[0]); ?>/><label for="rank_type0"> 一月</label>
			<input type="radio" name="rank_type" value="1" id="rank_type1" <?php echo ($this->rank_type[1]); ?>/><label for="rank_type1"> 指定日数</label>
			<input type="radio" name="rank_type" value="2" id="rank_type2" <?php echo ($this->rank_type[2]); ?>/><label for="rank_type2"> 最近の○日間</label>
			<span>
			</span>
		</dd>
		
		<dt>計算する日数</dt>
		<dd>
			<input type="number" name="rank_day" value="<?php e(RANK_DAY); ?>" min="1" max="31" />
			<span>指定日数, 最近の○日間 の時のみ有効です</span>
		</dd>
		
		<dt>表示件数</dt>
		<dd>
			<input type="number" name="rank_count" value="<?php e(RANK_COUNT); ?>" min="1" />
			<span>ランキング生成時に表示する最大件数です</span>
		</dd>
		
		<dt>表示最大文字数</dt>
		<dd>
			<input type="number" name="name_length" value="<?php e(NAME_LENGTH); ?>" min="1" />
			<span>置換 URL が設定されていない URL の場合、設定した文字数に切り抜きます</span>
		</dd>
		
		<dt>IP 間隔 ( 分 )</dt>
		<dd>
			<input type="number" name="ip_interval" value="<?php e(IP_INTERVAL); ?>" min="30" max="1440" />
			<span>同一 IP での連続アクセスを保存しない間隔です</span>
		</dd>
		
		<dt>生成間隔 ( 分 )</dt>
		<dd>
			<input type="number" name="create_interval" value="<?php e(CREATE_INTERVAL); ?>" min="60" max="1440" />
			<span>ランキングを生成する間隔です</span>
		</dd>
		
		<dt>文字コード</dt>
		<dd>
			<input type="text" name="character_code" value="<?php e(CHARACTER_CODE); ?>" />
			<span>rank.html で使用する文字コードです。 UTF-8 , EUC-JP , SJIS など</span>
		</dd>
		
		<dt>置換したもののみ表示</dt>
		<dd>
			<input type="radio" name="replace_only" value="0" id="replace_only0" <?php echo ($this->replace_only[0]); ?>/><label for="replace_only0"> すべて表示</label>
			<input type="radio" name="replace_only" value="1" id="replace_only1" <?php echo ($this->replace_only[1]); ?>/><label for="replace_only1"> 置換した URL のみ表示</label>
		</dd>
	</dl>
	<p class="button submit">
		<input type="hidden" name="redirect" value="./?mode=setting" />
		<input type="submit" value="設定更新" />
	</p>
	</form>
</section>

<section class="form">
	<h1>ログイン設定</h1>
	<form action="./?action=set&amp;type=1" method="post">
	<dl class="form clearfix">
		<dt>現在のユーザー名</dt>
		<dd><input type="text" name="admin_user" /></dd>
		
		<dt>現在のパスワード</dt>
		<dd><input type="text" name="admin_pass" /></dd>
		
		<dt>新しいユーザー名</dt>
		<dd><input type="text" name="new_user" /><span>新しく設定したいユーザー名</span></dd>
		
		<dt>新しいパスワード</dt>
		<dd><input type="text" name="new_pass" /><span>新しく設定したいパスワード</span></dd>
	</dl>
	<p class="button submit">
		<input type="hidden" name="redirect" value="./?mode=setting" />
		<input type="submit" value="設定更新" />
	</p>
	</form>
</section>

</article>
