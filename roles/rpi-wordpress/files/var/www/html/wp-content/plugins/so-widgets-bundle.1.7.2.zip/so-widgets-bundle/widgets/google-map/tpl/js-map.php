<div
	class="sow-google-map-canvas"
	style="height:<?php echo intval($height) ?>px;"
	id="map-canvas-<?php echo esc_attr( $map_id ) ?>"
	data-options="<?php echo esc_attr( json_encode( $map_data ) ) ?>"
></div>
