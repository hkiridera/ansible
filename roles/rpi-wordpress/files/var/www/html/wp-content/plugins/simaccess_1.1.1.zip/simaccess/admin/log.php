<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}
?>
<article>

<h1><span>生ログ</span></h1>
<?php message(); ?>
<section class="form">
	<h1>生ログ</h1>
	<?php if ($this->is_log) : ?>
	<p>全 <?php e($this->cnt); ?> 件</p>
	<table>
		<colgroup span="1"></colgroup>
		<colgroup span="1" style="width: 160px;"></colgroup>
		<colgroup span="1" style="width: 170px;"></colgroup>
		<thead>
		<tr>
			<th>リンク元 URL</th>
			<th>IP</th>
			<th>アクセス日時</th>
		</tr>
		</thead>
		<tbody>
		<?php foreach ($this->access as $key => $value) : ?>
		<tr>
			<td><a href="<?php e($value['referrer']); ?>"><?php e($value['referrer']); ?></a></label></td>
			<td><?php e($value['ip']); ?></td>
			<td><?php e($value['date']); ?></td>
		</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	
	<?php $this->pagenavi->pageNavi(); endif; ?>
	
</section>

<section>
	<h1>削除</h1>
	<p>
		ログを全て削除します<br />
		現在 <?php e($this->delete_time); ?> より以前のログは削除されています。
	</p>
	<form action="./?action=delete_log" method="post">
	<p class="button">
		<input type="hidden" name="redirect" value="./?mode=log" />
		<input type="submit" value="削除" onclick="return conf('ログを全て削除してもよろしいですか？');" />
	</p>
	</form>
</section>

</article>
