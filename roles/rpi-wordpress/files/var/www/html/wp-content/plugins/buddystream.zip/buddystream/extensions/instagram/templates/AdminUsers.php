<?php
$buddystream_extension = "instagram";
include(BP_BUDDYSTREAM_DIR.'/extensions/default/templates/AdminUsers.php');