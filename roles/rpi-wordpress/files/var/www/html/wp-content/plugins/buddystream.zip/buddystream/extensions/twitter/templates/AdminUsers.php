<?php
$buddystream_extension = "twitter";
include(BP_BUDDYSTREAM_DIR.'/extensions/default/templates/AdminUsers.php');