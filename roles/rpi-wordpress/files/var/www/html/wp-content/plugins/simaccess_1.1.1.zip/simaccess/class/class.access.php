<?php

require_once( dirname(__FILE__). '/class.db.php');
require_once( dirname(__FILE__). '/class.common.php');

class Access extends Common
{
	/**
	 * コンストラクタ
	 *
	 * @return void
	 */
	public function __construct() {
	
		parent::__construct();
		
		$this->db = new DB();
		$this->db->connect('access.sqlite');
		
		// 設定読み込み
		$this->readSetting();
		
		date_default_timezone_set('UTC');

		$this->time = time() + TIME_ZONE;
		$this->rank_file = RANK_FILE;
		$this->do_delete = false;
		$this->replace_only = REPLACE_ONLY;

	}
	
	/**
	 * IP アドレスチェック
	 * 指定間隔内の同一 IP によるアクセスかどうか調べる
	 *
	 * @return string
	 */
	private function checkIP() {

		// IP
		$ip = $_SERVER["REMOTE_ADDR"];
	
		// 日付 ( 指定した間隔 ( 分 ) 前の日付 )
		$date = gmdate("Y-m-d H:i:s", $this->time - IP_INTERVAL * 60);

		// アクセスがあったら
		$ret = $this->db->count('access', 'ip', ' where date >= datetime("'.$date.'") and ip = "'.$ip.'"');
		if ($ret[0] > 0) {
			return false;
		}
		
		return $ip;
		
	}
	
	/**
	 * アクセスデータ書き込み
	 *
	 * @return void
	 */
	public function accessProcess() {
	
		$info = array();
		
		// リファラ取得
		$info['referrer'] = mb_convert_encoding($_GET['referrer'], "UTF-8", "UTF-8,EUC-JP,SJIS,JIS,ASCII");
		
		// IP チェック
		if (($info['ip'] = $this->checkIP()) === false) return;
		// 日付
		$info['date'] = gmdate("Y-m-d H:i:s", $this->time);
		
		$keys = array(
			'ip' => PDO::PARAM_STR,
			'referrer' => PDO::PARAM_STR,
			'date'	=> PDO::PARAM_STR
		);
		
		$data = array();
		$data[0] = $this->toPrepareArray($keys, $info);
		
		$this->db->begin();
		$this->db->insert('access', $data);
		$this->db->commit();
		
		// ランキング生成
		$this->createRank();
	
		// 不要なデータを削除
		if ($this->do_delete) {
			$this->deleteAccessLog();
		}
		
	}
	
	/**
	 * ランキング生成
	 *
	 * @return array
	 */
	public function createRank($create = false, $rank_all = false, $start = null, $end = null) {
	
		$interval = CREATE_INTERVAL * 60;
		// 指定時間経っていない場合はランキングを生成しない
		if (CREATE_TIME + $interval >= $this->time && !$create) {
			return;
		}
		
		// リファラチェック、削除
		$this->denyURLDelete();
	
		list($url, $name, $count) = $this->rankProcess($start, $end);
		
		// 表示件数
		$cnt = count($url);
		$loop = ($cnt < RANK_COUNT) ? $cnt : RANK_COUNT;
		if ($rank_all) {
			$loop = $cnt;
		}
		
		// 0件の場合は作成しない
		if ($cnt <= 0) {
			return;
		}
		
		// 以下の HTML 部分を編集
		// 始まりに表示する部分です
		$html = '<ol class="ranking">';
		// ここまで
		
		$rank = 0;
		$rank_temp = 1;
		$prev_rank = 0;
		$prev_count = -1;
		for ($i = 0; $i < $loop; $i++) {
		
			if ($count[$i] == $prev_count) {
				$rank = $prev_rank;
				$rank_temp++;
			} else {
				$rank = $prev_rank + $rank_temp;
				$rank_temp = 1;
			}
			
			// 以下の HTML 部分を編集
			// ループ部分です。ランキングの数だけ繰り返されます。
			/*
			$rank		: 順位
			$url[$i]	: アクセス元の URL
			$name[$i]	: 表示する文字列
			$count[$i]	: アクセス数
			*/
			$html .= '
			<li><span>'.$rank.'</span><a href="'.$url[$i].'" title="'.$name[$i].'">'.$name[$i].'</a></li>';
			// ここまで
			
			$prev_rank = $rank;
			$prev_count = $count[$i];
		
		}
		
		// 以下の HTML 部分を編集
		// 終に表示する部分です。
		$html .= '</ol>';
		// ここまで
		
		$html = str_replace(array("\r\n", "\r", "\n", "\t"), '', $html);
		// 文字コード変換
		$html = mb_convert_encoding($html, CHARACTER_CODE, 'UTF-8,JIS,EUC-JP,SJIS,sjis-win,ASCII');
		
		$handle = fopen($this->rank_file, 'w');
		fwrite($handle, $html);
		fclose($handle);
		
		// 生成時間を格納
		$this->db->begin();
		$this->db->update('setting', 'create_time = ?', array($this->time));
		$this->db->commit();
	
	}
	
	/**
	 * ランキング計算
	 *
	 * @return array
	 */
	public function rankProcess($start = null, $end = null) {
	
		if ($start === null && $end === null) {
			list($start, $end) = $this->getRankingDate();
		}
		return $this->ranking($start, $end);
		
	}
	
	/**
	 * ランキングを生成する期間を取得
	 *
	 * @return array
	 */
	private function getRankingDate() {
		
		// 今日の年月
		$y = gmdate('Y', $this->time);
		$m = gmdate('m', $this->time);
		$d = gmdate('d', $this->time);
				
		// 生成方法によって分ける
		switch (RANK_TYPE) {
			case 0:
				// 月はじめのタイムスタンプ
				$start_timestamp = mktime(0, 0, 0, $m, 1, $y);
				// 月終わりのタイムスタンプ
				$end_timestamp = strtotime("+1 month", $start_timestamp);
				$start = gmdate("Y-m-d H:i:s", $start_timestamp);
				$end = gmdate("Y-m-d H:i:s", $end_timestamp);
				
				// 月が変わってれば削除する
				if ((gmdate('m', DELETE_TIME)) != $m) {
					$this->do_delete = true;
					$this->delete_timestamp = $start_timestamp;
				}
				
				break;
			case 1:
				$start = gmdate("Y-m-d H:i:s", RANK_START_TIME);
				$end = gmdate("Y-m-d H:i:s", strtotime("+".RANK_DAY." day", RANK_START_TIME));
				
				// 前回削除から、RANK_DAY 以上経っていたら削除する
				if ((DELETE_TIME + RANK_DAY * 86400) - $this->time < 0) {
					$timestamp = mktime(0, 0, 0, $m, $d, $y);
					$this->do_delete = true;
					$this->delete_timestamp = $timestamp;
				}

				break;
			case 2:
				$start = gmdate("Y-m-d H:i:s", strtotime("-".RANK_DAY." day", $this->time));
				$end = gmdate("Y-m-d H:i:s", $this->time);
				
				// 前回削除から、RANK_DAY 以上経っていたら削除する
				if ((DELETE_TIME + RANK_DAY * 86400) - $this->time < 0) {
					$timestamp = strtotime("-".RANK_DAY." day", $this->time);
					// 指定日数前の0時0分0秒
					$y = gmdate('Y', $timestamp);
					$m = gmdate('m', $timestamp);
					$d = gmdate('d', $timestamp);
					$timestamp = mktime(0, 0, 0, $m, $d, $y);
					$this->do_delete = true;
					$this->delete_timestamp = $timestamp;
				}
				
				break;
			default:
				break;
		}
		
		return array($start, $end);
			
	}
	
	/**
	 * ランキング計算
	 *
	 * @return array
	 */
	private function ranking($start, $end) {
		
		// 置換する URL
		$ret_rep = $this->db->select('replace', 'ref, url, name');
		
		$where = ' where date >= datetime(?) and date < datetime(?) group by referrer';
		$prepare = array(array($start, $end));
		if ($start === null) {
			$where = ' where date < datetime(?) group by referrer';
			$prepare = array(array($end));
		}
		
		$ret = $this->db->select('access', 'count(referrer), referrer, date', $where, $prepare);
		if (count($ret) <= 0) {
			return;
		}
		
		/*	// old code
		$where = ' where date >= datetime(?) and date < datetime(?)';
		$prepare = array(array($start, $end));
		if ($start === null) {
			$where = ' where date < datetime(?)';
			$prepare = array(array($end));
		}
		
		$ret = $this->db->select('access', 'referrer, date', $where, $prepare);
		if (count($ret) <= 0) {
			return;
		}
		*/
		
		// URL 取得
		$row = 0;
		$url = array();
		$name = array();
		$count = array();
		$cnt_replace = (count($ret_rep) > 0) ? true : false;
		foreach ($ret as $access) {
		
			// URL 置換
			$is_find = false;
			if ($cnt_replace) {
				foreach ($ret_rep as $replace) {
					// リファラ置換のため分割
					$ref = array();
					$ref = explode("|", $replace['ref']);
					$cnt_ref = count($ref);
					for ($i = 0; $i < $cnt_ref; $i++) {
						if (stristr($access['referrer'], $ref[$i]) !== false) {
							$access['referrer'] = $replace['url'];
							$access['name'] = $replace['name'];
							$is_find = true;
							break;
						}
					}
				}
			}
			
			if (($key = array_search($access['referrer'], $url)) !== false) {
				// カウントアップ
				//$count[$key]++;	// old code
				$count[$key] += $access['count(referrer)'];
			} else {
				if ($is_find) {
					$name[$row] = $access['name'];
				} else {
					$name[$row] = mb_substr($access['referrer'], 0, NAME_LENGTH, 'UTF-8').' …';
				}
				// 新規追加
				$url[$row] = $access['referrer'];
				//$count[$row] = 1;	// old code
				$count[$row] = $access['count(referrer)'];
				if (!$is_find && $this->replace_only) {
					unset($name[$row], $url[$row], $count[$row]);
				} else {
					$row++;
				}
			}
			
		}
		
		// カウント順にソート
		array_multisort($count, SORT_DESC, $name, SORT_ASC, $url);
		
		return array($url, $name, $count);
		
	}
	
	/**
	 * 拒否 URL 削除
	 *
	 * @return void
	 */
	public function denyURLDelete() {
			
		// 拒否 URL リスト取得
		$ret = $this->db->select('deny_url', 'url');
		if (count($ret) > 0) {
			$this->db->begin();
			foreach ($ret as $url) {
				// SQL
				$url = '%'.str_replace('%', '|%', $url['url']).'%';
				$sql = "delete from access where referrer like '".$url."' escape '|'";
				$this->db->exec($sql);
			}
			$this->db->commit();
			$this->db->exec('VACUUM;');
		}
		
	}
	
	/**
	 * 古いアクセスログを削除
	 *
	 * @return void
	 */
	public function deleteAccessLog() {
	
		// 保存ファイル名
		$filename = gmdate("Y-m-d", $this->delete_timestamp).'.html';
		$end = gmdate("Y-m-d H:i:s", $this->delete_timestamp);
		
		// ランキング生成
		$this->rank_file = LOG_FOLDER.$filename;
		$this->replace_only = 0;
		$this->createRank(true, true, null, $end);
		
		// 古いデータを削除
		$this->db->begin();
		$this->db->delete('access', ' where date < datetime("'.$end.'")');
		
		$y = gmdate('Y', $this->time);
		$m = gmdate('m', $this->time);
		$d = gmdate('d', $this->time);
		// 今日の 0 時のタイムスタンプ
		$timestamp = mktime(0, 0, 0, $m, $d, $y);
		$this->db->update('setting', 'delete_time = ?, rank_start_time = ?', array($this->delete_timestamp, $timestamp));
		
		$this->db->commit();
		
		$this->db->exec('vacuum;');
	
	}
	
	/**
	 * 設定読み込み
	 *
	 * @return void
	 */
	private function readSetting() {
		
		$sql = 'select * from setting';
		$temp = $this->db->query($sql, PDO::FETCH_ASSOC);
		$ret = $temp[0];
		
		foreach ($ret as $key => $value) {
			define(strtoupper($key), $value);
		}
		
	}
		
	/**
	 * デストラクタ
	 *
	 * @return void
	 */
	public function __destruct() {

		$this->db->disConnect();
	
	}
	
}
