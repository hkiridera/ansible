<?php
$buddystream_extension = "lastfm";
include(BP_BUDDYSTREAM_DIR.'/extensions/default/templates/AdminUsers.php');