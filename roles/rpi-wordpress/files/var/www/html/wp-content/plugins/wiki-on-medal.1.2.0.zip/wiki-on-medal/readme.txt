=== Wiki on Medal ===
Contributors: Piotr Pesta
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=EEDF5TV3M2WVG&lc=US
Plugin Name: Wiki on Medal
Plugin URI: http://smartfan.pl/
Tags: widget, wikipedia, article on medal, wikipedia widget, featured article
Author: Piotr Pesta
Requires at least: 2.8.0
Tested up to: 4.3
Stable tag: 1.2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Wiki on Medal is a widget that lets your visitors to see article on medal (featured article) from Wikipedia.

== Description ==

Wiki on Medal is a widget that lets your visitors to see article on medal (featured article) from Wikipedia. Supported languages so far: Deutsch, Polish, English. More languages in the future.

If you would like to show your support for this software, please consider donating: [Donate via PayPal](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=EEDF5TV3M2WVG&lc=US).

== Installation ==

1. Upload the zip to 'plugins' directory
2. Unzip (steps 1 and 2 cand also be performed automatically)
3. Activate the plugin
4. Configure and place the widget on your sidebar

Or just add .zip file as a new plugin in your Wordpress administration panel.

== Screenshots ==

1. Wiki on Medal on right block.

== Changelog ==
= 1.2.0 =
* Caching support (5 hours refresh)
* Minor bug fix for polish lang
= 1.1.1 =
* Wordpress 4.3 compatibility
= 1.1.0 =
* Bugfix - widget works again
= 1.0.1 =
* 4.1 Wordpress version compatibility
= 1.0.0 =
* Initial Release