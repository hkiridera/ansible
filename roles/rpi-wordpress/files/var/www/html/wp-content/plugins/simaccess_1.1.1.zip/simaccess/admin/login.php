<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}
?>
<article>

<h1><span>ログイン</span></h1>
<?php message(); ?>
<section class="form" style="margin-top: 10px;">
	<form action="./?action=login" method="post">
	<dl class="form clearfix">
		<dt>ユーザー名</dt>
		<dd><input type="text" name="user" value="" placeholder="ユーザー名を入力してください" autofocus="autofocus" /></dd>
		
		<dt>パスワード</dt>
		<dd><input type="password" name="pass" value="" placeholder="パスワードを入力してください" /></dd>
		
	</dl>
	<p class="button submit">
		<input type="submit" value="ログイン" />
	</p>
	</form>
</section>

</article>
