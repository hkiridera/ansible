<?php

	require( plugin_dir_path( __FILE__ ) . 'inc/config.php' );
	require( plugin_dir_path( __FILE__ ) . 'inc/adminOptionsValidator.php' );
	require( plugin_dir_path( __FILE__ ) . 'inc/adminSanitizer.php' );
	require( plugin_dir_path( __FILE__ ) . 'inc/render.php' );
	require( plugin_dir_path( __FILE__ ) . 'inc/loader.php' );
