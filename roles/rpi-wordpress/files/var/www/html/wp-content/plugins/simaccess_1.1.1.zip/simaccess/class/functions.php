<?php

session_start();

/**
 * echo
 *
 * @return void, string
 */
function e($data, $return = false, $br = true) {

	if (isset($data)) {
		$data = h($data);
		if ($br) {
			$data = nl2br($data);
		}
		// 数値文字参照はもとに戻す
		//$data = preg_replace("/(&amp;)(#[0-9]+;)/", "\2", $data);
	}
	
	if ($return) {
		return $data;
	} else {
		echo $data;
	}
	
}

function v($str) {
	echo '<pre>';
	var_dump($str);
	echo '</pre>';
}

/**
 * 文字列エンコード
 *
 * @return void
 */
function h($str) {
	return htmlspecialchars($str, ENT_QUOTES);
}

/**
 * セッション出力
 *
 * @return void
 */
function s($key = null) {
	
	if (isset($_SESSION[$key])) {
		e($_SESSION[$key]);
		unset($_SESSION[$key]);
	}
	
}

/**
 * セッションに値セット
 */
function setSession($value, $key = 'value') {
	if (is_array($value) && count($value) > 0) {
		foreach ($value as $key => $val) {
			$_SESSION[$key] = $val;
		}
	} else {
		$_SESSION[$key] = $value;
	}
}

/**
 * メッセージをセット
 */
function setMessage($str, $class = 'msg') {
	$_SESSION['message'] = '<span class="'.$class.'">'.$str.'</span>';
}

/**
 * メッセージ表示
 */
function message() {
	if (isset($_SESSION['message'])) {
		echo '<p class="message">'.$_SESSION['message'].'</p>';
		unset($_SESSION['message']);
	}
}

/**
 * エラー
 */
function error($str = null) {
	if ($str !== null) {
		setMessage($str, 'error');
	}
}

/**
 * GET 値取得
 *
 * @return array
 */
function getGet($key = null) {

	return dataFormat($_GET, $key);

}

/**
 * POST 値取得
 *
 * @return array
 */
function getPost($key = null) {

	return dataFormat($_POST, $key);

}

/**
 *
 */
function dataFormat($data, $key = null) {

	if ($key !== null) {
		if (isset($data[$key])) {
			return $data[$key];
		} else {
			return null;
		}
	} else {
		return $data;
	}

}

/**
 * モード取得
 * GET 値優先
 *
 * @return array
 */
function getMode() {

	if (($tmode = getGet('mode')) !== null) {
		$mode = $tmode;
	} else if (($tmode = getPost('mode')) !== null) {
		$mode = $tmode;
	} else {
		$mode = null;
	}

	return $mode;
}

/**
 * モードチェック
 *
 * @return bool
 */
function isMode($mode = '') {
	if (getMode() == $mode) {
		return true;
	}
	return false;
}

/**
 * 数値チェック
 *
 * @return bool
 */
function isInteger($str) {

	return (preg_match("/^[0-9]+$/", $str)) ? true : false;

}

/**
 * 半角英数チェック
 *
 * @return bool
 */
function isAlphanumeric($str) {

	return (preg_match("/^[a-zA-Z0-9]+$/", $str)) ? true : false;

}

/**
 * 簡易URLチェック
 *
 * @return bool
 */
function isURL($str) {

	if (isset($str) && $str != '') {
		if (preg_match('/^(https?|ftp)(:\/\/[-_.!~*\'()a-zA-Z0-9;\/?:\@&=+\$,%#]+)$/', $str)) {
			return true;
		} else {
			return false;
		}
	}
	
	return false;

}

/**
 * 簡易URLチェック ( プロトコルなし )
 *
 * @return bool
 */
function isURLStr($str) {

	if (isset($str) && $str != '') {
		if (preg_match('/^[-_.!~*\'()a-zA-Z0-9;\/?:\@&=+\$,%#]+$/', $str)) {
			return true;
		} else {
			return false;
		}
	}
	
	return false;

}

/**
 * 文字数チェック
 *
 * @return bool
 */
function strLength($str, $str_count = 50) {

	return (mb_strlen($str, 'UTF-8') <= $str_count) ? true : false;

}

/**
 * 未入力チェック
 *
 * @return bool
 */
function checkEmpty($str) {

	if (!($str == '' || strlen($str) <= 0)) {
		return true;
	}
	
	return false;

}

/**
 * 禁止文字のチェック
 *
 * @return bool
 */
function checkNGWord($str, $ng_word = array()) {

	$temp = explode("|", trim($ng_word));
	foreach ($temp as $value) {
		foreach ($str as $string) {
			if (stristr($string, $value) !== false) {
			
				return false;
				
			}
		}
	}
	
	return true;
	
}

