<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}
?>
<article>

<h1><span>現在のランキングファイル</span></h1>
<?php message(); ?>
<section>
	<h1>rank.html</h1>
	<?php include(RANK_FILE); ?>
</section>

<section class="form">
	<h1>更新</h1>
	<form action="./?action=create_rank" method="post">
	<dl class="form clearfix">
		<dt>ファイル更新日</dt>
		<dd><?php e($this->create_date); ?></dd>
		<dt>現在の設定</dt>
		<dd><?php e($this->now_setting); ?></dd>
	</dl>
	<p class="button submit">
		<input type="hidden" name="redirect" value="./?mode=rank" />
		<input type="submit" value="ランキング更新" />
	</p>
	</form>
</section>

</article>
