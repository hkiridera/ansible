<?php

require_once( dirname(__FILE__). '/class.common.php');

class Login
{
	/**
	 * コンストラクタ
	 *
	 * @return void
	 */
	public function __construct($action) {
		
		$this->common = new Common();
		
		if ($action === 'login') {
		
			$this->login();
			
		} else if ($action === 'logout') {
		
			$this->logout();
			
		}
		
	}
	
	/**
	 * ログイン
	 *
	 * @return void
	 */
	public function login() {
	
		$post = getPost();
		
		$input_user = $post['user'];
		$input_pass = md5($post['pass']);
		
		if ($input_user === ADMIN_USER && $input_pass === ADMIN_PASS) {
			$_SESSION['admin'.$input_user] = $input_pass;
		} else {
			error('ユーザー名もしくはパスワードが違います');
		}
		
		$this->common->redirect($this->common->referer);
		
	}
	
	/**
	 * ログイン確認
	 *
	 * @return bool
	 */
	public function isLogin() {
	
		if (isset($_SESSION['admin'.ADMIN_USER]) && $_SESSION['admin'.ADMIN_USER] === ADMIN_PASS) {
			return true;
		}
		
		return false;
		
	}
	
	/**
	 * ログアウト
	 *
	 * @return void
	 */
	public function logout() {
	
		if (isset($_SESSION['admin'.ADMIN_USER])) {
			unset($_SESSION['admin'.ADMIN_USER]);
		}
		
		setMessage('ログアウトしました');
		$this->common->redirect('./');
		
	}

	/**
	 * デストラクタ
	 *
	 * @return void
	 */
	public function __destruct() {
	}
	
}
