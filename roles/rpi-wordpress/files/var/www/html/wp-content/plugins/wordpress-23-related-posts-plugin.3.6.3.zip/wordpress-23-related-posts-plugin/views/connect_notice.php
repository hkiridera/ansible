<div id="wp-rp-message" class="updated wp-rp-connect">
	<div id="wp-rp-dismiss">
		<a id="wp-rp-close-button"></a>
	</div>
	<div id="wp-rp-wrap-container">
		<div id="wp-rp-connect-wrap">
			<a id="wp-rp-login" href="<?php echo admin_url('admin.php?page=wordpress-related-posts&ref=turn-on-rp'); ?>">Turn on</a>
		</div>
		<div id="wp-rp-text-container">
			<h4>WordPress Related Posts are almost ready,</h4>
			<h4>now all you need to do is connect to our service.</h4>
		</div>
	</div>
	<div id="wp-rp-bottom-container">
		<p>By turning on Related Posts you agree to <a href="http://www.sovrn.com/editorial-network-terms-of-service/" target="_blank">terms of service.</a></p>
		<p>You'll get Advanced Settings, Themes, Thumbnails and Analytics Dashboard. These features are provided by <a target="_blank" href="http://www.sovrn.com">Sovrn</a> as a service.</p>
	</div>
</div>
