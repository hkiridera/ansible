
function conf(str) {
	return window.confirm(str);
}

// ランキング URL 削除
function deleteRanking(del_num) {
	var form = document.getElementById('form');
	form.elements['url'].value = document.getElementById('url_' + del_num).value;
	if (conf(form.elements['url'].value + '\nをランキングから削除してもよろしいですか？')) {
		form.submit();
	}
	return false;
}

// 拒否 URL 設定
function denyULREdit(denyid) {
	var form = document.getElementById('form');
	form.action = './?action=edit_denyurl';
	form.elements['submit'].value = '編集';
	form.elements['id'].value = denyid;
	form.elements['url'].value = getContent(document.getElementById('url_' + denyid));
	return false;
}

// 置換 URL 設定
function repULREdit(repid) {
	var form = document.getElementById('form');
	form.action = './?action=edit_repurl';
	form.elements['submit'].value = '編集';
	document.getElementById('id').value = repid;
	
	form.elements['ref'].value = getContent(document.getElementById('ref_' + repid));
	form.elements['name'].value = getContent(document.getElementById('name_' + repid));
	form.elements['url'].value = getContent(document.getElementById('url_' + repid));
	
	return false;
}

function getContent(obj) {
	if (typeof obj.textContent != "undefined") {
		return obj.textContent;
	} else {
		return obj.innerText;
	}
}

//
function checkSubmit(id, form) {
	if (conf('削除してもよろしいですか？')) {
		for (var i = 0; i < document.forms[form].elements.length; i++) {
			if (document.forms[form].elements[i].type == 'checkbox') {
				document.forms[form].elements[i].checked = false;
			}
		}
		document.getElementById(id).checked = true;
		document.forms[form].submit();
	}
	return false;
}

// 全て選択
function check_all(obAll) {
	for (var i = 0; i < document.del_form.length; i++) {
		if (document.del_form[i].type == "checkbox") {
			document.del_form[i].checked = obAll.checked;
		}
	}
}

// 全て選択以外のチェックボックスの処理
function checkbox(obCh) {
	if (obCh.checked == false) {
		document.del_form.chall.checked = false;
		return;
	}
	
	for (var i = 0; i < document.del_form.length; i++) {
		// チェックボックスなら
		if (document.del_form[i].type == "checkbox") {
			// 全て選択以外のチェックボックスに選択されていないものがあったら
			if (document.del_form[i].checked == false && document.del_form[i].name != "chall") {
				return;
			}
		}
	}
	// 全て選択をチェックする
	document.del_form.chall.checked = true;
}


