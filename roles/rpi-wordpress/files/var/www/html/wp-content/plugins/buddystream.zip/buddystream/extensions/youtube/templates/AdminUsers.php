<?php
$buddystream_extension = "youtube";
include(BP_BUDDYSTREAM_DIR.'/extensions/default/templates/AdminUsers.php');