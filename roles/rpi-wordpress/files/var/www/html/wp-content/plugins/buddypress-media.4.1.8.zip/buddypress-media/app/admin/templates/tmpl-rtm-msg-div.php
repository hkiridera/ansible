<div class="{{data.class}}" id="{{data.id}}">
	<p>{{data.msg}}</p>
</div>