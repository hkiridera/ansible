<?php

require_once( dirname(__FILE__). '/functions.php');

class Common
{
	/**
	 * コンストラクタ
	 *
	 * @return void
	 */
	public function __construct() {
		
		if (isset($_SERVER['HTTP_REFERER'])) {
			$this->referer = h($_SERVER['HTTP_REFERER']);
		}
		
		$this->show_cnt = 20;
	
	}
	
	/**
	 * 計測開始
	 *
	 * @return void
	 */
	public function measureStart() {
	
		list($msec, $sec) = explode(" ", microtime());
		$this->time_start = (float)$sec + (float)$msec;
	
	}
	
	/**
	 * 計測終了
	 *
	 * @return void
	 */
	public function measureEnd() {
	
		list($msec, $sec) = explode(" ", microtime());
		$this->time_end = (float)$sec + (float)$msec;

		// 時間表示
		printf("time : %0.4f sec", $this->time_end - $this->time_start);
	
	}
		
	/**
	 * 
	 *
	 * @return array
	 */
	public function toPrepareArray($keys, $arr_data) {
	
		$i = 0;
		$values = array();
		
		foreach ($keys as $key => $value) {
			$values[$i]['data'] = isset($arr_data[$key]) ? $arr_data[$key] : null;
			$values[$i]['type'] = $value;
			$i++;
		}
		
		return $values;
	
	}
	
	/**
	 * 
	 *
	 * @return array
	 */
	public function toArray($keys, $arr_data) {
	
		$i = 0;
		$values = array();
		
		foreach ($keys as $key) {
			$values[$i] = isset($arr_data[$key]) ? $arr_data[$key] : null;
			$i++;
		}
		
		return $values;
	
	}
	
	/**
	 * リダイレクト
	 *
	 * @return void
	 */
	public function redirect($url = null) {
		
		if ($url === null) {
			if (isset($_POST['redirect']) && $_POST['redirect'] != '') {
				$url = 'http://'.$_SERVER['HTTP_HOST'];
				$url .= rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				$url .= '/'.h($_POST['redirect']);
			} else {
				die('ERROR');
			}
		}
		
		header ("Location: {$url}");
		die();
	
	}
	
}
