<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sim Access</title>
	<!--[if lt IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<link rel="stylesheet" type="text/css" href="./admin/style.css">
	<script type="text/javascript" src="./admin/js.js"></script>
	<meta name="robots" content="noindex,nofollow">
</head>
<body>

<div id="header_wrap">

	<div id="header">
		
		<header class="clearfix">

			<h1><a href="./"><img src="./admin/images/sim.png" alt="Sim Access" />Sim Access</a></h1>

			<ul class="clearfix">
				<li><a href="./?action=logout">ログアウト</a></li>
			</ul>

		</header>

		<nav id="nav">

			<?php if ($this->mode != 'login') :?>
			<ul class="clearfix">
				<li><a href="./">現在のランキング</a></li>
				<li><a href="./?mode=rep">置換 URL 設定</a></li>
				<li><a href="./?mode=deny">拒否 URL 設定</a></li>
				<li><a href="./?mode=log">生ログ</a></li>
				<li><a href="./?mode=old_log">過去のランキング</a></li>
				<li><a href="./?mode=rank">ランキングファイル</a></li>
				<li><a href="./?mode=setting">設定</a></li>
			</ul>
			<?php endif; ?>

		</nav>
		
	</div>
	
</div>

<div id="wrapper" class="clearfix">

	<?php
	switch ($this->mode) {
	
		case 'login':
			$this->i('login.php');
			break;
			
		case 'setting':
			$this->setting();
			break;
		
		case 'deny':
		case 'deny_edit':
			$this->denyURLSetting();
			break;
			
		case 'rep':
		case 'rep_edit':
			$this->replaceURLSetting();
			break;
			
		case 'log':
			$this->log();
			break;
			
		case 'rank':
			$this->rankjs();
			break;
			
		case 'old_log':
			$this->oldLog();
			break;
			
		default:
			$this->adminRanking();
			break;
	
	}
	?>
	
</div>
	
<footer>

	<?php if ($this->mode != 'login') $this->measureEnd(); ?>
	&nbsp;&nbsp;&nbsp;
	Sim Access by <a href="http://log.noiretaya.com/">Noiretaya</a>

</footer>

</body>
</html>
