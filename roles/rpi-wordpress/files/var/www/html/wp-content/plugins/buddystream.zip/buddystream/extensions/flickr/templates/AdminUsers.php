<?php
$buddystream_extension = "flickr";
include(BP_BUDDYSTREAM_DIR.'/extensions/default/templates/AdminUsers.php');