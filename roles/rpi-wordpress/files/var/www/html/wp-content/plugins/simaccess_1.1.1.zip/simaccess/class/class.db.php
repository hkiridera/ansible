<?php

class DB
{
	/**
	 * SQLite 接続
	 *
	 * @return void
	 */
	public function connect($dbfile) {
	
		$file = dirname(__FILE__).'/../'.$dbfile;
	
		if (!file_exists($file)) {
			die ('Error : DBFile Not Found');
		}
		
		try {
			$this->db = new PDO('sqlite:'.$file);
			$this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		} catch (PDOException $e) {
			die ('Connection failed : '.$e->getMessage());
		}
	
	}
	
	/**
	 * アクセステーブル作成
	 *
	 * @return void
	 */
	public function init() {
		
		/*
		$sql = 'drop table access; drop table deny_url; drop table replace;';
		
		$this->exec($sql);
		$this->exec('VACUUM;');
		
		$sql = '
		create table access (
		ip text,
		referrer text,
		date text
		);';
		
		$this->exec($sql);
		
		$sql = '
		create table deny_url (
		id integer not null primary key autoincrement,
		url text
		);';
		
		$this->exec($sql);
		
		$sql = '
		create table replace (
		id integer not null primary key autoincrement,
		ref text,
		url text,
		name text
		);';
		
		$this->exec($sql);
		*/
		
		$sql = 'drop table setting;';
		$this->exec($sql);
		$this->exec('VACUUM;');
		
		$sql = '
		create table setting (
		time_zone integer not null,
		character_code text not null,
		rank_file text not null,
		rank_type integer not null,
		rank_day integer not null,
		rank_start_time integer not null,
		rank_count integer not null,
		delete_time integer not null,
		name_length integer not null,
		ip_interval integer not null,
		create_interval integer not null,
		create_time integer not null,
		log_folder text not null,
		replace_only integer not null,
		admin_user text not null,
		admin_pass text not null
		);';
		
		$this->exec($sql);
		
		$sql = '
		insert into setting values (
		32400,
		"UTF-8",
		"./rank.html",
		0,
		7,
		0,
		20,
		0,
		15,
		30,
		360,
		0,
		"./log/",
		1,
		"admin",
		"1a1dc91c907325c69271ddf0c944bc72"
		);
		';
		
		$this->exec($sql);
		
		
	}
	
	/**
	 * SQLite 切断
	 *
	 * @return void
	 */
	public function disConnect() {
	
		unset($this->db);
	
	}
	
	/**
	 * SELECT
	 *
	 * @return void
	 */
	public function select($table, $column, $option = null, $option_data = null) {
	
		$sql = 'select '.$column.' from '.$table.$option;
		
		try {
			
			$result = array();
		
			if ($option_data === null) {
				$option_loop = 1;
				$option_cnt = 0;
			} else {
				$option_loop = count($option_data);
				$option_cnt = count($option_data[0]);
			}
			
			$stmt = $this->db->prepare($sql);
			
			for ($i = 0; $i < $option_loop; $i++) {
			
				for ($j = 0; $j < $option_cnt; $j++) {
					$stmt->bindValue($j+1, $option_data[$i][$j]);
				}
				
				$stmt->execute();
				
				$arr_temp = $stmt->fetchAll(PDO::FETCH_ASSOC);
				if (count($arr_temp) > 0) {
					$result = array_merge($result, $arr_temp);
				}
				
			}
			
			return $result;
			
		} catch (PDOException $e) {
		
			$this->error();
			
		}
	}
	
	/**
	 * INSERT
	 *
	 * @return void
	 */
	public function insert($table, $data) {
		
		$ph = null;
		$value_cnt = count($data[0]);
		
		if ($value_cnt <= 0) {
			return;
		}
		
		for ($i = 0; $i < $value_cnt; $i++) {
			$ph .= '?, ';
		}
		$ph = rtrim($ph, ', ');
		
		try {
		
			$sql = 'insert into '.$table.' values('.$ph.')';
			$stmt = $this->db->prepare($sql);
		
			$ins_cnt = count($data);
			for ($i = 0; $i < $ins_cnt; $i++) {
				
				for ($j = 0; $j < $value_cnt; $j++) {
					$stmt->bindValue($j+1, $data[$i][$j]['data'], $data[$i][$j]['type']);
				}

				$stmt->execute();
			
			}
			
		} catch (PDOException $e) {
		
			$this->rollBack();
			$this->error();
			
		}
	
	}
	
	/**
	 * UPDATE
	 *
	 * @return void
	 */
	public function update($table, $set, $data) {
		
		if (count($data) <= 0) {
			return;
		}
		
		try {
		
			$sql = 'update '.$table.' set '.$set;
			$stmt = $this->db->prepare($sql);
			$stmt->execute($data);
			
		} catch (PDOException $e) {
		
			$this->rollBack();
			$this->error();
			
		}
	
	}
	
	/**
	 * DELETE
	 *
	 * @return void
	 */
	public function delete($table, $option = null, $data = array()) {
		
		try {
		
			$sql = 'delete from '.$table.$option;
			$stmt = $this->db->prepare($sql);
			
			$data_cnt = count($data);
			for ($i = 0; $i < $data_cnt; $i++) {
				$stmt->bindValue($i+1, $data[$i]);
			}
			
			$stmt->execute();
			
		} catch (PDOException $e) {
		
			$this->rollBack();
			$this->error();
			
		}
	
	}
	
	/**
	 * COUNT
	 *
	 * @return void
	 */
	public function count($table, $column, $option = null) {
	
		$sql = 'select count('.$column.') from '.$table.$option;
		try {
			$stmt = $this->db->query($sql);
			return $stmt->fetch(PDO::FETCH_NUM);
		} catch (PDOException $e) {
			$this->error();
		}
		
	}
	
	/**
	 * MAX
	 *
	 * @return void
	 */
	public function max($table, $column) {
	
		$sql = 'select max('.$column.') from '.$table;
		try {
			$stmt = $this->db->query($sql);
			return $stmt->fetch(PDO::FETCH_NUM);
		} catch (PDOException $e) {
			$this->error();
		}
		
	}
	
	/**
	 * Query
	 *
	 * @return void
	 */
	public function query($sql, $fetch = PDO::FETCH_NUM) {
	
		try {
			$stmt = $this->db->query($sql);
			return $stmt->fetchAll($fetch);
		} catch (PDOException $e) {
			$this->error();
		}
		
	}
	
	/**
	 * Exec
	 *
	 * @return void
	 */
	public function exec($sql) {
	
		try {
			$stmt = $this->db->exec($sql);
		} catch (PDOException $e) {
			$this->error();
		}
		
	}
	
	/**
	 * トランザクション開始
	 *
	 * @return void
	 */
	public function begin() {
	
		$this->db->beginTransaction();
	
	}
	
	/**
	 * コミット
	 *
	 * @return void
	 */
	public function commit() {
	
		$this->db->commit();
	
	}
	
	/**
	 * ロールバック
	 *
	 * @return void
	 */
	public function rollBack() {
	
		$this->db->rollBack();
	
	}
	
	/**
	 * エラー表示
	 *
	 * @return void
	 */
	public function error() {
	
		$err = $this->db->errorInfo();
		die ($err[2]);
	
	}
	
}
