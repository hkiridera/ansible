<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}

$p_l = $this->p - 4;
if ($p_l < 1) $p_l = 1;
$p_r = $this->p + 4;
if ($p_r >= $this->maxpage) $p_r = $this->maxpage;

echo '<nav id="pagenavi">';
echo '<ul class="clearfix">';

if ($this->p > 1 && $this->p <= $this->maxpage) {
	$p_prev = $this->p - 1;
	echo '<li><a href="'.$self.'?'.$get.'&p='.$p_prev.'" title="前のページへ">Prev</a></li>'."\n";
}

if ($p_l > 1) {
	echo '<li><a href="'.$self.'?'.$get.'&p=1'.'" title="FirstPage">1</a></li>'."\n";
	echo '<li><span>…</span>';
}
for ($i = $p_l; $i < $this->p; $i++) {
	echo '<li><a href="'.$self.'?'.$get.'&p='.$i.'" title="Page_'.$i.'">'.$i.'</a></li>'."\n";
}
echo '<li><a href="'.$self.'?'.$get.'&p='.$i.'" title="Page_'.$i.'"><b>'.$i.'</b></a></li>'."\n";
for ($i = $this->p + 1; $i <= $p_r; $i++) {
	echo '<li><a href="'.$self.'?'.$get.'&p='.$i.'" title="Page_'.$i.'">'.$i.'</a></li>'."\n";
}
if ($p_r < $this->maxpage) {
	echo '<li><span>…</span>';
	echo '<li><a href="'.$self.'?'.$get.'&p='.$this->maxpage.'" title="LastPage">'.$this->maxpage.'</a></li>'."\n";
}

if ($this->p >= 1 && $this->p < $this->maxpage) {
	$p_next = $this->p + 1;
	echo '<li><a href="'.$self.'?'.$get.'&p='.$p_next.'" title="次のページへ">Next</a></li>'."\n";
}
echo '</ul>';
echo '</nav>';
