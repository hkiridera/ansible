<?php
// 直接アクセスの場合は死
if (!isset($_SESSION['direct']) && $_SESSION['direct'] !== false) {
	die();
}
?>
<article>

<h1><span>現在のランキング</span></h1>
<?php message(); ?>
<section>
	<h1>Ranking</h1>
	<?php $this->pagenavi->pageNavi(); ?>
	<p>このランキングは表示する度に生成されますので、貼付け用の出力されたランキングとは異なる可能性があります。</p>
	<form action="./?action=del_rank" method="post" id="form">
	<input type="hidden" name="redirect" value="./" />
	<input type="hidden" name="url" value="" />
	</form>
	<table>
		<colgroup span="1" style="width: 50px;"></colgroup>
		<colgroup span="1"></colgroup>
		<colgroup span="1" style="width: 80px;"></colgroup>
		<colgroup span="1" style="width: 60px;"></colgroup>
		<thead>
		<tr>
			<th>-</th>
			<th>URL</th>
			<th>合計</th>
			<th>削除</th>
		</tr>
		</thead>
		<tbody>
		<?php for ($i = $this->start; $i < $this->end; $i++) : ?>
		
		<tr>
			<td><?php e($this->rank[$i]); ?></td>
			<td><a href="<?php e($this->url[$i]); ?>" title="<?php e($this->name[$i]); ?>"><?php e($this->name[$i]); ?></a><br /><?php e($this->url[$i]); ?></td>
			<td class="alignright"><?php e($this->count[$i]); ?></td>
			<td><a href="#" class="actionlink" onclick="return deleteRanking('<?php echo($i); ?>');">削除</a><input type="hidden" name="temp" id="url_<?php echo($i); ?>" value="<?php e($this->url[$i]); ?>" /></td>
		</tr>
		<?php endfor; ?>
		
		</tbody>
	</table>
	<?php $this->pagenavi->pageNavi(); ?>
</section>

</article>
