<?php

class URL
{
	/**
	 * コンストラクタ
	 *
	 * @return void
	 */
	public function __construct(&$admin) {
	
		$this->admin = $admin;
		$this->db = $admin->db;
	
	}
	
	/**
	 * 拒否 URL 読み込み
	 *
	 * @return void
	 */
	public function readDenyURL() {
	
		$deny = $this->db->select('deny_url', '*', ' order by id desc');
		if (count($deny) < 0) {
			return false;
		}
		
		return $deny;
	
	}
	
	/**
	 * 拒否 URL 追加
	 *
	 * @return string or bool
	 */
	public function addDenyURL() {
	
		$set = array();
		$set['url'] = getPost('url');
		if (!isURLStr($set['url']) || !checkEmpty($set['url'])) {
			setSession($set);
			return '未入力、または URL 形式が間違っている可能性があります';
		}
		
		$keys = array(
			'id' => PDO::PARAM_NULL,
			'url' => PDO::PARAM_STR
		);
		
		$data = array();
		$data[0] = $this->admin->toPrepareArray($keys, $set);
		
		$this->db->begin();
		$this->db->insert('deny_url', $data);
		$this->db->commit();
		
		return true;
	
	}
	
	/**
	 * 拒否 URL 削除
	 *
	 * @return void
	 */
	public function deleteDenyURL() {
	
		$id = getPost('id');
		if (count($id) <= 0) {
			return '削除項目が選択されていません';
		}
		
		// 数値チェック
		foreach ($id as $value) {
			if (!isInteger($value)) {
				return 'ID が不正です';
			}
		}
		
		$in = implode(',', $id);
		
		$this->db->begin();
		$this->db->delete('deny_url', ' where id in('.$in.')');
		$this->db->commit();
		
		return true;
		
	}
	
	/**
	 * 拒否 URL 編集
	 *
	 * @return void
	 */
	public function editDenyURL() {
		
		$set = array();
		$set['id'] = getPost('id');
		if (!checkEmpty($set['id']) || !isInteger($set['id'])) {
			return 'ID が不正です';
		}
		$set['url'] = getPost('url');
		if (!isURLStr($set['url']) || !checkEmpty($set['url'])) {
			setSession($set);
			$this->redirect = './?mode=deny_edit&id='.h($set['id']);
			return '未入力、URL 形式が間違っている可能性があります';
		}

		$data = array($set['url'], $set['id']);
		
		$this->db->begin();
		$this->db->update('deny_url', 'url = ? where id = ?', $data);
		$this->db->commit();
		
		return true;
		
	}
	
	/**
	 * 置換 URL 読み込み
	 *
	 * @return void
	 */
	public function readReplaceURL() {
	
		$replace = $this->db->select('replace', '*', ' order by id desc');
		if (count($replace) < 0) {
			return false;
		}
		
		return $replace;
	
	}
	
	/**
	 * 置換 URL 登録
	 *
	 * @return void
	 */
	public function addReplaceURL() {
	
		$error = null;
		
		$set = array();
		$set['ref'] = getPost('ref');
		$set['name'] = getPost('name');
		$set['url'] = getPost('url');
		
		if (!checkEmpty($set['ref']) || !checkEmpty($set['name']) || !checkEmpty($set['url'])) {
			$error .= '未入力項目があります<br />';
		}
		
		if (!isURLStr($set['url'])) {
			$error .= '置換 URL 形式が間違っている可能性があります<br />';
		}
		
		$arr_url = explode('|', trim($set['ref']));
		if (count($arr_url) > 0) {
			foreach ($arr_url as $value) {
				if (!isURLStr($value)) {
					$error .= '置換元 URL 形式が間違っている可能性があります<br />';
				}
			}
		}
		
		if ($error !== null) {
			setSession($set);
			return $error;
		}
		
		$keys = array(
			'id' => PDO::PARAM_STR,
			'ref' => PDO::PARAM_STR,
			'url' => PDO::PARAM_STR,
			'name' => PDO::PARAM_STR
		);
		
		$data = array();
		$data[0] = $this->admin->toPrepareArray($keys, $set);
		
		$this->db->begin();
		$this->db->insert('replace', $data);
		$this->db->commit();
		
		return true;
		
	}
	
	/**
	 * 置換 URL 削除
	 *
	 * @return void
	 */
	public function deleteReplaceURL() {
	
		$id = getPost('id');
		if (count($id) <= 0) {
			return '削除項目が選択されていません';
		}
		
		// 数値チェック
		foreach ($id as $value) {
			if (!isInteger($value)) {
				return 'ID が不正です';
			}
		}
		
		$in = implode(',', $id);
		
		$this->db->begin();
		$this->db->delete('replace', ' where id in('.$in.')');
		$this->db->commit();
		
		return true;
		
	}
	
	/**
	 * 置換 URL 編集
	 *
	 * @return void
	 */
	public function editReplaceURL() {
	
		$error = null;
		
		$set = array();
		$set['id'] = getPost('id');
		$set['ref'] = getPost('ref');
		$set['name'] = getPost('name');
		$set['url'] = getPost('url');
		
		if (!checkEmpty($set['id']) || !isInteger($set['id'])) {
			$error .= 'ID が不正です<br />';
		}
		
		if (!isURLStr($set['url'])) {
			$error .= '置換 URL 形式が間違っている可能性があります<br />';
		}
		
		if (!checkEmpty($set['ref']) || !checkEmpty($set['name']) || !checkEmpty($set['url'])) {
			$error .= '未入力項目があります<br />';
		}
		
		$arr_url = explode('|', trim($set['ref']));
		if (count($arr_url) > 0) {
			foreach ($arr_url as $value) {
				if (!isURLStr($value)) {
					$error .= '置換元 URL 形式が間違っている可能性があります<br />';
					break;
				}
			}
		}
		
		if ($error !== null) {
			setSession($set);
			$this->redirect = './?mode=rep_edit&id='.h($set['id']);
			return $error;
		}
		
		$data = array();
		$data = array($set['ref'], $set['url'], $set['name'], $set['id']);
		
		$this->db->begin();
		$this->db->update('replace', ' ref = ?, url = ?, name = ? where id = ?', $data);
		$this->db->commit();
		
		return true;
		
	}
	
	/**
	 * リダイレクト
	 *
	 * @return mixed
	 */
	public function getRedirect() {
		if (isset($this->redirect)) {
			return $this->redirect;
		} else {
			return null;
		}
	}
	
	/**
	 * デストラクタ
	 *
	 * @return void
	 */
	public function __destruct() {
	
	}
	
}
