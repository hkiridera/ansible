/* for menu in responsive */
jQuery(document).ready(function() {
		jQuery(window).scroll(function () {
		if( jQuery(window).width() > 768) {
			if (jQuery(this).scrollTop() > 220) {
			jQuery('.home-menu-list').addClass('sticky-head');
			}
			else {
		jQuery('.home-menu-list').removeClass('sticky-head');
		}
		}
			else {
			if (jQuery(this).scrollTop() > 250) {
				jQuery('.home-menu-list').addClass('sticky-head');
			}else {
		jQuery('.home-menu-list').removeClass('sticky-head');
		}
			}				
		});
		
});	 	  
/* for menu */
   jQuery(document).ready(function() {
	if( jQuery(window).width() > 767) {
	   jQuery('.nav li.dropdown').hover(function() {
		   jQuery(this).addClass('open');
	   }, function() {
		   jQuery(this).removeClass('open');
	   }); 
	   jQuery('.nav li.dropdown-menu').hover(function() {
		   jQuery(this).addClass('open');
	   }, function() {
		   jQuery(this).removeClass('open');
	   }); 
	}
	jQuery('.nav').find('.caret').each(function(){
		jQuery(this).on('click', function(){
			if( jQuery(window).width() < 768) {
				jQuery(this).parent().next().slideToggle();
			}
			return false;
		});
	});
});

/* header slider */
   var swiper = new Swiper('.home_slider', {
        effect: 'coverflow',
        grabCursor: true,
        centeredSlides: true,
		 autoplay: 2500,
		nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        slidesPerView: '2',
		loop:true,
        coverflow: {
            rotate: 10,
            stretch: 0,
            depth: 50,
            modifier: 1,
            slideShadows : true,
			
        },
        breakpoints: {
            1240: {
                slidesPerView: 3,
                spaceBetween: 40
            },
            768: {
                slidesPerView: 1,
                spaceBetween: 30
            },
            640: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            320: {
                slidesPerView: 1,
                spaceBetween: 10
            }
        }		
    });
/* for blog */
	 var swiper = new Swiper('.home_blog',{
		   pagination: '.swiper-pagination',
		 slidesPerView: 3,
        paginationClickable: true,
		 autoplay: 0,
		loop:false,
		
	   breakpoints: {
            1240: {
                slidesPerView: 3,
                spaceBetween: 40
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 30
            },
            640: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            320: {
                slidesPerView: 1,
                spaceBetween: 10
            }
        }
    });

/* for scroll arrow */
	 var amountScrolled = 300;

jQuery(window).scroll(function() {
	if ( jQuery(window).scrollTop() > amountScrolled ) {
		jQuery('a.back-to-top').fadeIn('slow');
	} else {
		jQuery('a.back-to-top').fadeOut('slow');
	}
});

jQuery('a.back-to-top').click(function() {
	jQuery('html, body').animate({
		scrollTop: 0
	}, 700);
	return false;
});