************Read Me************

This theme is a child theme for Twenty Thirteen.
This theme includes Twitter Bootstrap 3.1.1 css and jquery and fonts.
Go to the Twitter Framework site to see what other components and jquery scripts you can use with this theme.

http://getbootstrap.com/

The style.css overwrites the default bootstrap styles to the flat styles- customise it however you like.
It also uses a custom nav walker: https://github.com/twittem/wp-bootstrap-navwalker

************Copyrights and Licenses************

Plain Jane WordPress theme, Copyright (C) 2013 Christine Garner
Plain Jane WordPress theme is licensed under the GPL.
All images are copyright Christine Garner, and licensed under the GNU General Public License v3.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Twitter Bootstrap - http://getbootstrap.com/2.3.2/
Bootstrap by Twitter and the Glyphicon set are licensed under the GPL-compatible [http://www.apache.org/licenses/LICENSE-2.0 Apache License v2.0]

wp-bootstrap-navwalker
A custom WordPress nav walker class to fully implement the Twitter Bootstrap 3.0+ navigation style in a custom theme using the WordPress built in menu manager.
https://github.com/twittem/wp-bootstrap-navwalker

************What's in this theme?************

Page templates included:
To set pages as public or private use the page attributes: page templates in the edit page screen.

Default Template- left sidebar with subpages menu for any child pages
Full Page- full width page template.
Sub page gallery- shows subpages as a thumbnail gallery- use the child pages of a page set to this template to create a thumbnail gallery.
sub page gallery 4 columns
Gallery page � has navigation links to other pages on the same level.

3 Menus

top right menu *
primary horizontal menu *
vertical menu for sidebar *

*(Please note the wp-bootstap-navwalker menus only support 1 level of drop down)
As author notes: This script in intended implement the Bootstrap 3.0 menu structure without adding additional features, additional dropdown levels will not be supported.

Widgets

6 widgets 

Primary Sidebar Widget (left) (widget visible on the default page template or Public Page Left Column template
Logged out widget (left)- widget only visible for public visitors on Public Page Left Column template
Footer Area 1 (left footer- all templates)
Footer Area 2 (middle footer- all templates)
Footer Area 3 (right footer - all templates)
Footer Area Home 1 (Home or front page on left in footer)
Footer Area Home 2 (Home or front page on right in footer)

Custom background:

you can set a custom background in the admin although this theme is designed to have a white or pale background.

Custom Header

you can set a custom header image in the admin.

Subpage function:

Default Template pages have a left sidebar and any child pages will show as a menu.

All functions are commented. 

Featured Thumbnails:

150px by 150px is the recommended size for thumbnails of child pages under a page using the page template for sub page gallery.
240px by 108px is the recommended size for thumbnails under a page using the page template for the 4 column sub page gallery.

