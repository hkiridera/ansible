   jQuery(document).ready(

		  function() { 

			jQuery("html").niceScroll();

		  }

		);

