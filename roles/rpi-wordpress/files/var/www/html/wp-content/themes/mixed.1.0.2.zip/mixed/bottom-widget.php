<aside class="bottom-widgets-wrapper" role="complemantary">
			
	<div class="container">
				
		<div class="col-sm-3">	
				
			<?php if(dynamic_sidebar('footer-1')); ?>

		</div> <!-- end col-sm-3 -->

		<div class="col-sm-3">
				
			<?php if(dynamic_sidebar('footer-2')); ?>

		</div> <!-- end col-sm-3 -->

		<div class="col-sm-3">
				
			<?php if(dynamic_sidebar('footer-3')); ?>

		</div> <!-- end col-sm-3 -->

		<div class="col-sm-3">
				
			<?php if(dynamic_sidebar('footer-4')); ?>

		</div> <!-- end col-sm-3 -->

	</div> <!-- end container -->

</aside> <!-- end bottom-widgets-area -->