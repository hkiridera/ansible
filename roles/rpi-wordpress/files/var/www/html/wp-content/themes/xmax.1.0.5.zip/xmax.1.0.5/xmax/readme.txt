Xmax theme
--------------------

Xmax is a multi purpose wordpress theme which could be used for almost all kinds of business. You can use it for Ecommerce, Blog, Portfolio, Coporate web site. Especially, it comes with Woocommerce plugin which makes it become a good ecommerce website. Fully responsive Resolution looks beautiful and is very attractive on any device. It has two optional versions – Wide and Boxed and multi-layouts, this Multi Purpose WordPress Theme provides everything you’ll need to create a professional looking website. Theme is designed and coded by http://kopatheme.com

--------------------
Sources and Credits
--------------------

--------------------
Font Awesome License
--------------------

Font License - http://fontawesome.io
License: SIL OFL 1.1
License URI: http://scripts.sil.org/OFL
Copyright: Dave Gandy, http://fontawesome.io

Code License - http://fontawesome.io
License: MIT License
License URI: http://opensource.org/licenses/mit-license.html
Copyright: Dave Gandy, http://fontawesome.io

Brand Icons
All brand icons are trademarks of their respective owners.
The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.


--------------------
Other Licenses
--------------------
See headers of files for further details.


--------------------
Screenshot
--------------------
    The image ( http://pixabay.com/fr/fraises-cr%C3%AApe-dessert-douce-395590/ ) is a free public picture, copyright Philipp_Stegmann ( http://pixabay.com/fr/users/Philipp_Stegmann-341220/ ), and distributed under the terms of the Creative Commons CC0 1.0 Universal Public Domain Dedication (http://creativecommons.org/publicdomain/zero/1.0/deed.en)
    The image ( http://pixabay.com/fr/golden-gate-bridge-san-francisco-388917/ ) is a free public picture, copyright Unsplash ( http://pixabay.com/fr/users/Unsplash-242387/ ), and distributed under the terms of the Creative Commons CC0 1.0 Universal Public Domain Dedication (http://creativecommons.org/publicdomain/zero/1.0/deed.en)
    The image ( http://pixabay.com/fr/fraises-rouge-douce-plantes-champ-196798/ ) is a free public picture, copyright Fruchthandel_Magazin ( http://pixabay.com/fr/users/Fruchthandel_Magazin-70434/ ), and distributed under the terms of the Creative Commons CC0 1.0 Universal Public Domain Dedication (http://creativecommons.org/publicdomain/zero/1.0/deed.en)
    The image ( http://pixabay.com/fr/plage-c%C3%B4te-l-eau-ciel-sable-569363/ ) is a free public picture, copyright Unsplash ( http://pixabay.com/fr/users/Unsplash-242387/ ), and distributed under the terms of the Creative Commons CC0 1.0 Universal Public Domain Dedication (http://creativecommons.org/publicdomain/zero/1.0/deed.en)
    The image ( http://pixabay.com/fr/plage-c%C3%B4te-pierres-rock-mer-l-eau-192981/ ) is a free public picture, copyright FrankWinkler ( http://pixabay.com/fr/users/FrankWinkler-64960/ ), and distributed under the terms of the Creative Commons CC0 1.0 Universal Public Domain Dedication (http://creativecommons.org/publicdomain/zero/1.0/deed.en)

--------------------
Javascript Licenses
--------------------
    bootstrap.js
        Bootstrap.js by @fat & @mdo
        Copyright 2012 Twitter, Inc.
        http://www.apache.org/licenses/LICENSE-2.0.txt
    custom.js
        Copyright (c) 2014 Kopatheme - kopatheme.com
        Licensed under the GPL license:
        *  http://www.gnu.org/licenses/gpl.html
    fotorama.js
        Copyright 2011—2015 Artem Polikarpov
        http://fotorama.io/
        Licensed under the MIT license
    hoverIntent.js
        Copyright 2007, 2013 Brian Cherne
        http://cherne.net/brian/resources/jquery.hoverIntent.html
        Licensed under the MIT license
    html5shiv
        Copyright by @afarkas @jdalton @jon_neal @rem | MIT/GPL2 Licensed
        Licensed under the MIT/GPL2 Licensed
    imagesloaded.js
        Copyright: Tomas Sardyha @Darsain and David DeSandro @desandro, http://v3.desandro.com/
        MIT License
    imgliquid.js
        Copyright (c) 2012 Alejandro Emparan (karacas) @krc_ale
        Dual licensed under the MIT and GPL licenses
        https://github.com/karacas/imgLiquid
    jflickrfeed.js
        Copyright (C) 2009 Joel Sutherland
        Licenced under the MIT license
        * http://www.newmediacampaigns.com/page/jquery-flickr-plugin
    jquery.flexslider.js
        jQuery FlexSlider v2.1
         * Copyright 2012 WooThemes
         * Contributing Author: Tyler Smith
         Licensed under the GPL2 Licensed
    jquery.form.js
         * jQuery Form Plugin
         * version: 2.94 (13-DEC-2011)
         * Dual licensed under the MIT and GPL licenses:
         *	http://www.opensource.org/licenses/mit-license.php
         *	http://www.gnu.org/licenses/gpl.html
    jquery.magnific-popup
        Masonry PACKAGED v3.1.2
         * Cascading grid layout library
         * http://masonry.desandro.com
         * MIT License
         * by David DeSandro
    jquery.mCustomScrollbar.js
        Copyright 2010-2013 Manos Malihutsakis
        author: malihu (http://manos.malihu.gr)
        plugin home: http://manos.malihu.gr/jquery-custom-content-scroller
        http://www.gnu.org/licenses/lgpl.html.
    jquery.navgoco.js
        jQuery Navgoco Menus Plugin v0.1.5 (2013-09-07)
         * https://github.com/tefra/navgoco
         * Copyright (c) 2013 Chris T (@tefra)
         * BSD - https://github.com/tefra/navgoco/blob/master/LICENSE-BSD
    modernizr.js
        Modernizr 2.7.1 (Custom Build) | MIT & BSD
         * Build: http://modernizr.com/download/#-fontface-backgroundsize-borderradius-boxshadow-flexbox-flexboxlegacy-multiplebgs-opacity-rgba-textshadow-cssanimations-csscolumns-generatedcontent-cssgradients-cssreflections-csstransforms-csstransforms3d-csstransitions-audio-video-shiv-mq-cssclasses-prefixed-teststyles-testprop-testallprops-prefixes-domprefixes-load
    owl.carousel.js
         jQuery OwlCarousel v1.3.2
         *  Copyright (c) 2013 Bartosz Wojciechowski
         *  http://www.owlgraphic.com/owlcarousel/
         *  Licensed under MIT
    superfish.js
         jQuery Superfish Menu Plugin - v1.7.4
         * Copyright (c) 2013 Joel Birch
         * Dual licensed under the MIT and GPL licenses:
         *	http://www.opensource.org/licenses/mit-license.php
         *	http://www.gnu.org/licenses/gpl.html

--------------------
Limitation
--------------------
Top menu, footer menu does not support multi level dropdown menu


Thanks!
KOPASOFT
