<?php 
// sidebars
add_action( 'widgets_init', 'spasalon_widgets_init' );
function spasalon_widgets_init(){
	
	$current_options = wp_parse_args(  get_option( 'spa_theme_options', array() ), default_data() );
	$service_layout = 12 / $current_options['service_layout'];
	$news_layout = 12 / $current_options['news_layout'];
	
	register_sidebar( array(
	'name' => __( 'Primary Sidebar', 'spasalon' ),
	'id' => 'sidebar-primary',
	'description' => __( 'The primary widget area', 'spasalon' ),
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>'
	) );
	
	register_sidebar( array(
	'name' => __( 'Service Content', 'spasalon' ),
	'id' => 'sidebar-service',
	'description' => __( 'Service content widget area', 'spasalon' ),
	'before_widget' => '<div id="%1$s" class="col-md-'.$service_layout.' col-sm-6 col-xs-12 widget %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h4 class="widget-title">',
	'after_title' => '</h4>'
	) );
	
	register_sidebar( array(
	'name' => __( 'Project Content', 'spasalon' ),
	'id' => 'sidebar-project',
	'description' => __( 'Project content widget area', 'spasalon' ),
	'before_widget' => '<div id="%1$s" class="widget item-product  %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h4 class="widget-title">',
	'after_title' => '</h4>'
	) );
	
	register_sidebar( array(
	'name' => __( 'News sidebar', 'spasalon' ),
	'id' => 'sidebar-news',
	'description' => __( 'News section widget area', 'spasalon' ),
	'before_widget' => '<div id="%1$s" class="col-md-'.$news_layout.' widget %2$s">',
	'after_widget' => '</div>',
	'before_title' => '<h4 class="widget-title">',
	'after_title' => '</h4>'
	) );
	
	register_sidebar( array(
	'name' => __( 'Footer Sidebar 1', 'spasalon' ),
	'id' => 'footer-sidebar1',
	'description' => __( 'Footer widget area', 'spasalon' ),
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>'
	) );
	
	register_sidebar( array(
	'name' => __( 'Footer Sidebar 2', 'spasalon' ),
	'id' => 'footer-sidebar2',
	'description' => __( 'Footer widget area', 'spasalon' ),
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>'
	) );
	
	register_sidebar( array(
	'name' => __( 'Footer Sidebar 3', 'spasalon' ),
	'id' => 'footer-sidebar3',
	'description' => __( 'Footer widget area', 'spasalon' ),
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>'
	) );
	
	register_sidebar( array(
	'name' => __( 'Footer Sidebar 4', 'spasalon' ),
	'id' => 'footer-sidebar4',
	'description' => __( 'Footer widget area', 'spasalon' ),
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>'
	) );
	
	register_sidebar( array(
	'name' => __( 'Woocommerce Sidebar', 'spasalon' ),
	'id' => 'woocommerce-1',
	'description' => __( 'Woocommerce sidebar widget area', 'spasalon' ),
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>'
	) );
	
}