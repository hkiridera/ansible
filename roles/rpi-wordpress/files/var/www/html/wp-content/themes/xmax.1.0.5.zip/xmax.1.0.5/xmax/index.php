<?php get_header(); ?>

<div class="kopa-entry-list">
<?php
  if (have_posts()):
    while (have_posts()) : the_post();
      ?>                              
      <div <?php post_class('kopa-entry-post'); ?>>
        <div class="entry-content">
          
          <?php the_content(); ?>          

          <?php
          wp_link_pages(array(
							'before'         => '<div class="page-link clearfix"><div class="pull-right"><span class="page-links-title">' . __('Parts: ', 'xmax') . '</span>',
							'after'          => '</div></div>',
							'next_or_number' => 'number',
							'pagelink'       => '<span>%</span>',
							'echo'           => true
          ));
          ?>

          </div>
      </div>

        <?php comments_template(); ?>
        
        <?php
    endwhile;
  else:
      printf('<blockquote>%1$s</blockquote>', __('Nothing Found...', 'xmax'));
  endif;
  ?>
</div>

<?php
get_footer();