<?php
  /**
   * @package graftee
   */
?>
<ul>
<li><?php printf( __( '%sを更に高速化するプラグイン', 'graftee' ), wp_get_theme() ); ?>"<a href="<?php echo get_admin_url(); ?>plugin-install.php?tab=search&type=term&s=Graftee+Speed+Up+Kit">Graftee Speed Up Kit</a>"</li>
</ul>
