<?php get_header(); ?>
<div class="content">
<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>
  <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="post-header-single">
        <span class="date"><img src="<?php  echo esc_url( get_template_directory_uri() ); ?>/images/cal.png" /> <a href="<?php echo get_day_link(get_post_time('Y'), get_post_time('m'), get_post_time('j')); ?>"><?php the_time( 'M j Y' ); ?></a></span>
        <span class="author"><img src="<?php  echo esc_url( get_template_directory_uri() ); ?>/images/aut.png" /> <?php the_author_posts_link(); ?></span>
        <span class="postCategory"><img src="<?php  echo esc_url( get_template_directory_uri() ); ?>/images/cat.png" /> <?php the_category( ', ' ); ?></span>
        <span class="postTags"><img src="<?php  echo esc_url( get_template_directory_uri() ); ?>/images/tag.png" /><?php the_tags( ' ', ', ', '<br />' ); ?></span>
        <span span class="title-single"><h2><?php the_title(); ?></h2></span>
    </div><!--end post header-->
    <div class="entry-single-description clear">

        
        <div class="entry-single-content">

            <?php the_content(); ?>

        </div>

        <!--BEGIN .author-bio-->
            
            <div class="author-bio">
                <p><b><?php _e( 'Written by', 'neo-zee' ); ?> <i><?php the_author_link(); ?></i></b></p>
                <p><?php echo get_avatar( get_the_author_meta('email'), '90' ); ?><?php the_author_meta('description'); ?></p><br />
            </div>
<!--END .author-bio-->
        
        <?php wp_link_pages(); ?>

        <div class="post-footer-single">
            <div id="comments"><?php comments_popup_link( __( 'Leave a comment', 'neo-zee' ), __( '1 Comment', 'neo-zee' ), __( '% Comments', 'neo-zee' ) ); ?></div>
        </div>
        <div class="post-footer-edit-single">
            <?php edit_post_link( __('[EDIT]', 'neo-zee' ) ); ?>
        </div>
    </div><!--end entry--> <!--end post footer-->
    
  </div><!--end post-->
<?php endwhile; /* rewind or continue if all posts have been fetched */ ?>



    <div>
            <?php
                // If comments are open or we have at least one comment, load up the comment template
                if ( comments_open() || get_comments_number() ) :
                    comments_template( '/comments.php' );
                endif;
            ?>
    </div>
  </div><!--end navigation-->
<?php else : ?>
<?php endif; ?>

</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>