
		<article class="post no-results nothing-found">
			<header class="entry-header page-header">
				<h1 class="entry-title"><?php _e( 'Nothing found', 'activetab' ); ?></h1>
			</header><!-- .entry-header -->

			<div class="entry-content">
				<?php get_search_form(); ?>
			</div><!-- .entry-content -->
		</article><!-- .post -->
