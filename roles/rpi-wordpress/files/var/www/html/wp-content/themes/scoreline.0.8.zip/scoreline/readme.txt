****NOTE****
ALL PRE-FIX & slug used in the theme " Scoreline ".

Scoreline
/////////////////////////*****************Copyrights Attribution********************////////////////////////////////////
Scoreline WordPress Theme, Copyright 2016 weblizar

Bootstrap | v3.3.5 |
Copyright 2011-2015 Twitter, Inc.
Licensed under MIT -https://github.com/twbs/bootstrap/blob/master/LICENSE

Font Awesome CSS |  v4.6.3 | 
Copyright 2015  Dave Gandy.,
Font Awesome licensed under SIL OFL 1.1 Code
Licensed under MIT license :http://fontawesome.io/license

Animate CSS | V3.5.0 |
Copyright 2015 Daniel Eden,
Licensed under MIT license - http://opensource.org/licenses/MIT

Hover CSS | V2.0.2 |
Copyright Ian Lunn 2014. Generated with Sass.
Licensed under MIT License - http://www.opensource.org/licenses/mit-license.php

Swiper CSS And JS |  v3.3.1 | 
Copyright 2015  Vladimir Kharlampidi
Licensed under MIT license :http://www.idangero.us/swiper/

custom-script | V 1.0 | scoreline 
(c) 2016  | Licensed under the MIT license and GPL license.

Images Taken from :
pixabay.com

Image For Sidebar and Blog
Image : https://pixabay.com/en/guitar-country-girl-music-1139397/ 

Image For Footer Posts
Image : https://pixabay.com/en/girl-pose-sitting-smile-cute-344322/

callout section Images: https://pixabay.com/en/background-course-abstract-pattern-728537/

All Images have been used in the Scoreline, are taken from pixabay.com .They are GPL Licensed and free to use and free to redistribute further. 
# --- EOF --- #
