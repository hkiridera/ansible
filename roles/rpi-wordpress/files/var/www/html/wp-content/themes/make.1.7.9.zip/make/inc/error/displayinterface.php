<?php
/**
 * @package Make
 */

/**
 * Interface MAKE_Error_DisplayInterface
 *
 * @since 1.7.0.
 */
interface MAKE_Error_DisplayInterface extends MAKE_Util_ModulesInterface {}