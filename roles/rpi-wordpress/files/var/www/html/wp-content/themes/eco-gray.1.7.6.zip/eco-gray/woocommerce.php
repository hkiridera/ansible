<?php get_header(); ?>   
		<div class="content">
			
			<div class="post-main">
				<div class="post-woocommerce">
					<?php woocommerce_content(); ?>
				</div>
			</div>
		</div>

</div>
</div>
</div>
<?php get_footer(); ?>