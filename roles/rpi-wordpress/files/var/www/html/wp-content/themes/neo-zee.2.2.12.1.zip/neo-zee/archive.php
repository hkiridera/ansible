<?php get_header(); ?>

<div id="content" class="content">


<!-- Loop -->

<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>
  <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    
    <div class="post-header-single">
        <span class="date"><img src="<?php  echo esc_url( get_template_directory_uri() ); ?>/images/cal.png" /> <a href="<?php echo get_day_link(get_post_time('Y'), get_post_time('m'), get_post_time('j')); ?>"><?php the_time( 'M j Y' ); ?></a></span>
        <span class="author"><img src="<?php  echo esc_url( get_template_directory_uri() ); ?>/images/aut.png" /> <?php the_author_posts_link(); ?></span>
        <span class="postCategory"><img src="<?php  echo esc_url( get_template_directory_uri() ); ?>/images/cat.png" /> <?php the_category( ', ' ); ?></span>
        <span span class="title-single"><h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></span>
    </div><!--end post header-->
    <div class="entry-single clear">

        <?php the_post_thumbnail(); ?>
        <?php the_excerpt(); ?>
        
        <?php wp_link_pages(); ?>

        <div class="post-footer-single">
            <div class="comments-single"><?php comments_popup_link( __( 'Leave a comment', 'neo-zee' ), __( '1 Comment', 'neo-zee' ), __( '% Comments', 'neo-zee' ) ); ?></div>
        </div>
        <div class="post-footer-edit-single">
            <?php edit_post_link( __('[EDIT]', 'neo-zee' ) ); ?>
        </div>
    </div><!--end entry--> <!--end post footer-->
  </div><!--end post-->
<?php endwhile; /* rewind or continue if all posts have been fetched */ ?>

    <div class="navigation index">
        <?php the_posts_pagination(); ?>
    </div><!--end navigation-->

  </div><!--end navigation-->
<?php else : ?>
<?php endif; ?>

</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>