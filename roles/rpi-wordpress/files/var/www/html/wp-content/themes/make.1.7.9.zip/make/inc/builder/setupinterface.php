<?php
/**
 * @package Make
 */


interface MAKE_Builder_SetupInterface extends MAKE_Util_ModulesInterface {}