Custom Community 2 - WordPress & BuddyPress Theme
Developed by Themekraft - http://themekraft.com

Theme Homepage - http://themekraft.com/store/custom-community-2-free-responsive-wordpress-bootstrap-theme/

Licensed under GNU General Public License, Version 2.0
http://www.gnu.org/licenses/gpl-2.0.html

The Custom Community Project on Github - https://github.com/Themekraft/Custom-Community

-------------------------------------------------------------


Standout with a professional custom made WordPress theme designed by you.

Responsive and ready for your next blog, portfolio site,
magazine, social network or shop. Use it out-of-the-box or customize up to
the smallest details. Spend your time on your ideas, not on trouble shooting.

Easy to use jQuery slideshow. List posts in magazine layouts.
140+ easy theme options. Many widget areas and
2 custom header menus.

3 predefined colour schemes (white, dark, natural) with clean and
simple browsersafe CSS design to start from.

Working with latest WordPress, BuddyPress, WooCommerce and most common plugins.

Find extensive Documentation, Free Tech Support and Premium Support at
http://themekraft.com/support.

One of the most used BudyPress themes. Community thriven development.
You are welcome to contribute and report bugs or ideas at GitHub:
https://github.com/Themekraft/Custom-Community/issues

Designed and developed by Themekraft.

-------------------------------------------------------------

PLEASE NEVER CHANGE THE THEME FILES
Your changes will not be update safe, which would be really sad. :(


-------------------------------------------------------------

But we made an extra space for your style changes. :)

Simply go to APPEARANCE -> THEME SETTINGS -> CSS and add your CSS changes there.


If you want to change more than CSS, we strongly recommend creating a child theme (see the theme documentation).

-------------------------------------------------------------

INCLUDED RESOURCES:

Custom Community 2 includes the following resources (listed alphabetically):

- Animate.css - licensed under the MIT license (http://opensource.org/licenses/MIT) - http://daneden.github.io/animate.css/
- Bootstrap 3.3.x - Code licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE), documentation under CC BY 3.0 (http://creativecommons.org/licenses/by/3.0/) - http://getbootstrap.com/
- Font Awesome 4.3.x - Font licensed under SIL OFL 1.1, CSS licensed under the MIT License (also see http://fontawesome.io/license) - http://fontawesome.io/
- Glyphicons - licensed under the MIT license
- Simple HTML DOM class - modified version for theme usage; licensed under the MIT license - http://simplehtmldom.sourceforge.net/
- smartmenus.js - licensed under the MIT license - http://www.smartmenus.org/


Thanks for using Custom Community Theme.
We hope you enjoy it!



