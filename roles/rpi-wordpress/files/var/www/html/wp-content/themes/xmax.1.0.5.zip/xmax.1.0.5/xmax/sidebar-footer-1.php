<?php
if (is_active_sidebar('footer-1-sidebar')):
	echo '<section class="col-md-3 col-sm-3 col-xs-12 widget-area-7">';
	dynamic_sidebar('footer-1-sidebar');
	echo '</section>';
endif;