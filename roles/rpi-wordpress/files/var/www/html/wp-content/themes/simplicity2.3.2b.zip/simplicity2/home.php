<?php //トップページ用 ?>
<?php get_header(); ?>

<?php get_template_part('list') ?>

<?php get_footer(); ?>