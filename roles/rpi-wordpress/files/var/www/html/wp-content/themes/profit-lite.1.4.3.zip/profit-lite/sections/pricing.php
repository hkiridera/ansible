<?php
/*
 * pricing section
 */

if (has_action('mp_profit_section_pricing')) {
    do_action('mp_profit_section_pricing');
}
