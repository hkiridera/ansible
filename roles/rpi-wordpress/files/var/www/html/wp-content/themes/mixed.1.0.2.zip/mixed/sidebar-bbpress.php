<aside class="sidebar-wrapper bbpress-sidebar" role="complemantary">
				
	<div class="col-sm-3">

		<?php if(dynamic_sidebar('bbpress')); ?>

	</div> <!-- end col-sm-4 -->

</aside> <!-- end mixed-sidebar -->