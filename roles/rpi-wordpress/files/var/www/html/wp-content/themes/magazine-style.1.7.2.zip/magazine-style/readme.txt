--------------------------------------------------------
Thanks for Downloading Magazine Style theme
--------------------------------------------------------
I made this for free to use if you find any bug or error please
You can directly contact us: http://www.insertcart.com/forums/
also suggestion are welcome


--------------------------Magazine Style------------------------
Features:

Theme have many features like some main are listed below

Theme option:
-upload favicon from theme option by url
-Customize you site background color or image
-show 5 latest posts with thumbnail in right sidebar -activate from theme option > General settings
-enable search from theme option > General settings

Advertise:
-Add text link below navigation
-Ads supports single post and footer best for adsense

Social:
-Add you fan page or follow page of Facebook, twitter, Rss feed, Google+, Linkedin from theme option > Social Media

Custom Css:
-Also support for Custom Css with you have not need to change main style.css file


== Change log ==

= 1.7 =
* Added microdata support
* Added schema.org navigation
* Added tags could css.
* Website width control

= 1.6.8 =
* Updated text domain
* Removed old tags from style.css
* Added Instagram social button

= 1.6.6 =
* Added arabic traslation
* Added website width control

= 1.6.1 =
* bbPress Support fixed
* Background image support added
* Search input box fix
* Screenshot updated
* Latest post fonts and thumbnail changes

= 1.6 =
* Added font awesome support
* Maximum website width to 1350px
* Fixed alignment of next and previous post
* Fixed Logo issue
* Header image issue fixed 
* Text domain fixed

= 1.5.9 =
* Missing id issue in widgets
* Searchform code updated
* Untranslatable text fixed
* Other Minor issue


= 1.5.8 =
* Fixed Table issue in post and pages
* Fixed calendar issue in widgets
* Updated comments.php codes
* Fixed other minor issue
* Language support for Portuguese added
* Search result overflow fix

= 1.5.7 =
* Fixed minor issue

= 1.5.6 =
*Optionframework updated
*Redesigned theme options
*Fix website logo issue on older IE version
*Fix other codes issue 

= 1.5.4 =
*Fixed stylesheet issue
*Option Framework updated
*Thumbnail will now good quality
*Other themes error fixed  

= 1.5.3 =
*updated theme optional panel
*Added arrow if drop down menu in top navigation
*Fixed rss feed and sitemap error 

= 1.5.1 =
*Updated Theme admin panel
*premium feature added
*Footer credit edit to new style
*fixed other issues

= 1.4.2 =
*Responsive website design
*Main Menu fixed when no menu created
*<pre> and <blockquote> redesigned

= 1.3.2 =
*Header menu not working bug fixed
*IE 6 DD_belatedPNG_0.0.8a-min.js removed no need of that.
*Footer ads will now show in every page and post


= 1.3.1 =
*Bug Fixed
*Added Image sprite in post meta
*Theme Author URI changed

= 1.2.3 =
*Bug Fixed
*Social share fixed in sidebar
*Longs table overflow fixed
*Resize header to increase post view area
*Redesign footer widget

= 1.2.2 =
*Bug Fixed
*Change table content issue
*Removed default favicon
*image thumbnail image.php
*Custom background issue fixed
*function prefix change to magazine
*Post date change now user can set their own


= 1.0 =
*Initial Release @ 1.0



== License ==

*Option Framework : Author is "Devin Price" provided at http://www.wptheming.com under License GPLv2 (All file Included in "inc" folder)
*Social Icons: are provided by "Konstantin Kovshenin" URL: http://kovshenin.com/2011/freebies-a-simple-social-icon-set-gpl/ Which in under GPL v2
*Images into /images/ folder that's are created by me publish Under gpl v2
*Fonts Monda: Copyright (c) 2012, vernon adams (vern@newtypography.co.uk)  This Font Software is licensed under the SIL Open Font License, Version 1.1. http://scripts.sil.org/OFL
* Font Awesome License: SIL OFL 1.1 URL: http://scripts.sil.org/OFL
**This theme and file are created by me & publish under GPLv3