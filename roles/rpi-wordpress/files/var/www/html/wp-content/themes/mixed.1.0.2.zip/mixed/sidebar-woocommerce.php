<aside class="sidebar-wrapper" role="complemantary">
				
	<div class="col-sm-3">

		<?php if(dynamic_sidebar('woocommerce')); ?>

	</div> <!-- end col-sm-4 -->

</aside> <!-- end mixed-sidebar -->