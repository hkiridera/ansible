<?php $scorline_theme_options = scoreline_get_options(); ?>
<div class="scoreline-callout-wrapper">
	<div class="container-fluid scoreline-callout space">
	    <div class="container">
			<div class="row scoreline-callout-desc">
		        <?php if($scorline_theme_options['fc_title'] !='') { ?>
				<div class="col-md-12">
				    <h2><?php echo esc_attr($scorline_theme_options['fc_title']);?></h2>
				</div>
			    <?php } ?>
			
				<?php if($scorline_theme_options['fc_btn_txt'] !='') { ?>
				<div class="col-md-12 btn">
					<a href="<?php echo esc_url($scorline_theme_options['fc_btn_link']); ?>"><?php echo esc_attr($scorline_theme_options['fc_btn_txt']); ?></a>
					<?php } ?>
		        </div>
	        </div>
        </div>
    </div>
</div>