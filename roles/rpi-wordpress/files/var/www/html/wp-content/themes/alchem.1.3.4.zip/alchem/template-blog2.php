<?php
/**
 * Template Name: Blog List Style 2
 *
 * @package Alchem
 * @since Alchem 1.0
 */
 global $alchem_blog_style , $alchem_css_class;
 $alchem_blog_style = '2';
 $alchem_css_class  = 'blog-list-wrap blog-grid row';
 get_template_part('template','blog');