<?php
/*
 * stock tiker section
 */
if (has_action('mp_profit_section_stock_ticker')) {
    do_action('mp_profit_section_stock_ticker');
}
