ProtoPress WordPress Theme
GNU GPL v3
Copyrights 2015. Rohit Tripathi.
http://rohitink.com/2015/03/18/protopress-multipurpose-theme/


Protopress
=========

Protopress is the Last WordPress theme you will Ever need. It is loaded with tons of Features including Multiple Layouts, Featured Content Areas, Showcases, Fully Configurable Sidebar width, Advanced Menu and Navigation system, Featured Images, Slider with 3D Effects, Google Fonts, High Quality Animation throughout the theme without compromising on the Professionalism. And yes, this theme is 100% Responsive and will work on all your devices from Mobiles, Tablets to Desktops.


Getting Started
---------------

How to Install the Theme?

1. Go to WP Admin > Appearance > Themes > Add New.
2. Search for "ProtoPress".
3. Click on Install and Activate.

Alternatively,

1. Go to WP Admin > Appearance > Themes > Add New > Upload.
2. Upload the protopress.zip file, in which you found this README.txt
3. Click on Install and Activate.

Setting it Up
-------------

This theme is built using Customizer. So to Configure theme settings like Featured Content Area, Sliders, Social Icons, etc from 
	
	Dashboard > Appearance > Customizer	
	
	

Report Bugs / Theme Support
---------------------------

ProtoPress is a relatively new theme, and could contain some hidden bugs. So, if you find any please report them at the following URL:

http://rohitink.com/2015/03/18/protopress-multipurpose-theme/


External Resources / Licenses
-----------------------------

This theme is 100% GPL. And any external resources used and bundled with the theme are also Fully Compatible with the GPL.

1. Font Awesome
	- Code under MIT License
	- Font under SIL OFL 1.1 
	- http://fortawesome.github.io/Font-Awesome/
	
2. Bootstrap
	- MIT License
	- http://getbootstrap.com
	
3. Hover.css
	- MIT License
	- http://ianlunn.github.io/Hover/
	
4. Slicknav
	- MIT License
	- https://github.com/ComputerWolf/SlickNav

5. BX Slider
	- MIT License
	- http://stevenwanderski.com, http://bxcreative.com			
	
6. Nivo Slider
	- MIT LIcense
	- https://github.com/gilbitron/Nivo-Slider	
	
7. _S/Underscores Framework
	- GPL v2
	- http://underscores.me
	
8. jQuery Flex Images
 	- https://github.com/Pixabay/jQuery-flexImages
 	- MIT License

9. Modernizer 			
	- MIT and BSD
	- http://modernizr.com
	
10. Responsive Menu
	- https://github.com/mattkersley/Responsive-Menu
	- MIT license
	

All Other Resources, apart from the ones mentioned above have been created by me fall under GPL v3 license of the theme.	

Screenshot Image Credits
------------------------

All the Images used in the Screenshot are Public Domain.
https://creativecommons.org/publicdomain/zero/1.0/

List of Images
	- http://pixabay.com/en/clock-time-stand-by-650753/
	- http://pixabay.com/en/alarm-phone-emergency-call-629777/
	- http://pixabay.com/en/mixing-desk-mixer-slide-control-351478/
	- http://pixabay.com/en/mugs-cups-table-wooden-massive-642113/
	- http://pixabay.com/en/studio-portrait-woman-face-model-660806/ 
	- http://pixabay.com/en/car-small-bus-van-transportation-677776/
	- http://pixabay.com/en/person-male-man-looking-sitting-677770/
	- http://pixabay.com/en/sparkler-holding-hands-firework-677774/
	- https://unsplash.com/photos/l5d9Zp7HO6o/download
	- http://pixabay.com/en/rail-railway-train-tracks-234318/

		