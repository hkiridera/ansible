<?php 
do_action( 'jbst_after_buddypress' );
do_action( 'jbst_footer' );
?>