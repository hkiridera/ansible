<?php
/**
 * Template Name: Blog List Style 3
 *
 * @package Alchem
 * @since Alchem 1.0
 */
 global $alchem_blog_style , $alchem_css_class;
 $alchem_blog_style = '3';
 $alchem_css_class  = 'blog-list-wrap blog-aside-image';
 get_template_part('template','blog');