<?php if(is_active_sidebar('main-top-sidebar')): ?>
		<?php dynamic_sidebar('main-top-sidebar'); ?>
<?php endif;?>