<!DOCTYPE html>
<html <?php language_attributes(); ?>
 
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    
    <?php wp_head(); ?>
</head>
 
<body <?php body_class(); ?>>
<?php global $neozee_do_not_duplicate; ?>
<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'neo-zee' ); ?></a>

    <!-- START CONTAINER -->
    <div class="container">
        <!-- START HEADER -->

    </div>

<div class="upper-credit">
</div>

 <div class="header">
    <!-- START HEADER IMAGE & ADV AREA -->
        <hgroup>
            <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
        </hgroup>
<?php $header_image = get_header_image();
        if ( ! empty( $header_image ) ) { ?>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
                <img src="<?php header_image(); ?>" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" alt="" />
            </a>
<?php } // if ( ! empty( $header_image ) )
?>

        <div class="nz-header-widget">

            <?php if ( is_active_sidebar( 'header-ad' ) ) : ?>
                <div id="secondary" class="widget-area" role="complementary">
                    <?php dynamic_sidebar( 'header-ad' ); ?>
                </div><!-- #secondary -->
            <?php endif; ?>

        </div>


        <!-- START NAVIGATION -->
    
            <div class="top-nav" role="navigation">
                <?php wp_nav_menu( array( 'theme_location' => 'neozee-menu-header', 'container_class' => 'neozee_menu_class' ) ); ?>
            </div>
        <!-- END NAVIGATION -->

        <!-- END HEADER IMAGE & ADV AREA -->
     
    

        <!-- END HEADER -->

</div>

        