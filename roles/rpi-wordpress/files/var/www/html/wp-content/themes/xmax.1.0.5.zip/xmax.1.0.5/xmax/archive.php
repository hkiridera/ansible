<?php get_header(); ?>

<div class="kopa-entry-list">
    <?php 
    get_sidebar('main-top');
        
    $layout = get_theme_mod('blog-layout', 'small-thumb');
    get_template_part('module/blog', $layout);        
    ?>
</div>

<?php
get_footer();