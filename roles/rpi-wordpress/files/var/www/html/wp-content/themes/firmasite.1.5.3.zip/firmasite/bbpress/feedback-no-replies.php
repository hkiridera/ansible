<?php

/**
 * No Replies Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice alert alert-info">
	<p><?php _e( 'Oh bother! No replies were found here!', 'firmasite' ); ?></p>
</div>
