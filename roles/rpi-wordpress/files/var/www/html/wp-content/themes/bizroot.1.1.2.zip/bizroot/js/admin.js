( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#bizroot-settings-metabox-container' ).tabs();

	});

} )( jQuery );
