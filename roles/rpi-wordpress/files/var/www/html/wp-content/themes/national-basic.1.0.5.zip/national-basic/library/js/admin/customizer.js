( function($) {
	$( window ).load( function() {
		$( '#customize-theme-controls' ).append(
			'<div class="premium-upgrade"><a href="https://themes.bavotasan.com/themes/national-wordpress-theme" target="_blank">' + Bavotasan_Customizer.upgradeAd + '<span class="dashicons dashicons-arrow-right-alt"></span></a></div>'
		);
	} );
} )(jQuery);