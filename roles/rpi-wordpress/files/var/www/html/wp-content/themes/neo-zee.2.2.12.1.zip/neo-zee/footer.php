<div class="footer">
	<div class="credit">
		<?php get_template_part( '/inc/credit', 'index' ); ?>
	</div>

</div>

<?php wp_footer(); ?>

</body>
</html>