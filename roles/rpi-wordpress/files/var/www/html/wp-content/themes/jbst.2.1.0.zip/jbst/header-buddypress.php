<?php
do_action( 'jbst_header' );
do_action( 'jbst_before_buddypress' );
?>