
					</div><!-- #content -->
				</div><!-- #primary -->
			</div><!-- .col-sm .clearfix -->
