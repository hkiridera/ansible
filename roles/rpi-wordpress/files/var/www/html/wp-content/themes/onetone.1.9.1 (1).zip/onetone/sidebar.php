<div class="sidebar">
    <div class="widget-area">
   <?php dynamic_sidebar('displayed-everywhere') ;?>
    </div>
  </div>