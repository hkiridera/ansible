= Tienda Basic =

* Created by Themes by bavotasan.com - http://themes.bavotasan.com/
* Built by c.bavota http://bavotasan.com/

== ABOUT TIENDA BASIC ==

Tienda Basic is an online storefront theme built specifically for WooCommerce. Set up a modern and beautifully designed eCommerce shop that works perfectly on handheld devices and desktops alike. With tons of great features and layout possibilities, Tienda will impress every customer while providing a smooth shopping experience. Also compatible with bbPress, BuddyPress and WPML. Uses Google Fonts for improved typeface readability.

== NOTES ==

* If you have a drop down list for your site navigation, the parent item should only be a grouping title with a "#" value for the URL parameter. The Bootstrap navbar requires a click to open the drop down list so any link that is set in the parent item will not work.

== LICENSES ==

Bootstrap, copyright 2011-2015 Twitter, Inc
Licensed under the terms of MIT license
http://getbootstrap.com/

SASS, copyright Hampton Catlin, Nathan Weizenbaum
Licensed under the terms of MIT license
http://sass-lang.com/

html5shiv
Dual-licensed under the terms of the GNU GPL, Version 2, and the MIT license
http://code.google.com/p/html5shiv/

Font Awesome, copyright Dave Gandy
Licensed under the terms of MIT license
http://fortawesome.github.io/Font-Awesome/

Google Fonts
Licensed under the terms of the SIL Open Font license
http://www.google.com/fonts/

Stock Images - http://gratisography.com/
Licensed under the terms of CC0

== CHANGELOG ==

03/15/2016 v1.0.2
* Fixed search results pagination
* Fixed H1 tag issue
* Fixed search bar extending issue
* Increased header image default height
* Tweaked CSS
* Updated archive.php title code
* Updated text domain
* Updated language file

06/5/2015 v1.0.1
* Updated images
* Changed image license
* Added CSS tweak to about and preview page
* Added featured image to products
* Added screen reader CSS
* Updated language file

Public Release
01/29/2015