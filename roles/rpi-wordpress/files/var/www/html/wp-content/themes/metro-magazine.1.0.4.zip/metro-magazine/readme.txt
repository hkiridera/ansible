=== Metro Magazine ===

Author: Rara Theme (http://raratheme.com)

Tags: two-columns, right-sidebar, custom-background, custom-menu, featured-image-header, featured-images, flexible-header, post-formats, sticky-post, threaded-comments, translation-ready, theme-options, footer-widgets, blog, full-width-template, news

Requires at least: 4.6
Tested up to: 4.6.1
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Metro Magazine is a perfect responsive magazine style WordPress theme suitable for news, newspaper, magazine, sports, technology, food and blogs. It comes with a sleek and responsive layout design fit for presenting contents and images in a stunning way. The theme has been developed to be a completely versatile and is capable of adapting to various types of magazines with vast customization options. The Theme is Search Engine Optimized (SEO) to help you easily climb the google rank. It is also translation ready.
== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Documentation For Homepage Setup

Note : Before You continue with the section , make sure you have properly configured your homepage settings.

A. Featured Post Section

 1. Go to Appearance> Customize>Home Page Settings> Featured Post Section 
 2. Enable Featured Post Section in Home Page to display featured posts in Homepage Section
 3. Enable Featured Post Section in Archive Page to display featured posts in Archive Pages.
 4. Select Post One, Post Two, Post Three, Post Four, Post Five and Post Six.
 5. The Featured Image of the selected posts will be displayed under the featured Posts section.
 6. The selected Post Titles will be displayed under the featured Posts section.
 7. Click Save & Publish 

B. Top News Section

 1.  Go to Appearance> Customize>Home Page Settings>Top News Section 
 2.  Enable Top News Section to display it in Homepage Section
 3.  Enter Tops News label.
 4.  Select Post One, Post Two, Post Three, Post Four, Post Five and Post Six.
 5.  The Featured Image of the selected posts will be displayed under the section.
 6.  The selected Post Titles will be displayed under the section.
 7.  Click Save & Publish 

C. Category Section

 1.  Go to Appearance> Customize>Home Page Settings>Category Section
 2.  Choose Category One, Category Two, Category Three, Category Four and Category Five.
 3.  Click Save & Publish. 

For more documentation settings, please visit the link below.
https://raratheme.com/documentation/metro-magazine

External resources linked to the theme.

== Font-Awesome ==
* Font Awesome
https://fontawesome.github.io/Font-Awesome/, 
Copyright (c); Dave Gandy, http://fontawesome.io/license/

== Google font ==
* Ubuntu Font by through Google Font 
https://www.google.com/fonts/specimen/Ubuntu

* Playfair+Display Font by through Google 
Font https://www.google.com/fonts/specimen/Playfair+Display

# Images
All images are under Creative Commons Public Domain deed CC0.

1. https://picjumbo.imgix.net/P1020515.jpg?q=40&w=1650&sharp=30
2. https://picjumbo.com/strawberry-milkshake-in-lovely-heart-shaped-cup/
3. https://picjumbo.com/young-girl-holding-her-fashion-sunglasses-in-hand/
4. https://picjumbo.com/wonderful-city-of-mikulov-czech-republic/
5. https://picjumbo.com/lake-shore-and-forests-scenery-in-romania/
6. https://picjumbo.com/outdoor-office-workspace-setup-with-high-ceiling/

# JS
All the JS are licensed under GPLv2 or later

* jquery.sidr.js, https://github.com/artberri/sidr, (C) 2013 Alberto Varela, MIT License, https://github.com/artberri/sidr/blob/master/LICENSE

* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)


* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)


All other resources and theme elements are licensed under the GPLv2 or later


Metro Magazine WordPress Theme, Copyright Rara Theme 2015, Raratheme.com
Metro Magazine WordPress Theme is distributed under the terms of the GPLv2 or later


*  This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
== Change Log ==
1.0.4
* Fixed issue for video post format.
* Fixed found bugs.

1.0.3
* Social setting, video section and footer credit modified updated.
* Entertainment tag is added.
* Description Modified.
* Fixed found bugs.

1.0.2
* Fixed issues mentioned on tracs.

1.0.1
* Removed unnecessary files.
* screenshot changed
* Bug fixes.

1.0.0
* Initial Release