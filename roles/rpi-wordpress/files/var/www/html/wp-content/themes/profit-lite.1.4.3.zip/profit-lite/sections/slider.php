<?php
/*
 * slider section
 */
if (has_action('mp_profit_section_slider')) {
    do_action('mp_profit_section_slider');
}


