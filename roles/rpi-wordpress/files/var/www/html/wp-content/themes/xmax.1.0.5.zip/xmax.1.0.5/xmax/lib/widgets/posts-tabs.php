<?php
add_action( 'widgets_init', array('Xmax_Widget_Posts_Tabs', 'register'));

class Xmax_Widget_Posts_Tabs extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'xmax-widget-posts-tabs kopa-tab2-widget', 'description' => __('Display list of posts with tabs layout.', 'xmax'));
        $control_ops = array('width' => 'auto', 'height' => 'auto');
        parent::__construct('xmax-widget-posts-tabs', __('Xmax Posts - Tabs', 'xmax'), $widget_ops, $control_ops);
    }

    public static function register(){
        register_widget('Xmax_Widget_Posts_Tabs');
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;

        $instance['title']          = strip_tags($new_instance['title']);
        $instance['posts_per_page'] = (int) strip_tags($new_instance['posts_per_page']);
        $instance['orderby']        = isset($new_instance['orderby']) && in_array($new_instance['orderby'], array('date', 'popular', 'comment_count', 'rand')) ? $new_instance['orderby'] : 'date';
        $instance['category']       = (isset($new_instance['category']) && is_array($new_instance['category'])) ? array_filter($new_instance['category']) : array();       
        $instance['in']             = strip_tags($new_instance['in']);

        return $instance;
    }

    public function form($instance) {
        $instance = wp_parse_args((array) $instance, $this->get_default());        
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:', 'xmax'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr(strip_tags($instance['title'])); ?>" />
        </p>  

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('posts_per_page')); ?>"><?php _e('Number of posts:', 'xmax'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('posts_per_page')); ?>" name="<?php echo esc_attr($this->get_field_name('posts_per_page')); ?>" type="text" value="<?php echo esc_attr((int) $instance['posts_per_page']); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('orderby')); ?>"><?php _e('Order by:', 'xmax'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('orderby')); ?>" name="<?php echo esc_attr($this->get_field_name('orderby')); ?>">                
                <?php
                $orderbys = array(
                    'date'          => __('Latest news', 'xmax'),                    
                    'comment_count' => __('Most comments', 'xmax'),
                    'rand'          => __('Random', 'xmax')
                );
                foreach ($orderbys as $value => $title) {
                    ?>
                    <option value="<?php echo esc_attr($value); ?>" <?php selected($instance['orderby'], $value); ?>><?php echo esc_attr($title); ?></option>
                    <?php
                }
                ?>
            </select>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('category')); ?>"><?php _e('Categories:', 'xmax'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('category')); ?>" name="<?php echo esc_attr($this->get_field_name('category')); ?>[]" multiple="multiple" size="5">
                <option value="">&horbar; <?php _e('All', 'xmax'); ?> &horbar;</option>
                <?php
                $terms = get_terms('category');
                if ($terms) {
                    foreach ($terms as $term) {
                        $selected = in_array($term->term_id, $instance['category']) ? 'selected="selected"' : '';
                        ?>
                        <option value="<?php echo esc_attr($term->term_id); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_attr($term->name); ?></option>
                        <?php
                    }
                }
                ?>
            </select>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('in')); ?>"><?php printf('%s <i>%s</i>', __('In:', 'xmax'), __('(require Wordpress 3.7+)', 'xmax')); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('in')); ?>" name="<?php echo esc_attr($this->get_field_name('in')); ?>">                
                <?php
                $times = array(
                    ''          => __('-- All --', 'xmax'),
                    '-1 week'   => __('1 week', 'xmax'),
                    '-2 week'   => __('2 weeks', 'xmax'),
                    '-3 week'   => __('3 weeks', 'xmax'),
                    '-1 month'  => __('1 months', 'xmax'),
                    '-2 month'  => __('2 months', 'xmax'),
                    '-3 month'  => __('3 months', 'xmax'),
                    '-4 month'  => __('4 months', 'xmax'),
                    '-5 month'  => __('5 months', 'xmax'),
                    '-6 month'  => __('6 months', 'xmax'),
                    '-7 month'  => __('7 months', 'xmax'),
                    '-8 month'  => __('8 months', 'xmax'),
                    '-9 month'  => __('9 months', 'xmax'),
                    '-10 month' => __('10 months', 'xmax'),
                    '-11 month' => __('11 months', 'xmax'),
                    '-1 year'   => __('1 year', 'xmax'),
                    '-2 year'   => __('2 years', 'xmax'),
                    '-3 year'   => __('3 years', 'xmax'),
                    '-4 year'   => __('4 years', 'xmax'),
                    '-5 year'   => __('5 years', 'xmax')
                );
                foreach ($times as $value => $title) {
                    ?>
                    <option value="<?php echo esc_attr($value); ?>" <?php selected($instance['in'], $value); ?>><?php echo esc_attr($title); ?></option>
                    <?php
                }
                ?>
            </select>
        </p>

        <?php
    }

    public function get_query($instance, $args_extra = array()) {
        global $wp_version;

        $args = array(
            'post_type'           => array('post'),
            'posts_per_page'      => (int) $instance['posts_per_page'],
            'post_status'         => array('publish'),
            'ignore_sticky_posts' => true
        );

        if (!empty($instance['category'])) {
            $args['tax_query'][] = array(
                'taxonomy' => 'category',
                'field'    => 'id',
                'terms'    => $instance['category']
            );
        }

        if (isset($args['tax_query']) && (count($args['tax_query']) >= 2)) {
            $args['tax_query']['relation'] = ('true' == $instance['relation']) ? 'AND' : 'OR';
        }

        if (isset($instance['orderby'])) {
            switch ($instance['orderby']) {
                case 'comment_count':
                    $args['orderby'] = 'comment_count';
                    break;
                case 'rand':
                    $args['orderby'] = 'rand';
                    break;
                default:
                    $args['orderby'] = 'date';
                    break;
            }
        } else {
            $args['orderby'] = 'date';
        }

        if (version_compare($wp_version, '3.7', '>=')) {
            if (isset($instance['in']) && !empty($instance['in'])) {
                $in = $instance['in'];
                $y = date('Y', strtotime($in));
                $m = date('m', strtotime($in));
                $d = date('d', strtotime($in));

                $args['date_query'] = array(
                    array(
                        'after' => array(
                            'year'  => (int) $y,
                            'month' => (int) $m,
                            'day'   => (int) $d
                        )
                    )
                );
            }
        }

        if (!empty($args_extra)) {
            return array_merge($args, $args_extra);
        } else {
            return $args;
        }
    }

    protected function get_default() {
        return array(
            'title'          => '',
            'posts_per_page' => 5,
            'orderby'        => 'date',
            'category'       => array(),           
            'in'             => ''
        );
    }

    public function widget($args, $instance) {
        extract($args);

        $instance = wp_parse_args((array) $instance, $this->get_default());
        $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);

        echo  htmlspecialchars_decode(esc_html($before_widget));
        if (!empty($title))
            echo  htmlspecialchars_decode(esc_html($before_title . $title . $after_title));

        extract($instance);

        if($category):
            $tabs_prefix = wp_generate_password(4, false, false);
            $tabs_ids = array();

            echo '<ul class="nav nav-tabs">';
            $active = ' class="active"';
            foreach($category as $category_id){

                $name                   = get_term_field('name', $category_id, 'category');
                $slug                   = get_term_field('slug', $category_id, 'category');
                $tab_id                 = "tab-{$tabs_prefix}-{$slug}";
                $tabs_ids[$category_id] = $tab_id;

                printf('<li %s><a href="#%s" data-toggle="tab">%s</a></li>', $active, $tab_id, $name);

                $active = false;
            }
            echo '</ul>';
            echo '<div class="tab-content">';
            $is_active = true;
            foreach($category as $category_id){
                $instance['category'] = array($category_id);
                $this->get_tab_content($instance, $is_active, $tabs_ids[$category_id]);
                $is_active = false;
            }
            echo '</div>';
        endif;
        echo htmlspecialchars_decode(esc_html($after_widget));
    }

    public function get_tab_content($instance, $is_active = true, $tabs_id){
        $query      = $this->get_query($instance);
        $resuls_set = new WP_Query($query);

        $active = $is_active ? 'active' : '';

        if ($resuls_set->have_posts()):            
            ?>
            <div class="tab-pane <?php echo esc_attr($active); ?>" 
                id="<?php echo esc_attr($tabs_id); ?>">
                <ul class="clearfix">
                    <?php
                    while ($resuls_set->have_posts()):
                        $resuls_set->the_post();
                    ?>
                    <li>
                        <article class="entry-item clearfix">
                            <?php if(has_post_thumbnail()): ?>
                                <div class="entry-thumb">
                                    <a href="<?php echo esc_url(get_permalink()); ?>">
                                        <?php the_post_thumbnail('xmax-small-thumb', array('class' => 'img-responsive')); ?>
                                    </a>

                                    <span class="entry-view">
                                    <?php _e('Comments', 'xmax'); ?>
                                    <span><?php echo esc_attr((int)get_comments_number()); ?></span>
                                    </span>
                                </div>
                            <?php endif; ?>

                            <div class="entry-content">
                                <h2 class="entry-title">
                                    <a href="<?php the_permalink();?>"><?php the_title(); ?></a>
                                </h2>

                                <p class="entry-date"><?php _e('Posted:', 'xmax'); ?><span><?php echo esc_attr(get_the_date()); ?></span></p>
                            </div>
                        </article>
                    </li>
                    <?php endwhile; ?>
                </ul>
            </div>
            <?php      
        endif;
        wp_reset_postdata();
    }

}
