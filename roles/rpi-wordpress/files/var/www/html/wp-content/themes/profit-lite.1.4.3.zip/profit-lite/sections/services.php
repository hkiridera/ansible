<?php
/*
 * services section
 */
if (has_action('mp_profit_section_services')) {
    do_action('mp_profit_section_services');
}