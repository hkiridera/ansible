jQuery(document).ready(function(){
// var request = new XMLHttpRequest();
// request.open('GET', 'http://www.www-kurs.de/html.htm', true);
// request.onreadystatechange = function (anEvent) {
   // if (request.readyState == 4) {
      // if(request.status == 200) {
         // document.getElementById("result").innerHTML = request.responseText;
      // }
   // }
// };
// request.send(null);

//jQuery('#fbstream').load('http://www.www-kurs.de/html.htm');
});