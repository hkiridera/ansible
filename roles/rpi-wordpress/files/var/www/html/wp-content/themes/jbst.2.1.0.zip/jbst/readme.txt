=== JBST ===
Contributors: bassjobsen
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=SNYGRL7YNVYQW
Tags: one-column,two-columns,three-columns,left-sidebar,right-sidebar,responsive-layout,accessibility-ready,buddypress,custom-background,custom-colors,custom-header,custom-menu,theme-options
Requires at least: 3.6
Tested up to: 3.9
Stable tag: 2.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

JBST is a powerful theme framework that can be used as a standalone website builder or as a framework to create child themes for WordPress.

== Description ==

JBST is a powerful theme framework that can be used as a standalone website builder or as a framework to create child themes for WordPress. JBST build on the top of Twitter's Bootstrap 3 and is full customizable with LESS. Integrated customizer for easy responsive website building. Right-To-Left (RTL) support. It also has built in support for BuddyPress, BBpress and eCommerce (WooCommerce, JigoShop and WPeCommerce).
Download the <a href="https://raw.github.com/bassjobsen/Boilerplate-JBST-Child-Theme/master/jbstchildtheming.pdf">Child Theme Guide</a>.

== Assets ==
 
 * Bootstrap, http://www.getbooststrap.com/, Apache 2 license
 * less.php, http://lessphp.gpeasy.com/, Apache license 
 * Options Framework, http://wptheming.com/options-framework-plugin/, GPLv2
 * Custom Metaboxes and Fields, https://github.com/WebDevStudios/Custom-Metaboxes-and-Fields-for-WordPress,  Dual licensed under the MIT or GPL Version 2 licenses
 * WP LESS to CSS, http://wordpress.org/plugins/wp-less-to-css/, GPLv2
 * Respond.js, https://github.com/scottjehl/Respond, Dual MIT/BSD license
 * HTML5 Shiv v3.7.0 | @afarkas @jdalton @jon_neal @rem | MIT/GPL2 Licensed

-- fonts --
 * Glyphicons, http://glyphicons.com/, Apache 2 license
 * Google Fonts, https://developers.google.com/fonts/, Google Fonts are licensed under open source licenses 
 
-- images -- 
 * assets/img/*, GPLv2 
