<?php get_header(); ?>   
		<div class="content">
			<div class="post-main">
				<center><h1><?php _e( 'Error 404 - Page Not Found', 'ecogray' ); ?></h1></center><br>
			</div> 			
		</div>


</div>
</div>
</div>
<?php get_footer(); ?>