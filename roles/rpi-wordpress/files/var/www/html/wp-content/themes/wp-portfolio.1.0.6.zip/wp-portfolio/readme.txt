=== WP PORTFOLIO ===

WP Portfolio is a Simple, Clean and Beautiful Responsive Free WordPress Portfolio Theme which adapts automatically to your tablets and mobile devices. WP Portfolio is specially designed for designers, photographers, artists and creatives. There are two post view layout (Grid and list), Social Profile Navigation and many more. Also has Custom Background, Header, Menu, Favicon, CSS, Webclip Icon, and Logo. Supports popular plugins like WooCommerce, bbPress, Breadcrumb NavXT, WP-PageNavi and Contact Form 7. It is also translation ready. Get free support at http://themehorse.com/support-forum/ and View beautiful portfolio demo site at http://themehorse.com/preview/wp-portfolio

=================================================================================

== THEME NOTES ==

- About Theme -
http://themehorse.com/themes/wp-portfolio

- Theme Demo -
http://themehorse.com/preview/wp-portfolio

- Theme Instruction -
http://themehorse.com/theme-instruction/wp-portfolio

- Free Support -
http://themehorse.com/support-forum

=================================================================================

== COPYRIGHT AND LICENSE ==

WP Portfolio, copyright 2016 themehorse.com
WP Portfolio is distributed under the terms of the GNU GPL
 
- WP Portfolio is built with the following resources -

Icon Fonts: Genericons - http://genericons.com
Copyright: Automattic, automattic.com
Licensed: GNU General Public License v2 or later

scripts.js: https://wordpress.org/themes/twentyfourteen
Copyright: Automattic, automattic.com
Licensed: GNU General Public License v2 or later

- Images used in screenshot -

https://pixabay.com/en/summer-holiday-holidays-recovery-1403147/
https://pixabay.com/en/cartoon-doodle-painting-people-1300894/
https://pixabay.com/en/scenic-landscape-art-flower-970894/
https://pixabay.com/en/buddha-face-statue-asia-buddhism-600236/
https://pixabay.com/en/artwork-colorful-art-flowers-vase-142879/
https://pixabay.com/en/steve-jobs-painting-apple-colors-1325111/
https://pixabay.com/en/artistic-bright-color-colored-2063/
https://pixabay.com/en/logodesign-web-design-website-1076200/
https://pixabay.com/en/flower-cartoon-painting-painted-1300902/
https://pixabay.com/en/frog-tree-frog-pop-up-folded-1173541/
https://pixabay.com/en/dragon-mythical-creatures-monster-1085225/
https://pixabay.com/en/castle-fantasy-cartoon-medieval-937979/
Copyright: http://pixabay.com
Licensed: Public Domain Images

The script html5.js is licensed under MIT
Other custom js, resources and theme elements are themehorse.com own creation and it is licensed under GNU General Public License v2

=================================================================================
