<?php
/**
 * @package Make
 */
?>

				</div>
			</div>

			<?php ttfmake_maybe_show_site_region( 'footer' ); ?>
		</div>

		<?php wp_footer(); ?>

	</body>
</html>