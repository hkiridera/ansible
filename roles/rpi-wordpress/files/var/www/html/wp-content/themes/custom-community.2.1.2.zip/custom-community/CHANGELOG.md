### v2.0.30
	- Has been added backwards compatibility for WP Title.
	- Has been fixed an empty value error in customizer.
	- Has been fixed the customizer preview on WordPress, v4.5.
	- Has been added text domains on translation functions.

### v1.0.0
	- Initial release.