<?php if (is_edit_visible()): ?>
<?php edit_post_link('編集', '<span class="edit"><span class="fa fa-pencil-square-o fa-fw"></span>', '</span>'); ?>
<?php endif; ?>