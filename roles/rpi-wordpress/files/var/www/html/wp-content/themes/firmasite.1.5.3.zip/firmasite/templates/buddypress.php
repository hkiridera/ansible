<div id="buddypress">
	<?php the_content(); ?>
</div>


