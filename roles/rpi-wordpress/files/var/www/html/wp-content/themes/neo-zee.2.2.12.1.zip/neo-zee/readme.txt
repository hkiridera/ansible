=== Neo Zee  ===

Contributors: Sultan Mustafijul Hoque, Poornima Prasath
Tags: light, white, buddypress, flexible-header, two-columns, right-sidebar, custom-header, fixed-layout, custom-background, custom-colors, custom-menu, featured-images, full-width-template, post-formats, sticky-post, translation-ready, responsive-layout, theme-options, threaded-comments, accessibility-ready
Requires at least: 4.2
Tested up to: 4.4
Stable tag: 2.2.12.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Neo Zee WordPress Theme, Copyright 2015 Sultan Mustafijul Hoque
Neo Zee is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of3
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see < http://www.gnu.org/licenses/ >.

== Description ==
Neo Zee is basically a simple responsive theme. With excellent support for all types of screen resolution, whether be a tablet or a small screen smartphone or a tylical cellphone, it gives excellent view enhanching user experiences.

* Responsive Layout
* Custom Header
* Post Formats
* Author Bio Box
* The GPL v2.0 or later license

= Copyrights for Resources used in this theme =

Everything (except the below) used in this theme has been created by Sultan Mustafijul Hoque, specifically for Neo Zee theme, and is distributed under GPL.

* custom-header.php - Derived from Twenty Twelve, distributed under GPL.
* editor-style.css - Derived from Twenty Twelve, distributed under GPL.
* editor-style.css - Derived from Twenty Twelve, distributed under GPL.


== Images ==
All images are created exclusevely for the theme Neo Zee. The screenhot included in this package is generated from the sister blog http://tunestreasure.com, which is copyrighted to Sultan Mustafijul Hoque. 

== Installation ==

1. Activate the theme
2. Go to the Header
3. Customize theme logo

* Setup theme options
Appearance -> Header

* Upload logo

