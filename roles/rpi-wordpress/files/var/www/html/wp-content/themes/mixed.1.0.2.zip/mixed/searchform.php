<form action="<?php echo esc_url(home_url('/')); ?>" method="get" id="searchform" class="searchform" role="search">
					
	<input type="text" value="" name="s" id="s" class="form-control" placeholder="<?php esc_attr_e('Search...','mixed'); ?>">

	<a class="search-submit"><i class="fa fa-search"></i></a>

</form>