(function($) {

    $(document).foundation();
$(".toggle-menu").on("click", function(){
  $("#menu").toggleClass("is-open");
});


})(jQuery);


