jQuery(document).ready( function( $ ) {

 $('#customize-theme-controls > ul').append('<li id="accordion-section-options" class="accordion-section control-section control-section-onetone-options" style="display: list-item;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box; padding: 10px 10px 20px;background: #fff;">'+onetone_admin_params.go_to_options+'</li>');


 });