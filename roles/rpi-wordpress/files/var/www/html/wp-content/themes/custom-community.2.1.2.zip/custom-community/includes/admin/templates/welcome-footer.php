<?php
/**
 * cc2 Welcome Screen footer template
 *
 * @author Fabian Wolf
 * @package cc2
 * @since 2.0.25
 */
 
?>

</div><!-- /.wrap -->
	
	
