-------------------------------------------------------
    Thank you for downloading Gridster-Lite
-------------------------------------------------------
This is a free theme released by ThemeFurnace.com under a GPL license.

Gridster is a neat and tidy grid-based portfolio theme for photographers, artists and designers to show off their work.

Gridster has been designed with simplicity in mind, it has a left-aligned sidebar which also serves to display the menu and site logo. The homepage is made up of a grid of your images which is responsive meaning it will change dimensions depending on what size screen you view it on. Simply create your categories and start adding images to create your site � no other configuration is needed.


Full version of this theme includes 18 More themes, customer support and more - see https://themefurnace.com/gridster-theme/


