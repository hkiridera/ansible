

### 1.1.4 - 21/04/2016

 Changes: 


 * Fixed #34 About us section responsive issue
