<script type="text/template" id="pt-pb-tmpl-form-css-class">
	<div class="pt-pb-option">
		<label for="css_class"><?php _e( 'CSS Class(es)', 'quest' ); ?>: </label>

		<div class="pt-pb-option-container">
			<input name="{{{pre}}}[css_class]" class="regular-text" type="text" value="{{{css_class}}}"/>

			<p class="description"><?php _e( 'Additional CSS classes, this will help you set custom styling. You can enter multiple classes by seperating them with spaces', 'quest' ) ?></p>
		</div>
	</div>
</script>