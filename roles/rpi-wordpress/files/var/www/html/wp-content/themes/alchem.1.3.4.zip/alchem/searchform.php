<form role="search" class="search-form" action="<?php echo esc_url(home_url('/'));?>">
 <div>
  <label class="sr-only"><?php _e("Search for","alchem");?>:</label>
   <input type="text" name="s" value="" placeholder="<?php _e("Search...","alchem");?>">
   <input type="submit" value="">
  </div>
 </form>