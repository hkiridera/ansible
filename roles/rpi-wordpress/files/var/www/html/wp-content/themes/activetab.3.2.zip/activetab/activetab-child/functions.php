<?php

/*
function activetab_remove_scripts() {
    wp_dequeue_style( 'activetab-bootstrap-theme-style' );
    wp_deregister_style( 'activetab-bootstrap-theme-style' );

    wp_dequeue_script( 'activetab-script' );
    wp_deregister_script( 'activetab-script' );
}
add_action( 'wp_enqueue_scripts', 'activetab_remove_scripts', 20 );
*/
