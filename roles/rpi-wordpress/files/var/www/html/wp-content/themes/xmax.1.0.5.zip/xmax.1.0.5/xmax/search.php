<?php get_header(); ?>

<div class="kopa-entry-list">
    <?php get_template_part('module/blog', 'small-thumb'); ?>
</div>

<?php
get_footer();