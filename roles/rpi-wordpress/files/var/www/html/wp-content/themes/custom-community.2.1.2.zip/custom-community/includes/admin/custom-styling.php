<?php
/**
 * Intermediate placeholder / wrapper
 * Formerly known as Custom Styling, now moved to Advanced Settings (advanced-settings.php)
 * 
 * @author Fabian Wolf
 * @package cc2
 * @since 2.0-r1
 */

@include_once('advanced-settings.php');
