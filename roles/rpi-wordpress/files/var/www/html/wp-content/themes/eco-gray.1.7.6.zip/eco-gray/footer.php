<div class="afooter2">
	<div class="footer">


		<div class="row">
			<div class="sidebar-footer span2">
				<?php dynamic_sidebar( 'footer' ); ?>
			</div>
		</div>

		<div class="mlogo">
			<div class="sidebar-user2 span2"><?php _e( 'Powered by', 'ecogray' ); ?> <a href="http://wordpress.org" target="_blank">WordPress</a>. <?php _e( 'Theme', 'ecogray' ); ?> <a href="http://justpx.com/" target="_blank">Eco Gray</a></div>
		</div>		
	</div>
</div>


	<?php wp_footer(); ?>
</body>
</html>