//ここにスキンで利用するJavaScriptを記入する
