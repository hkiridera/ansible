(function($) {

    $(document).foundation();	
	
})(jQuery);

