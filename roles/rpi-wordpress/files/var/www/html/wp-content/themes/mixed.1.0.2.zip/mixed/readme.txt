For your any question or request please feel free to contact me. I will be happy to help => mail@burak-aydin.com


== Copyright ==
Mixed, Burak Aydin Copyright 2014
Mixed is distributed under the terms of the GNU GPL

 
Mixed is built with the following resources:

Icon Fonts: Font Awesome - http://fontawesome.io/
License: Font: SIL OFL 1.1, CSS: MIT License

Bootstrap - Copyright 2011-2014 Twitter, Inc.
Licensed under MIT

HTML5 Shiv - https://github.com/aFarkas/html5shiv
Licensed under MIT

SmoothScroll - https://github.com/galambalazs/smoothscroll
Licensed under MIT

jQuery Fraction Slider - http://jacksbox.de/stuff/jquery-fractionslider/
Licensed under MIT

Advanced Custom Fields - http://www.advancedcustomfields.com/
Licensed under GPL

Redux Framework - http://reduxframework.com/
Licensed under GPL v2 or later

TGM Plugin Activation - http://tgmpluginactivation.com/
Licensed under the GPL-2.0 or later license

FitVids 1.0.3 ( for responsive video ) - http://fitvidsjs.com/
License under the WTFPL 


== Screenshot images ==
WooCommerce Sample Data
https://github.com/woothemes/woocommerce/blob/master/dummy-data/dummy-data.xml