jQuery(document).ready(function($) {
	$('#accordion-section-title_tagline').prepend(
	    '<div class="user_sticky_note">'+            
	    '<span class="sticky_info_row"><a class="button" href="http://demo.accesspressthemes.com/accesspress-mag/" target="_blank">Demo</a>'+
	    '<span class="sticky_info_row"><a class="button" href="http://doc.accesspressthemes.com/accesspress-mag-documentation/" target="_blank">Documentation</a></span>'+
	    '<span class="sticky_info_row"><a class="button" href="https://accesspressthemes.com/support/forum/themes/free-themes/theme-accesspress-mag/" target="_blnak">Support forum</a></span>'+
	    '<span class="sticky_info_row"><a class="button" href="https://accesspressthemes.com/wordpress-themes/" target="_blank">More Details</a></span>'+
	    '</div>'
	);
});