<?php if(is_active_sidebar('right-sidebar')): ?>
	<aside class="sidebar widget-area-5">
		<?php dynamic_sidebar('right-sidebar'); ?>
	</aside>
<?php endif;?>