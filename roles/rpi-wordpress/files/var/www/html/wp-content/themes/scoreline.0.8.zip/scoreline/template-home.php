<?php //Template Name:HOME
$scorline_theme_options = scoreline_get_options(); 
get_header();
get_template_part('home', 'slider');
if ($scorline_theme_options['show_service']=="on"){
get_template_part('home', 'services');
}
if ($scorline_theme_options['show_ex_sec']=="on"){
get_template_part('home', 'extra');
}
if ($scorline_theme_options['show_blog']=="on"){
get_template_part('home', 'blog');
}
if ($scorline_theme_options['show_callout']=="on"){
get_template_part('footer', 'callout');
}
get_footer();
?>
