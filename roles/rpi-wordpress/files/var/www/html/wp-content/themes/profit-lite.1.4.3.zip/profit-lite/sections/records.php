<?php
/*
 * records section
 */
if (has_action('mp_profit_section_records')) {
    do_action('mp_profit_section_records');
}
