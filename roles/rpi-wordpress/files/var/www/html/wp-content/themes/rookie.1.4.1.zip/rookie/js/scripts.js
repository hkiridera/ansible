/**
 * scripts.js
 *
 * Custom scripts for the Rookie theme.
 */
( function( $ ) {
	$('.comment-metadata time').timeago();
} )( jQuery );
