<h1 class="post-title entry-title"><?php the_title(); ?></h1>
<?php get_template_part('parts/single-author-date'); ?>