jquery.nicescroll
version 3.6.0
copyright 2014-11-21 InuYaksa*2014
licensed under the MIT

http://nicescroll.areaaperta.com/
https://github.com/inuyaksa/jquery.nicescroll


Source for bg.jpg image:  https://download.unsplash.com/photo-1420819453217-57b6badd9e19
Source for screenshot image: https://stocksnap.io/photo/S35JHGOU8W

