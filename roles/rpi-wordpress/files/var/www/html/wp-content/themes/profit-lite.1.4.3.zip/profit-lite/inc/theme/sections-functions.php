<?php

/*
 * Features section
 *
 * @see mp_profit_after_sidebar_features_function()
 * @see mp_profit_before_sidebar_features_function()
 */

if (!function_exists('mp_profit_after_sidebar_features_function')) {

    function mp_profit_after_sidebar_features_function() {
        return '';
    }

}
if (!function_exists('mp_profit_before_sidebar_features_function')) {

    function mp_profit_before_sidebar_features_function() {
        return '';
    }

}
/*
 * Records section
 *
 * @see mp_profit_after_sidebar_records_function()
 * @see mp_profit_before_sidebar_records_function()
 */

if (!function_exists('mp_profit_after_sidebar_records_function')) {

    function mp_profit_after_sidebar_records_function() {
        return '';
    }

}
if (!function_exists('mp_profit_before_sidebar_records_function')) {

    function mp_profit_before_sidebar_records_function() {
        return '';
    }

}
/*
 * Team section
 *
 * @see mp_profit_after_sidebar_team_function()
 * @see mp_profit_before_sidebar_team_function()
 */

if (!function_exists('mp_profit_after_sidebar_team_function')) {

    function mp_profit_after_sidebar_team_function() {
        return '';
    }

}
if (!function_exists('mp_profit_before_sidebar_team_function')) {

    function mp_profit_before_sidebar_team_function() {
        return '';
    }

}
/*
 * Pricing section
 *
 * @see mp_profit_after_sidebar_pricing_function()
 * @see mp_profit_before_sidebar_pricing_function()
 */

if (!function_exists('mp_profit_after_sidebar_pricing_function')) {

    function mp_profit_after_sidebar_pricing_function() {
        return '';
    }

}
if (!function_exists('mp_profit_before_sidebar_pricing_function')) {

    function mp_profit_before_sidebar_pricing_function() {
        return '';
    }

}
/*
 * Newsletter section
 *
 * @see mp_profit_after_sidebar_newsletter_function()
 * @see mp_profit_before_sidebar_newsletter_function()
 */

if (!function_exists('mp_profit_after_sidebar_newsletter_function')) {

    function mp_profit_after_sidebar_newsletter_function() {
        return '';
    }

}
if (!function_exists('mp_profit_before_sidebar_newsletter_function')) {

    function mp_profit_before_sidebar_newsletter_function() {
        return '';
    }

}
/*
 * Testimonials section
 *
 * @see mp_profit_after_sidebar_testimonials_function()
 * @see mp_profit_before_sidebar_testimonials_function()
 */

if (!function_exists('mp_profit_after_sidebar_testimonials_function')) {

    function mp_profit_after_sidebar_testimonials_function() {
        return '';
    }

}
if (!function_exists('mp_profit_before_sidebar_testimonials_function')) {

    function mp_profit_before_sidebar_testimonials_function() {
        return '';
    }

}
/*
 * Google map section
 *
 * @see mp_profit_after_sidebar_location_function()
 * @see mp_profit_before_sidebar_location_function()
 */

if (!function_exists('mp_profit_after_sidebar_location_function')) {

    function mp_profit_after_sidebar_location_function() {
        return '';
    }

}
if (!function_exists('mp_profit_before_sidebar_location_function')) {

    function mp_profit_before_sidebar_location_function() {
        return '';
    }

}