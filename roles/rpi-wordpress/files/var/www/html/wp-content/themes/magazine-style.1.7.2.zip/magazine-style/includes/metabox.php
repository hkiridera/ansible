<?php
/**
 * Add meta box
 *
 */
function magazinesingle_add_meta_boxes( $post ){
	add_meta_box( 'food_meta_box', __( 'Post Layout Select [Pro Only]', 'magazine' ), 'magazinesingle_build_meta_box', 'post', 'side', 'high' );
}
add_action( 'add_meta_boxes', 'magazinesingle_add_meta_boxes' );
/**
 * Build custom field meta box
 *
 * @param post $post The post object
 */
function magazinesingle_build_meta_box( $post ){
	// make sure the form request comes from WordPress
	wp_nonce_field( basename( __FILE__ ), 'magazinesinglemeta_meta_box_nonce' );
	// retrieve the _food_magazinesinglemeta current value
	$current_magazinesinglemeta = get_post_meta( $post->ID, '_food_magazinesinglemeta', true );
	
	
	
	
	?>
	<div class='inside'>

		<h4><span class="dashicons dashicons-layout"></span><?php _e( 'Layout Select for current post only - for website layout please choose from theme options', 'magazine' ); ?></h4>
		<p>
			<input type="radio" name="magazinesinglemeta" value="rsd" <?php checked( $current_magazinesinglemeta, 'rsd' ); ?> /> <?php _e('Right Sidebar - Default','magazine'); ?><br />
			<input type="radio" name="magazinesinglemeta" value="ls" <?php checked( $current_magazinesinglemeta, 'ls' ); ?> /> <?php _e('Left Sidebar','magazine'); ?><br/>
			<input type="radio" name="magazinesinglemeta" value="lr" <?php checked( $current_magazinesinglemeta, 'lr' ); ?> /><?php _e('Left - Right Sidebars','magazine'); ?> <br/>
			<input type="radio" name="magazinesinglemeta" value="fc" <?php checked( $current_magazinesinglemeta, 'fc' ); ?> /> <?php _e('Full Content - No Sidebar','magazine'); ?>
		</p>

		

	</div>
	<?php
}
/**
 * Store custom field meta box data
 *
 * @param int $post_id The post ID.
 * @link https://codex.wordpress.org/Plugin_API/Action_Reference/save_post
 */
function food_save_meta_box_data( $post_id ){
	// verify meta box nonce
	if ( !isset( $_POST['magazinesinglemeta_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['magazinesinglemeta_meta_box_nonce'], basename( __FILE__ ) ) ){
		return;
	}
	// return if autosave
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ){
		return;
	}
  // Check the user's permissions.
	if ( ! current_user_can( 'edit_post', $post_id ) ){
		return;
	}
	// store custom fields values
	// magazinesinglemeta string
	if ( isset( $_REQUEST['magazinesinglemeta'] ) ) {
		update_post_meta( $post_id, '_food_magazinesinglemeta', sanitize_text_field( $_POST['magazinesinglemeta'] ) );
	}

}
add_action( 'save_post', 'food_save_meta_box_data' );