<?php get_header() ?>
<div class="box big-box">
<?php get_template_part("bread") ?>

<h1 class="box-header main-color-font"><span class="lsf">frustrate </span>404 Not Found</h1>

<P style="margin-bottom: 30px;">お探しのページはございません</p>

</div><!-- .big-box -->

<?php get_template_part("cat_lists") ?>


<?php get_sidebar() ?>
<?php get_footer() ?>