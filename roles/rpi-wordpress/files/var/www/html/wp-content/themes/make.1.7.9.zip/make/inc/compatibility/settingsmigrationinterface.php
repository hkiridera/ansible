<?php
/**
 * @package Make
 */

/**
 * Interface MAKE_Compatibility_SettingsMigrationInterface
 *
 * @since 1.7.0.
 */
interface MAKE_Compatibility_SettingsMigrationInterface extends MAKE_Util_ModulesInterface {}