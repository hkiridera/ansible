<?php get_header(); ?>

<div class="kopa-entry-list">
<?php
  if (have_posts()):
      while (have_posts()) : the_post();
					$post_id     = get_the_ID();
					$post_url    = get_permalink();
					$post_title  = get_the_title();
					$post_format = get_post_format();
          ?>                              
          <div <?php post_class('kopa-entry-post'); ?>>

              <header class="clearfix">

                  <h4 class="entry-title"><?php the_title(); ?></h4>

                  <div class="entry-meta clearfix">
                     
                          <p class="entry-date">
                          	<?php _e('Posted:', 'xmax'); ?> 
                          	<span><?php echo get_the_date(); ?></span>
                          </p>
                                          
                          <p class="entry-categories">
                          	<?php _e('In:', 'xmax'); ?> 
                          	<?php the_category(', '); ?>
                          </p>
                                           
                          <p class="entry-comment">
                          	<?php 
	                          	comments_popup_link(
		                          	__('No Comment', 'xmax'), 
		                          	__('1 Comment', 'xmax'), 
		                          	__('% Comments', 'xmax'), 
		                          	'', 
		                          	__('0 Comment', 'xmax'));
	                          ?>
                          </p>
                     
                  </div>
              </header>

              <div class="entry-content">
              		<div class="entry-thumb">
                      <?php the_post_thumbnail('xmax-single-post'); ?>
                  </div>
                  
                  <?php the_content(); ?>

                  <?php
                  wp_link_pages(array(
											'before'         => '<div class="page-link clearfix"><div class="pull-right"><span class="page-links-title">' . __('Parts: ', 'xmax') . '</span>',
											'after'          => '</div></div>',
											'next_or_number' => 'number',
											'pagelink'       => '<span>%</span>',
											'echo'           => true
                  ));
                  ?>

              </div>

              <?php if (has_tag()): ?>
                <div class="single-post-bottom">                      
                  <div class="kopa-tag-box clearfix">                      
                      	<?php the_tags('', ' ', ''); ?>                                                
                  </div>                      
                </div>
              <?php endif; ?>

              <?php get_template_part('module/post', 'adjacent'); ?>
              <!--/kopa-next/prev-post-->

              <?php get_template_part('module/post', 'related'); ?>
              <!--/kopa-recent-post-->

              <?php get_template_part('module/post', 'author'); ?>
              <!--/kopa-about-author-->              
          </div>

          <?php comments_template(); ?>
          
          <?php
      endwhile;
  else:
      printf('<blockquote>%1$s</blockquote>', __('Nothing Found...', 'xmax'));
  endif;
  ?>
</div>

<?php
get_footer();