<?php

/* Set content width value based on the theme's design */
if ( ! isset( $content_width ) )
	$content_width = 1200;

if ( ! function_exists( 'neozee_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */

function neozee_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on _s, use a find and replace
	 * to change '_s' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'neo-zee', get_template_directory() . '/language' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/* Add theme support for custom backgrounds. */
	add_theme_support('custom-background');

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	/* Set custom thumbnail dimensions */
	set_post_thumbnail_size( 125, 125, true );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'neozee-menu-header' => __( 'Header', 'neo-zee' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/* Add support for custom menus. */
	add_theme_support( 'menus' );

	// This theme styles the visual editor with editor-style.css to match the theme style.
	add_editor_style( 'editor-style.css' );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'neozee_custom_background_args', array(
		'default-color'	=> 'ffffff',
		'default-attachment' => 'fixed',
		'default-image' => '',
	) ) );

}
endif; // neozee_setup
add_action( 'after_setup_theme', 'neozee_setup' );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function neozee_widgets_init() {
	register_sidebar(array(
		'name' => __('Sidebar', 'neo-zee'),
		'id'   => 'sidebar',
		'description'   => __('This is the widgetized sidebar.', 'neo-zee'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>'
	));
	register_sidebar(array(
		'name' => __('Header Ad (970x90)', 'neo-zee'),
		'id'   => 'header-ad',
		'description'   => __('This is the header ad area.', 'neo-zee'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>'
	));
	register_sidebar(array(
		'name' => __('Introductory Area - Below Navigation', 'neo-zee'),
		'id'   => 'static-area',
		'description'   => __('This widget is to be placed after the navigation menu, i.e. before latest posts.', 'neo-zee'),
		'before_widget' => '<div id="%1$s" class="entry-static post-header-static clear">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>'
	));

}
add_action( 'widgets_init', 'neozee_widgets_init' );


function neozee_load_scripts() {
	/* Enqueue custom Javascript here using wp_enqueue_script(). */

	/* Load the comment reply JavaScript. */
	if ( is_singular() && get_option( 'thread_comments' ) && comments_open() )
		wp_enqueue_script( 'comment-reply' );
}


/* Dynamic Copyright Date */
function neozee_copyright() {
global $wpdb;
$copyright_dates = $wpdb->get_results("
SELECT
YEAR(min(post_date_gmt)) AS firstdate,
YEAR(max(post_date_gmt)) AS lastdate
FROM
$wpdb->posts
WHERE
post_status = 'publish'
");
$output = '';
if($copyright_dates) {
$copyright = "&copy; " . $copyright_dates[0]->firstdate;
if($copyright_dates[0]->firstdate != $copyright_dates[0]->lastdate) {
$copyright .= '-' . $copyright_dates[0]->lastdate;
}
$output = $copyright;
}
return $output;
}



// enable threaded comments
function neozee_enable_threaded_comments(){
if (!is_admin()) {
if (is_singular() AND comments_open() AND (get_option('thread_comments') == 1))
wp_enqueue_script('comment-reply');
}
}
add_action('wp_enqueue_scripts', 'neozee_enable_threaded_comments');


/**
 * Enqueue scripts and styles
 */
function neozee_scripts() {
	wp_enqueue_style( 'neo-zee-style', get_stylesheet_uri() );
}

add_action( 'wp_enqueue_scripts', 'neozee_scripts' );



/**
* Implement Custom NeoZee Functions
*/
require( get_template_directory() . '/functions/neozee-custom.php' );


/**
 * Implement the Custom Header feature
 */
require( get_template_directory() . '/inc/custom-header.php' );


?>