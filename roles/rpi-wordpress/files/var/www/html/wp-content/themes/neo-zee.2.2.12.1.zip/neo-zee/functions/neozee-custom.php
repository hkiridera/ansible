<?php



// Changing excerpt length
function neozee_excerpt_length($length) {
return 100;
}
add_filter('excerpt_length', 'neozee_excerpt_length');

// Changing excerpt more
function neozee_excerpt_more($more) {
return ' ...';
}
add_filter('excerpt_more', 'neozee_excerpt_more');




?>