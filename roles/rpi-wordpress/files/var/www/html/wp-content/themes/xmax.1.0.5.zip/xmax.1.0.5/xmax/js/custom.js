/*
 * ------------------------------------------------------------
 * DOCUMENT.READY
 * ------------------------------------------------------------
 */
jQuery(document).ready(function() {
    /*
     * ------------------------------------------------------------
     * NAVIGATION
     * ------------------------------------------------------------
     */
    if ( jQuery('.sf-menu').length > 0 ){
        jQuery('.sf-menu').superfish({
            speed: 'fast',
            speedOut: 'fast',
            delay: 0
        });
    }

    jQuery('.top-menu').superfish({
        speed: 'fast',
        speedOut: 'fast',
        delay: 0
    });

    /*
     * ------------------------------------------------------------
     * OWL CAROUSEL
     * ------------------------------------------------------------
     */
    jQuery(".menu-owl-carousel").owlCarousel({
        singleItem: true,
        pagination: false,
        navigationText: false,
        navigation: true
    });
    jQuery(".owl-carousel3").owlCarousel({
        singleItem: true,
        pagination: false,
        navigationText: false,
        navigation: true
    });
    jQuery(".owl-carousel4").owlCarousel({
        singleItem: true,
        pagination: false,
        navigationText: false,
        navigation: true
    });
    var owl2 = jQuery(".owl-carousel1");
    owl2.owlCarousel({
        items: 2,
        itemsDesktop: [1024, 2],
        itemsDesktopSmall: [980, 2],
        itemsTablet: [640, 1],
        slideSpeed: 400,
        navigationText: false,
        navigation: true,
        pagination: false,
        autoPlay: true,
        stopOnHover: true
    });
    var owl3 = jQuery(".owl-carousel2");
    owl3.owlCarousel({
        items: 4,
        pagination: false,
        navigationText: false,
        navigation: true

    });
    jQuery('.owl-prev').addClass('fa fa-angle-left');
    jQuery('.owl-next').addClass('fa fa-angle-right');
    jQuery('.owl-carousel1 .owl-buttons .owl-prev').removeClass('fa fa-angle-left').addClass('fa fa-chevron-left');
    jQuery('.owl-carousel1 .owl-buttons .owl-next').removeClass('fa fa-angle-right').addClass('fa fa-chevron-right');
    /*
     * ------------------------------------------------------------
     * SOCIAL FILTER
     * ------------------------------------------------------------
     */
    jQuery('.social-filter > div span').click(function() {
        if (jQuery(".social-filter ul").is(":hidden")) {
            jQuery(".social-filter ul").slideDown("slow");
        } else {
            jQuery(".social-filter ul").slideUp();
        }
    });


    /*
     * ------------------------------------------------------------
     * SEARCH FORM
     * ------------------------------------------------------------
     */
    jQuery('.search-form input').on({
        focus: function() {
            if (kopa_variable.i18n.SEARCH === this.value)
                this.value = '';
        },
        blur: function() {
            if ('' === this.value)
                this.value = kopa_variable.i18n.SEARCH;
        }
    });

});


jQuery(window).load(function() {
    /*
     * ------------------------------------------------------------
     * MOBILE TOP MENU
     * ------------------------------------------------------------
     */
    if (jQuery(".top-menu-mobile").length > 0){
        jQuery(".top-menu-mobile").navgoco({
            accordion: true
        });
    }

    jQuery(".top-nav-mobile > .pull").click(function() {
        jQuery(".top-menu-mobile").slideToggle("slow");
    });
    /*
     * ------------------------------------------------------------
     * MOBILE TOP MENU FIX
     * ------------------------------------------------------------
     */
    jQuery('.main-nav-mobile > .pull').click(function() {
        if (jQuery(".main-menu-mobile").is(":hidden")) {
            jQuery(".main-menu-mobile").slideDown("slow");
        } else {
            jQuery(".main-menu-mobile").slideUp("slow").animate(500);
        }
    });

    jQuery('.kopa-close').click(function() {
        jQuery(this).parent(".main-menu-mobile").css("display", "none");
    });

    /*
     * ------------------------------------------------------------
     * FIX IE8
     * ------------------------------------------------------------
     */
    jQuery(" ul.top-menu li ul li:last-child").css("border", "none");
    jQuery(".kopa-home-3 .widget-area-1 > .widget:last-child").css("margin-bottom", "35px");
    jQuery(".kopa-main-nav ul.main-menu li:last-child a").css("border-right", "none");
    jQuery(".widget-area-2 .widget:last-child, .widget-area-3 .widget:last-child, .widget-area-6 .widget:last-child, .widget-area-12 .widget:last-child, .widget-area-13 .widget:last-child").css("margin-bottom", "0");
    jQuery(".widget-area-14 .widget:last-child").css("border", "none");
    jQuery(".kopa-breadcrumb li:last-child:before").css("display", "none");
    jQuery(".article-list-3 ul li:nth-child(2)").css({
        "border": "none",
        "padding-top": "10px"
    });
    jQuery(".widget-area-16 .kopa-article-list-widget ul li:last-child").css({
        "border-bottom": "1px solid #f1f1f1",
        "padding-bottom": "15px"
    });



    /*
     * ------------------------------------------------------------
     * BACK TO TOP
     * ------------------------------------------------------------
     */
    if (jQuery("#back-top").length > 0) {
        jQuery(window).scroll(function() {
            if (jQuery(this).scrollTop() > 200) {
                jQuery('#back-top').fadeIn();
            } else {
                jQuery('#back-top').fadeOut();
            }
        });
        /* scroll body to 0px on click */
        jQuery('#back-top a').click(function() {
            jQuery('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
    }
    /*
     * ------------------------------------------------------------
     * FILTER TAB
     * ------------------------------------------------------------
     */
    var tab_a = jQuery(".kopa-tab-1-widget .dropdown-menu > li a");
    tab_a.click(function() {
        var tab_id = jQuery(this).attr("href");
        jQuery(tab_id).find("a").click();
        var tab_text = jQuery(tab_id).find("a").text();
        jQuery(this).closest(".dropdown").find("> a").text(tab_text);
    });
    var tab_b = jQuery(".kopa-tab-1-widget .nav-tabs > li > a");
    tab_b.click(function() {
        var tab_text_2 = jQuery(this).text();
        jQuery(this).closest(".kopa-tab-1-widget").find(".dropdown > a").text(tab_text_2);
    });
});