<div class="col-md-12">
	<div class="error_404">
		<h2><?php _e('404','scoreline'); ?></h2>
		<h4><?php _e('Whoops... Post Not Found !!!','scoreline'); ?></h4>
		<p><?php _e('We`re sorry, but the page you are looking for doesn`t exist.','scoreline'); ?></p>
		<p><a href="<?php echo esc_url(home_url( '/' )); ?>"><button id="commentSubmit" type="submit"><?php _e('Go To Homepage','scoreline'); ?></button></a></p>
	</div>
</div>