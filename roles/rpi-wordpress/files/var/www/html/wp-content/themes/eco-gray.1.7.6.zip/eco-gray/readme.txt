Google Webfonts: Open Sans. which are under Apache License, Version 2.0

Copyrights for Images used in this theme GPL3.
The Following images present in the 'images/' folder:
	eco-gray-bonus.jpg
	serach-button.jpg
	pro-vs-free.png
	eco-gray-pro-sidebar-home-4.jpg
	color.jpg	http://pixabay.com/en/fashion-shooting-guy-man-male-601563/ - Public Domain CC0


screenshot.png has been created by me. Copyright 2014 justpx.com
Eco Gray is distributed under the terms of the GNU GPL