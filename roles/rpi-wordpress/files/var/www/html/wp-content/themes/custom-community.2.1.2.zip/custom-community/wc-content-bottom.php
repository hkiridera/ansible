<?php
/**
 * WooCommerce Integration: After Content
 *
 * @package cc2
 * @since 2.0.25
 * @author Fabian Wolf
 */
 
?>

				</div><!-- close #content -->

				<?php if( cc2_display_sidebar( 'right' ) ) :
					get_sidebar( 'right' ); 
				endif; ?>


			</div><!-- close .row -->
		</div><!-- close .container -->
	</div><!-- close .main-content -->
