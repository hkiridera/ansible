<?php
function bluestreet_theme_data_setup()
{
	
	return $theme_options=array(
			//Logo and Fevicon header					
			'webriti_stylesheet'=>'default.css',
		
		);
}
?>