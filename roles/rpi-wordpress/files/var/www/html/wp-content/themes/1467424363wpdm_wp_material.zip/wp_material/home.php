<?php get_header() ?>

<?php get_template_part("ad_728") ?>

<div class="box big-box">

<h2 class="box-header main-color-font"><span class="lsf">star </span>New post</h2>

<?php get_template_part("loop") ?>

</div><!-- .big-box -->

<?php get_template_part("cat_lists") ?>

<?php get_sidebar() ?>
<?php get_footer() ?>