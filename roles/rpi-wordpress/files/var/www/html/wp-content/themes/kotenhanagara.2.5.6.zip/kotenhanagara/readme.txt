== Description ==
Theme Name: kotenhanagara
Author: Z.com byGMO
Author URI: https://cloud.z.com/jp/en/wp/
Description:Kotenhanagara is a simple, easy-to-use and highly customizable WordPress theme. Beautiful design inspiration came from Japanese Urushi lacqerware, varnished with the traditional manners. Background color can be customized as well as swappable flower patterned default background.
Version: 2.5.6
Tags: black, red, white, two-columns, right-sidebar, fixed-width, custom-header
License: GNU General Public License
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Copyright ==
Kotenhanagara WordPress theme, Copyright (C) 2015 Z.com byGMO
Kotenhanagara is licensed under the GPL.

Kotenhanagara WordPress theme is based on Underscores (_s) starter theme http://underscores.me/ - Copyright: Automattic, automattic.com

== License ==
Unless otherwise specified, all the theme files, scripts and images
are licensed under GNU General Public License version 2, see file license.txt.
The exceptions to this license are as follows:

-script.js is licensed under MIT
-html5.js is licensed under MIT

*Social media icons and background images are all designed by "Z.com by GMO" and distributed under the terms of the GNU GPL v2

== Instruction ==
-To display menus, please use "Custom menu" in widget area, not from "Menus" in Appearance.
-Please change background image not by uploading, but by choosing from Media Library.
When no background image is selected, it goes back to the default image.

== Changelog ==

Version 2.1
-Bug Fix
-Web Fonts now works in all text
-Now logo can be customized


== Theme Notes ==
You can drop your queries in our contact form in the following link.
info.hosting.jp@z.com