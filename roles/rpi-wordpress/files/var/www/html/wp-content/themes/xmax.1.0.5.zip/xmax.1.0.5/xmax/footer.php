        </div>        
        <?php get_sidebar('right'); ?>        
    </div>
    <div class="clear"></div>
</div>
<!--/end KOPA-MAIN-CONTENT-->

<?php if(is_active_sidebar('footer-1-sidebar') || is_active_sidebar('footer-2-sidebar') || is_active_sidebar('footer-3-sidebar') || is_active_sidebar('footer-4-sidebar')): ?>
<div class="bottom-sidebar clearfix">
    <div class="main-wrapper clearfix">
        <div class="bottom-sidebar-wrapper clearfix">
            <?php 
            get_sidebar('footer-1');
            get_sidebar('footer-2');
            get_sidebar('footer-3');
            get_sidebar('footer-4');
            ?>
        </div>
    </div>
</div>
<!--/end BOTTOM-SIDERBAR-->
<?php endif;?>

<footer id="kopa-footer">
    <?php
    #FOOTER MENU
    if (has_nav_menu('footer-nav')) {
        wp_nav_menu(array(
            'theme_location'  => 'footer-nav',
            'container'       => 'nav',
            'conatiner_id'    => 'footer-nav',
            'container_class' => 'footer-nav',
            'menu_id'         => 'footer-menu',
            'menu_class'      => 'footer-menu clearfix'));
    }

    $footer_information = get_theme_mod('copyright');
    if ($footer_information): ?>
        <div class="copyright">
            <p><?php echo htmlspecialchars_decode(esc_html($footer_information)); ?></p>
        </div>            
    <?php endif; ?>
</footer>
</div>
<p id="back-top"><a href="#top" rel="nofollow"><i class="fa fa-angle-up"></i></a></p>
<?php wp_footer(); ?>
</body>