jQuery(document).ready(function($){

    $('.surfarama-color-field').wpColorPicker();

});