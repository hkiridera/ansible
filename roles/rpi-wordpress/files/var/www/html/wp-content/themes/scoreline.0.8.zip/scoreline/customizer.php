<?php
add_action( 'customize_register', 'scoreline_customizer' );

function scoreline_customizer( $wp_customize ) {
	wp_enqueue_style('customizr', get_template_directory_uri() .'/css/customizr.css'); 
	$scorline_theme_options = scoreline_get_options();	
	/* Genral section */
	$wp_customize->add_panel( 'scoreline_theme_option', array(
    'title' => __( 'Theme Options','scoreline' ),
    'priority' => 1,
	) );
    $wp_customize->add_section(
        'general_sec',
        array(
            'title' => __( 'Theme General Options','scoreline' ),
            'description' => __('Here you can customize Your theme general Settings','scoreline'),
			'panel'=>'scoreline_theme_option',
			'capability'=>'edit_theme_options',
            'priority' => 35,	
        ));
	
	// For Slider Settings
	$wp_customize->add_section(
        'slider_sec',
        array(
            'title' =>  __( 'Theme Slider Options','scoreline' ),
			'panel'=>'scoreline_theme_option',
            'description' => __('Here you can manage slider','scoreline'),
			'capability'=>'edit_theme_options',
            'priority' => 35,
        ) );
	for($i=1; $i<=4; $i++){
	$wp_customize->add_setting(
		'scoreline_options[slider_image_'.$i.']',
		array(
			'type'    => 'option',
			'default'=>'',
			'capability' => 'edit_theme_options',
			'sanitize_callback'=>'scoreline_sanitize_integer',
		));
	$wp_customize->add_control( 
	new scoreline_Slider_Image_Control( 
	$wp_customize, 'slider_image_'.$i,
	array(
		'label'    => 'Slider Image '.$i, 
		'section'  => 'slider_sec',
		'settings' => 'scoreline_options[slider_image_'.$i.']',
			
	) ) );
	}
	// For Service Section
	$wp_customize->add_section('service_section',array(
	'title'=>__("Home Service Options",'scoreline'),
	'panel'=>'scoreline_theme_option',
	'capability'=>'edit_theme_options',
    'priority' => 35
	));
	$wp_customize->add_setting(
		'scoreline_options[show_service]',
		array(
			'type'    => 'option',
			'default'=>$scorline_theme_options['show_service'],
			'sanitize_callback'=>'scoreline_sanitize_checkbox',
			'capability'        => 'edit_theme_options',
		)
	);
	$wp_customize->add_control( 'show_service', array(
		'label'        => __( 'Show Services on Home Page', 'scoreline' ),
		'type'=>'checkbox',
		'section'    => 'service_section',
		'settings'   => 'scoreline_options[show_service]',
	) );
	$wp_customize->add_setting(
	'scoreline_options[home_service_heading]',
		array(
		'default'=>esc_attr($scorline_theme_options['home_service_heading']),
		'type'=>'option',
		'sanitize_callback'=>'scoreline_sanitize_text',
		'capability'=>'edit_theme_options'
		));
	$wp_customize->add_control( 'home_service_heading', array(
		'label'        =>  __('Home Service Title', 'scoreline' ),
		'type'=>'text',
		'section'    => 'service_section',
		'settings'   => 'scoreline_options[home_service_heading]'
	    ));
	
	$wp_customize->add_setting(
	'scoreline_options[service_desc]',
		array(
		'default'=>esc_attr($scorline_theme_options['service_desc']),
		'type'=>'option',
		'sanitize_callback'=>'scoreline_sanitize_text',
		'capability'=>'edit_theme_options'
		));
	$wp_customize->add_control( 'service_desc', array(
		'label'        =>  __('Home Service Description', 'scoreline' ),
		'type'=>'text',
		'section'    => 'service_section',
		'settings'   => 'scoreline_options[service_desc]'
	    ));
		for($i=1; $i<=3; $i++){
	$wp_customize->add_setting(
		'scoreline_options[ser_img_'.$i.']',
		array(
			'type'    => 'option',
			'default'=>'',
			'capability' => 'edit_theme_options',
			'sanitize_callback'=>'scoreline_sanitize_integer',
		));
	$wp_customize->add_control( 
	new scoreline_Slider_Image_Control( 
	$wp_customize, 'ser_img_'.$i,
	array(
		'label'    => 'Service Image '.$i, 
		'section'  => 'service_section',
		'settings' => 'scoreline_options[ser_img_'.$i.']',
			
	) ) );
	}
	
	// For Home Extra Section Section
    $wp_customize->add_section('extra_section',array(
	'title'=>__("Home Extra Section",'scoreline'),
	'panel'=>'scoreline_theme_option',
	'capability'=>'edit_theme_options',
    'priority' => 35
	));
	$wp_customize->add_setting(
		'scoreline_options[show_ex_sec]',
		array(
			'type'    => 'option',
			'default'=>$scorline_theme_options['show_ex_sec'],
			'sanitize_callback'=>'scoreline_sanitize_checkbox',
			'capability'        => 'edit_theme_options',
		)
	);
	$wp_customize->add_control( 'show_ex_sec', array(
		'label'        => __( 'Show Portfilio on Home Page', 'scoreline' ),
		'type'=>'checkbox',
		'section'    => 'extra_section',
		'settings'   => 'scoreline_options[show_ex_sec]',
	) );
	$wp_customize->add_setting(
		'scoreline_options[section_title]',
		array(
			'type'    => 'option',
			'default'=>$scorline_theme_options['section_title'],
			'capability' => 'edit_theme_options',
			'sanitize_callback'=>'scoreline_sanitize_text',
		));
	$wp_customize->add_control( 'section_title', array(
		'label'        => __( 'Home Extra Section Heading', 'scoreline' ),
		'type'=>'text',
		'section'    => 'extra_section',
		'settings'   => 'scoreline_options[section_title]'
	) );
	$wp_customize->add_setting(
		'scoreline_options[sec_desc]',
		array(
			'type'    => 'option',
			'default'=>$scorline_theme_options['sec_desc'],
			'capability' => 'edit_theme_options',
			'sanitize_callback'=>'scoreline_sanitize_text',
		));
	$wp_customize->add_control( 'sec_desc', array(
		'label'        => __('Home Extra Section Description', 'scoreline' ),
		'type'=>'text',
		'section'    => 'extra_section',
		'settings'   => 'scoreline_options[sec_desc]'
	) );
	$wp_customize->add_setting(
		'scoreline_options[plugin_shortcode]',
		array(
			'type'    => 'option',
			'default'=>$scorline_theme_options['plugin_shortcode'],
			'capability' => 'edit_theme_options',
			'sanitize_callback'=>'scoreline_sanitize_text',
		));
	$wp_customize->add_control( 'plugin_shortcode', array(
		'label'        => __('Home Extra Section Shortcode', 'scoreline' ),
		'type'=>'text',
		'section'    => 'extra_section',
		'settings'   => 'scoreline_options[plugin_shortcode]'
	) );
	
	// For Home Blog Section
	$wp_customize->add_section('blog_section',array(
	'title'=>__("Home Blog Options",'scoreline'),
	'panel'=>'scoreline_theme_option',
	'capability'=>'edit_theme_options',
    'priority' => 35
	));
	$wp_customize->add_setting(
		'scoreline_options[show_blog]',
		array(
			'type'    => 'option',
			'default'=>$scorline_theme_options['show_blog'],
			'sanitize_callback'=>'scoreline_sanitize_checkbox',
			'capability'        => 'edit_theme_options',
		)
	);
	$wp_customize->add_control( 'show_blog', array(
		'label'        => __( 'Show Blog on Home Page', 'scoreline' ),
		'type'=>'checkbox',
		'section'    => 'blog_section',
		'settings'   => 'scoreline_options[show_blog]',
	) );
	$wp_customize->add_setting(
		'scoreline_options[blog_title]',
		array(
			'type'    => 'option',
			'default'=>$scorline_theme_options['blog_title'],
			'capability' => 'edit_theme_options',
			'sanitize_callback'=>'scoreline_sanitize_text',
		));
	$wp_customize->add_control( 'blog_title', array(
		'label'        => __('Home Blog Heading', 'scoreline' ),
		'type'=>'text',
		'section'    => 'blog_section',
		'settings'   => 'scoreline_options[blog_title]'
	) );
	$wp_customize->add_setting(
		'scoreline_options[blog_desc]',
		array(
			'type'    => 'option',
			'default'=>$scorline_theme_options['blog_desc'],
			'capability' => 'edit_theme_options',
			'sanitize_callback'=>'scoreline_sanitize_text',
		));
	$wp_customize->add_control( 'blog_desc', array(
		'label'        => __('Home Blog Description', 'scoreline' ),
		'type'=>'text',
		'section'    => 'blog_section',
		'settings'   => 'scoreline_options[blog_desc]'
	) );
	
	 // Social section
    $wp_customize->add_section('social_section',array(
	'title'=>__(" Social Options",'scoreline'),
	'panel'=>'scoreline_theme_option',
	'capability'=>'edit_theme_options',
    'priority' => 35
	));
	$wp_customize->add_setting(
	'scoreline_options[header_social_media_in_enabled]',
		array(
		'default'=>esc_attr($scorline_theme_options['header_social_media_in_enabled']),
		'type'=>'option',
		'sanitize_callback'=>'scoreline_sanitize_checkbox',
		'capability'=>'edit_theme_options'
		)
	);
	$wp_customize->add_control( 'header_social_media_in_enabled', array(
		'label'        => __( 'Enable Social Media Icons in Header', 'scoreline' ),
		'type'=>'checkbox',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[header_social_media_in_enabled]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[footer_section_social_media_enbled]',
		array(
		'default'=>esc_attr($scorline_theme_options['footer_section_social_media_enbled']),
		'type'=>'option',
		'sanitize_callback'=>'scoreline_sanitize_checkbox',
		'capability'=>'edit_theme_options'
		)
	);
	$wp_customize->add_control( 'footer_section_social_media_enbled', array(
		'label'        => __( 'Enable Social Media Icons in Footer', 'scoreline' ),
		'type'=>'checkbox',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[footer_section_social_media_enbled]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[email_id]',
		array(
		'default'=>esc_attr($scorline_theme_options['email_id']),
		'type'=>'option',
		'sanitize_callback'=>'sanitize_email',
		'capability'=>'edit_theme_options'
		)
	);
	$wp_customize->add_control( 'email_id', array(
		'label'        =>  __('Email ID', 'scoreline' ),
		'type'=>'email',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[email_id]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[phone_no]',
		array(
		'default'=>esc_attr($scorline_theme_options['phone_no']),
		'type'=>'option',
		'sanitize_callback'=>'scoreline_sanitize_text',
		'capability'=>'edit_theme_options'
		)
	);
	$wp_customize->add_control( 'phone_no', array(
		'label'        =>  __('Phone Number', 'scoreline' ),
		'type'=>'text',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[phone_no]'
	) );

	$wp_customize->add_setting(
	'scoreline_options[fb_link]',
		array(
		'default'=>esc_attr($scorline_theme_options['fb_link']),
		'type'=>'option',
		'sanitize_callback'=>'esc_url_raw',
		'capability'=>'edit_theme_options'
		)
	);
	$wp_customize->add_control( 'fb_link', array(
		'label'        => __( 'Facebook', 'scoreline' ),
		'type'=>'url',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[fb_link]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[gplus]',
		array(
		'default'=>esc_attr($scorline_theme_options['gplus']),
		'type'=>'option',
		'sanitize_callback'=>'esc_url_raw',
		'capability'=>'edit_theme_options'
		)
	);
		$wp_customize->add_control( 'gplus', array(
		'label'        => __( 'Google+', 'scoreline' ),
		'type'=>'url',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[gplus]'
	) );
	
	$wp_customize->add_setting(
	'scoreline_options[instagram_link]',
		array(
		'default'=>esc_attr($scorline_theme_options['instagram_link']),
		'type'=>'option',
		'sanitize_callback'=>'esc_url_raw',
		'capability'=>'edit_theme_options'
		)
	);
		$wp_customize->add_control( 'instagram_link', array(
		'label'        => __( 'Instagram', 'scoreline' ),
		'type'=>'url',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[instagram_link]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[youtube_link]',
		array(
		'default'=>esc_attr($scorline_theme_options['youtube_link']),
		'type'=>'option',
		'sanitize_callback'=>'esc_url_raw',
		'capability'=>'edit_theme_options'
		) );
	$wp_customize->add_control( 'youtube_link', array(
		'label'        => __( 'Youtube', 'scoreline' ),
		'type'=>'url',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[youtube_link]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[linkedin_link]',
		array(
		'default'=>esc_attr($scorline_theme_options['linkedin_link']),
		'type'=>'option',
		'sanitize_callback'=>'esc_url_raw',
		'capability'=>'edit_theme_options'
		) );
	$wp_customize->add_control( 'linkedin_link', array(
		'label'        => __( 'Linkedin', 'scoreline' ),
		'type'=>'url',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[linkedin_link]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[pinterest_link]',
		array(
		'default'=>esc_attr($scorline_theme_options['pinterest_link']),
		'type'=>'option',
		'sanitize_callback'=>'esc_url_raw',
		'capability'=>'edit_theme_options'
		) );
	$wp_customize->add_control( 'pinterest_link', array(
		'label'        => __( 'Pinterst', 'scoreline' ),
		'type'=>'url',
		'section'    => 'social_section',
		'settings'   => 'scoreline_options[pinterest_link]'
	) );
	
	// Footer Callout Section
	$wp_customize->add_section('callout_section',array(
	'title'=>__("Footer Call-Out Options",'scoreline'),
	'panel'=>'scoreline_theme_option',
	'capability'=>'edit_theme_options',
    'priority' => 35
	));
	$wp_customize->add_setting(
		'scoreline_options[show_callout]',
		array(
			'type'    => 'option',
			'default'=>$scorline_theme_options['show_callout'],
			'sanitize_callback'=>'scoreline_sanitize_checkbox',
			'capability'        => 'edit_theme_options',
		)
	);
	$wp_customize->add_control( 'show_callout', array(
		'label'        => __( 'Show Callout Area on Home Page', 'scoreline' ),
		'type'=>'checkbox',
		'section'    => 'callout_section',
		'settings'   => 'scoreline_options[show_callout]',
	) );
	$wp_customize->add_setting(
	'scoreline_options[fc_title]',
		array(
		'default'=>esc_attr($scorline_theme_options['fc_title']),
		'type'=>'option',
		'capability'=>'edit_theme_options',
		'sanitize_callback'=>'scoreline_sanitize_text',
		)
	);
	$wp_customize->add_control( 'fc_title', array(
		'label'        => __( 'Footer callout Title', 'scoreline' ),
		'type'=>'text',
		'section'    => 'callout_section',
		'settings'   => 'scoreline_options[fc_title]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[fc_btn_txt]',
		array(
		'default'=>esc_attr($scorline_theme_options['fc_btn_txt']),
		'type'=>'option',
		'capability'=>'edit_theme_options',
		'sanitize_callback'=>'scoreline_sanitize_text',
		)
	);
	$wp_customize->add_control( 'fc_btn_txt', array(
		'label'        => __( 'Footer callout Button Text', 'scoreline' ),
		'type'=>'text',
		'section'    => 'callout_section',
		'settings'   => 'scoreline_options[fc_btn_txt]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[fc_btn_link]',
		array(
		'default'=>esc_attr($scorline_theme_options['fc_btn_link']),
		'type'=>'option',
		'capability'=>'edit_theme_options',
		'sanitize_callback'=>'scoreline_sanitize_text',
		)
	);
	$wp_customize->add_control( 'fc_btn_link', array(
		'label'        => __( 'Footer callout Button Link', 'scoreline' ),
		'type'=>'text',
		'section'    => 'callout_section',
		'settings'   => 'scoreline_options[fc_btn_link]'
	) );
	
	// Footer Section
	$wp_customize->add_section('footer_section',array(
	'title'=>__("Footer Options",'scoreline'),
	'panel'=>'scoreline_theme_option',
	'capability'=>'edit_theme_options',
    'priority' => 35
	));
	$wp_customize->add_setting(
	'scoreline_options[footer_customizations]',
		array(
		'default'=>esc_attr($scorline_theme_options['footer_customizations']),
		'type'=>'option',
		'sanitize_callback'=>'scoreline_sanitize_text',
		'capability'=>'edit_theme_options'
		)
	);
	$wp_customize->add_control( 'footer_customizations', array(
		'label'        => __( 'Footer Customization Text', 'scoreline' ),
		'type'=>'text',
		'section'    => 'footer_section',
		'settings'   => 'scoreline_options[footer_customizations]'
	) );
	
	$wp_customize->add_setting(
	'scoreline_options[developed_by_text]',
		array(
		'default'=>esc_attr($scorline_theme_options['developed_by_text']),
		'type'=>'option',
		'sanitize_callback'=>'scoreline_sanitize_text',
		'capability'=>'edit_theme_options'
		)
	);
	$wp_customize->add_control( 'developed_by_text', array(
		'label'        => __( 'Developed By Text', 'scoreline' ),
		'type'=>'text',
		'section'    => 'footer_section',
		'settings'   => 'scoreline_options[developed_by_text]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[developed_by_weblizar_text]',
		array(
		'default'=>esc_attr($scorline_theme_options['developed_by_weblizar_text']),
		'type'=>'option',
		'sanitize_callback'=>'scoreline_sanitize_text',
		'capability'=>'edit_theme_options'
		)
	);
	$wp_customize->add_control( 'developed_by_weblizar_text', array(
		'label'        => __( 'Developed By Link Text', 'scoreline' ),
		'type'=>'text',
		'section'    => 'footer_section',
		'settings'   => 'scoreline_options[developed_by_weblizar_text]'
	) );
	$wp_customize->add_setting(
	'scoreline_options[developed_by_link]',
		array(
		'default'=>esc_attr($scorline_theme_options['developed_by_link']),
		'type'=>'option',
		'capability'=>'edit_theme_options',
		'sanitize_callback'=>'esc_url_raw'
		)
	);
	$wp_customize->add_control( 'developed_by_link', array(
		'label'        => __( 'Developed By Link', 'scoreline' ),
		'type'=>'url',
		'section'    => 'footer_section',
		'settings'   => 'scoreline_options[developed_by_link]'
	) ); 
$wp_customize->add_section( 'scoreline_more' , array(
				'title'      	=> __( 'Upgrade to Scoreline Premium', 'scoreline' ),
				'priority'   	=> 999,
				'panel'=>'scoreline_theme_option',
			) );

			$wp_customize->add_setting( 'scoreline_more', array(
				'default'    		=> null,
				'sanitize_callback' => 'sanitize_text_field',
			) );

			$wp_customize->add_control( new More_scoreline_Control( $wp_customize, 'scoreline_more', array(
				'label'    => __( 'Scoreline Premium', 'scoreline' ),
				'section'  => 'scoreline_more',
				'settings' => 'scoreline_more',
				'priority' => 1,
			) ) );	
}

function scoreline_sanitize_text( $input ) {
    return wp_kses_post( force_balance_tags( $input ) );
}
function scoreline_sanitize_checkbox( $input ) {
   if ( $input == 1 ) {
        return 'on' ;
    } else {
        return '';
    }
}
function scoreline_sanitize_integer( $input ) {
    return (int)($input);
}

/* class for thumbnail images */
if ( class_exists( 'WP_Customize_Control' ) && ! class_exists( 'scoreline_Slider_Image_Control' ) ) :
class scoreline_Slider_Image_Control extends WP_Customize_Control 
{  
 public function render_content(){ ?>
	<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
	<?php $args = array( 'post_type' => 'post', 'post_status'=>'publish','posts_per_page'=> -1); 
		$slide_id = new WP_Query( $args ); ?>
		<select <?php $this->link(); ?> >
		<option value= "" <?php if($this->value()=='') echo 'selected="selected"';?>><?php _e('Default Image','scoreline'); ?></option>
		<?php if($slide_id->have_posts()):
			while($slide_id->have_posts()):
				$slide_id->the_post();
				if(has_post_thumbnail()){ ?>
				 <option value= "<?php echo get_the_id(); ?>"<?php if($this->value()== get_the_id() ) echo 'selected="selected"';?>><?php the_title(); ?></option>
				<?php }
			endwhile; 
	     endif; ?>
		 </select>
		 <?php
}  /* public function ends */
}/*   class ends */
endif;

/* class for categories */
if ( class_exists( 'WP_Customize_Control' ) && ! class_exists( 'scoreline_category_Control' ) ) :
class scoreline_category_Control extends WP_Customize_Control 
{  
 public function render_content(){ ?>
	<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
	<?php  
		$scoreline_category = get_categories(); ?>
		<select <?php $this->link(); ?> >
		<?php foreach($scoreline_category as $category){ ?>
		<option value= "<?php echo $category->cat_name; ?>" <?php if($this->value()== $category->cat_name ) echo 'selected="selected"';?>><?php echo $category->cat_name; ?></option>
		<?php } ?>
		 </select>
		 <?php
}  /* public function ends */
}/*   class ends */
endif; 

if ( class_exists( 'WP_Customize_Control' ) && ! class_exists( 'More_scoreline_Control' ) ) :
class More_scoreline_Control extends WP_Customize_Control {

	/**
	* Render the content on the theme customizer page
	*/
	public function render_content() {
		?>
		<label style="overflow: hidden; zoom: 1;">
			<div class="col-md-2 col-sm-6 upsell-btn">					
					<a style="margin-bottom:20px;margin-left:20px;" href="https://weblizar.com/themes/scoreline-premium/" target="blank" class="btn btn-success btn"><?php _e('Upgrade to Enigma Premium','enigma'); ?> </a>
			</div>
			<div class="col-md-4 col-sm-6">
				<img class="enigma_img_responsive " src="<?php echo get_template_directory_uri() .'/images/score-line-short.png'?>">
			</div>			
			<div class="col-md-3 col-sm-6">
				<h3 style="margin-top:10px;margin-left: 20px;text-decoration:underline;color:#333;"><?php echo _e( 'Scoreline Premium - Features','scoreline'); ?></h3>
					<ul style="padding-top:20px">
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('Responsive Design','scoreline'); ?> </li>
										
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('More than 18+ Templates','scoreline'); ?> </li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('7+ Different Types of Blog Templates','scoreline'); ?> </li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('6+ Types of Portfolio Templates','scoreline'); ?></li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('5+ Sevice Templates','scoreline'); ?></li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('Patterns Background','scoreline'); ?>   </li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('WPML Compatible','scoreline'); ?>   </li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('Woo-commerce Compatible','scoreline'); ?>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('Image Background','scoreline'); ?>  </li>	
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('Ultimate Portfolio layout with Isotope effect','scoreline'); ?> </li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('Rich Short codes','scoreline'); ?> </li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('Translation Ready','scoreline'); ?> </li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('Coming Soon Mode','scoreline'); ?>  </li>
						<li class="upsell-enigma"> <div class="dashicons dashicons-yes"></div> <?php _e('Extreme Gallery Design Layout','scoreline'); ?>  </li>
					
					</ul>
			</div>
			<div class="col-md-2 col-sm-6 upsell-btn">					
					<a style="margin-bottom:20px;margin-left:20px;" href="https://weblizar.com/themes/scoreline-premium/" target="blank" class="btn btn-success btn"><?php _e('Upgrade to Scoreline Premium','scoreline'); ?> </a>
			</div>
			<span class="customize-control-title"><?php _e( 'Enjoying Scoreline?', 'scoreline' ); ?></span>
			<p>
				<?php
					printf( __( 'If you Like our Products , Please do Rate us on %sWordPress.org%s?  We\'d really appreciate it!', 'scoreline' ), '<a target="" href="https://wordpress.org/support/view/theme-reviews/scoreline?filter=5">', '</a>' );
				?>
			</p>
		</label>
		<?php
	}
}
endif;
?>